// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Engine Patch Layer (EPL).
//
// Layer 4 of the RSIL stack. Applies per-game engine patches that
// inflate the streaming buffer size and LOD distance constants, combined
// with DuckStation's 8MB RAM expansion mode. This is the technique
// proven by the Gran Turismo 2 community ("big drawing distance" mod).
//
// HOW IT WORKS
// ------------
// The PS1 engine has a fixed streaming buffer in main RAM (typically
// 16-64KB) where it decompresses the next track sector before DMA-ing
// it to VRAM. The buffer size is hardcoded as a constant in the game
// executable. With 2MB RAM, the buffer is small — the engine can only
// hold a few sectors ahead, causing pop-in when the player outruns the
// buffer.
//
// With DuckStation's 8MB RAM mode + a patch that increases the buffer
// size constant, the engine holds more sectors ahead. Draw distance
// increases; pop-in is pushed further out.
//
// PATCH FORMAT
// ------------
// Patches are signature-anchored, not address-anchored. Each patch
// specifies a byte pattern (with wildcard mask) to search for in the
// loaded executable. When the pattern matches, the patch overwrites
// the matched bytes with new values. This makes patches portable
// across regional variants (SCES/SCUS/SLUS/SLPS) and across revisions.
//
// Patches are authored by the community (reverse engineers who analyze
// each game's streaming code). RSIL provides the engine that applies
// them; it does not ship patches itself.
//
// DIVERGENCE
// ----------
// Enhanced mode intentionally diverges from original hardware behavior
// in CPU state (the patched executable runs different code). GPU state
// is NOT diverged — the GPU still receives and executes exactly what
// the (patched) engine commands. The validator in Enhanced mode
// compares against a patched baseline, not the original.

#pragma once

#include "rsil/Types.h"

#include <cstdint>
#include <filesystem>
#include <functional>
#include <optional>
#include <string>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// Patch manifest
// ---------------------------------------------------------------------------

// A single byte-pattern patch. The pattern is searched in the loaded
// executable image; when found, the matched bytes are replaced.
struct PatchEntry {
    std::string name;
    std::string description;

    // Byte pattern to search for. Hex string, e.g. "8B 04 24 ?? ?? ?? ?? 8D".
    // "??" is a wildcard that matches any byte.
    std::string pattern_hex;

    // Replacement bytes. Must be the same length as the pattern (wildcards
    // in the pattern positions are preserved from the original).
    std::string replacement_hex;

    // Category for display in the overlay.
    enum class Category : uint8_t {
        StreamingBudget,   // increases the engine's per-frame DMA sector count
        LodDistance,       // increases LOD switch distance
        VramEviction,      // delays or disables engine VRAM eviction
        Other,
    } category = Category::Other;

    // Whether this patch requires 8MB RAM mode.
    bool requires_8mb = true;
};

// A complete manifest for one game executable.
struct PatchManifest {
    ExecutableSignature exe_signature;
    std::string display_name;
    std::vector<PatchEntry> patches;

    // Recommended DuckStation settings for this manifest.
    bool recommend_8mb_ram = true;
    bool recommend_fastboot = false;
};

// ---------------------------------------------------------------------------
// Pattern matcher
// ---------------------------------------------------------------------------

// Compiled byte pattern with wildcard mask. Pre-compiled for fast scanning.
struct CompiledPattern {
    std::vector<uint8_t> bytes;
    std::vector<uint8_t> mask;  // 0xFF = match, 0x00 = wildcard
    size_t length = 0;
};

CompiledPattern compile_pattern(const std::string& pattern_hex);

// Scan a byte range for the pattern. Returns the offset of the first
// match, or std::nullopt if not found.
std::optional<size_t> scan_pattern(const uint8_t* data, size_t size,
                                   const CompiledPattern& pattern);

// ---------------------------------------------------------------------------
// RAM access interface
// ---------------------------------------------------------------------------

// Abstract interface for reading/writing emulated RAM. DuckStation
// provides a concrete implementation backed by its Bus class.
class RamAccess {
public:
    virtual ~RamAccess() = default;

    // Read a range of RAM. Returns false if the range is unmapped.
    virtual bool read(uint32_t address, uint8_t* dest, size_t size) = 0;

    // Write a range of RAM. Returns false if the range is unmapped
    // or read-only.
    virtual bool write(uint32_t address, const uint8_t* src, size_t size) = 0;

    // Get the total RAM size (2MB or 8MB depending on DuckStation config).
    virtual size_t ram_size() = 0;
};

// ---------------------------------------------------------------------------
// Applied patch record (for revert)
// ---------------------------------------------------------------------------

struct AppliedPatch {
    std::string name;
    uint32_t address = 0;
    std::vector<uint8_t> original_bytes;
    std::vector<uint8_t> patched_bytes;
    bool active = false;
};

// ---------------------------------------------------------------------------
// ScenePatchLayer
// ---------------------------------------------------------------------------

class ScenePatchLayer {
public:
    ScenePatchLayer();

    // Load a patch manifest from a JSON file. Returns false on parse error.
    bool load_manifest(const std::filesystem::path& path);

    // Check whether the loaded manifest matches the given executable
    // signature. Returns true if the manifest is applicable.
    bool matches_executable(const ExecutableSignature& sig) const;

    // Apply all patches in the manifest to emulated RAM via the RamAccess
    // interface. Patches are applied in manifest order. If a pattern is
    // not found, that patch is skipped (with a warning) but the rest
    // proceed. Returns the number of patches successfully applied.
    //
    // PRECONDITION: matches_executable() returned true.
    // PRECONDITION: DuckStation is running with 8MB RAM mode if any
    //   patch has requires_8mb = true.
    uint32_t apply(RamAccess& ram);

    // Revert all applied patches (restore original bytes).
    void revert(RamAccess& ram);

    // Query state.
    bool is_applied() const { return applied_; }
    const std::vector<AppliedPatch>& applied_patches() const { return applied_patches_; }
    const PatchManifest& manifest() const { return manifest_; }
    bool has_manifest() const { return has_manifest_; }

    // Stats for the overlay.
    struct Stats {
        uint32_t patches_applied = 0;
        uint32_t patches_skipped = 0;
        uint32_t patches_failed = 0;
    };
    const Stats& stats() const { return stats_; }

private:
    bool has_manifest_ = false;
    bool applied_ = false;
    PatchManifest manifest_;
    std::vector<AppliedPatch> applied_patches_;
    Stats stats_;
};

// ---------------------------------------------------------------------------
// Manifest loading (JSON)
// ---------------------------------------------------------------------------

// Parse a patch manifest from a JSON string. Returns false on error.
bool parse_manifest_json(const std::string& json, PatchManifest& out);

// Load a manifest from a JSON file.
bool load_manifest_file(const std::filesystem::path& path, PatchManifest& out);

// Scan a directory for manifest files matching the given executable
// signature. Returns the path to the first matching manifest, or empty.
std::filesystem::path find_manifest_for_exe(
    const std::filesystem::path& dir,
    const ExecutableSignature& sig);

}  // namespace rsil
