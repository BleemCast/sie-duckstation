// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Runtime Spatial Inference Layer for DuckStation
// Public type definitions shared across all subsystems.
//
// All types in this header are metadata-only. They MUST NOT carry:
//   - absolute vertex coordinates
//   - mesh data
//   - texture pixels / CLUT pixels
//   - raw VRAM dumps
//   - raw RAM dumps
//
// Coordinate-bearing fields (VertexDelta, BoundingBox) store only
// *normalized relative* deltas, which are non-reversible and cannot be
// used to reconstruct copyrighted geometry.

#pragma once

#include <array>
#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// Identifiers
// ---------------------------------------------------------------------------

// 128-bit content hash of a game executable used as the top-level cache key.
// Computed from the .exe image as loaded by DuckStation (post-PS-EXE header
// parse, region-agnostic). Stored as hex string in persistence.
struct ExecutableSignature {
    std::array<uint8_t, 16> md5 = {};
    uint32_t crc32 = 0;
    std::string display_name;   // "SCES-00901" / "SLUS-00870" etc., metadata only

    bool operator==(const ExecutableSignature& o) const {
        return md5 == o.md5 && crc32 == o.crc32;
    }
};

// Stable 64-bit cluster signature. See ClusterSignature.h for construction.
// The signature is a structural hash: same topology+counts+attributes+relative
// bbox deltas => same signature. It does NOT encode absolute position.
using ClusterSignatureId = uint64_t;

// Monotonic per-frame counters. Wraps at 2^32; consumers must treat as
// modular when comparing across sessions.
using FrameId = uint32_t;
using ClusterEventId = uint64_t;   // global, monotonic across the session
using CellId = uint32_t;           // visibility cell identifier
using SectorId = uint32_t;         // track sector identifier
using TrackId = uint32_t;          // track identifier

// Invalid sentinel values.
constexpr ClusterSignatureId kInvalidSignature = 0;
constexpr CellId kInvalidCell = 0xFFFFFFFFu;
constexpr SectorId kInvalidSector = 0xFFFFFFFFu;
constexpr TrackId kInvalidTrack = 0xFFFFFFFFu;

// ---------------------------------------------------------------------------
// PS1 GPU primitive metadata (mirrors GPUSTAT / packet fields, metadata only)
// ---------------------------------------------------------------------------

enum class PrimitiveTopology : uint8_t {
    Unknown = 0,
    Polygon,        // 0x04..0x07
    Line,           // 0x40..0x47
    Sprite,         // 0x64..0x67
    Quad,
};

// Texpage (TP) register bits 0..15 (mirrors PS1 GPU TP register).
// Stored as raw 16-bit field; consumers extract transparent/blending/dither
// bits as needed. Metadata only — does NOT imply texture pixels are stored.
using TexpageId = uint16_t;
using ClutId = uint16_t;

// Per-primitive attribute snapshot. Lightweight, copied by value.
struct PrimitiveAttributes {
    TexpageId texpage = 0;
    ClutId    clut    = 0;
    uint8_t   raw_cmd = 0;            // first byte of the primitive packet
    bool      textured  : 1;
    bool      gouraud   : 1;
    bool      blended   : 1;
    bool      lit       : 1;          // has lighting flag
    uint8_t   reserved  : 4;

    bool operator==(const PrimitiveAttributes& o) const {
        return texpage == o.texpage && clut == o.clut && raw_cmd == o.raw_cmd &&
               textured == o.textured && gouraud == o.gouraud &&
               blended == o.blended && lit == o.lit;
    }
};

// Normalized relative bounding box. All deltas are computed as
//   (v - centroid) / max_axis_extent
// and quantized to int16 for stable hashing. The normalization is
// *non-reversible* — the original vertex coordinates cannot be recovered
// from these values.
struct NormalizedBBox {
    std::array<int16_t, 3> min_delta = {0, 0, 0};
    std::array<int16_t, 3> max_delta = {0, 0, 0};

    bool operator==(const NormalizedBBox& o) const {
        return min_delta == o.min_delta && max_delta == o.max_delta;
    }
};

// ---------------------------------------------------------------------------
// Telemetry records
// ---------------------------------------------------------------------------

// A single primitive observed in the GPU command FIFO.
struct PrimitiveObservation {
    PrimitiveTopology  topology = PrimitiveTopology::Unknown;
    uint16_t           vertex_count = 0;
    PrimitiveAttributes attrs;
    NormalizedBBox     bbox;
    // Runtime source pointer captured from the DMA chain header at observation
    // time. NEVER persisted; used only for live adjacency inference.
    uint32_t           transient_source_ram = 0;
    uint32_t           transient_vram_dest  = 0;
};

// A group of consecutive primitives sharing identical Texpage, CLUT and
// attributes. This is the atomic unit of cluster signature hashing.
struct ClusterEvent {
    ClusterEventId    id = 0;
    FrameId           frame = 0;
    PrimitiveAttributes attrs;
    PrimitiveTopology topology = PrimitiveTopology::Unknown;
    uint32_t          primitive_count = 0;
    uint32_t          total_vertex_count = 0;
    NormalizedBBox    aggregate_bbox;
    // Aggregated per-cluster signature (post-grouping).
    ClusterSignatureId signature_id = kInvalidSignature;
};

// ---------------------------------------------------------------------------
// Scheduling / prediction
// ---------------------------------------------------------------------------

// Confidence in [0,1] derived from a decaying weighted moving average of
// transition frequency. See AdjacencyGraph.h.
using TransitionConfidence = float;

struct Transition {
    ClusterSignatureId from = kInvalidSignature;
    ClusterSignatureId to   = kInvalidSignature;
    TransitionConfidence confidence = 0.0f;
    uint32_t            observed_count = 0;
};

// ---------------------------------------------------------------------------
// Host-side pre-registration request
// ---------------------------------------------------------------------------

// Opaque token returned by the host renderer when a pre-registration has been
// accepted. The renderer is free to ignore or evict; the RSIL layer treats
// the host as advisory only.
using HostPreRegToken = uint64_t;
constexpr HostPreRegToken kInvalidToken = 0;

struct PreRegistrationRequest {
    ClusterSignatureId signature_id = kInvalidSignature;
    TexpageId          texpage = 0;
    ClutId             clut = 0;
    // Full attribute mask for shader pre-compilation. Populated by the
    // Predictor from the SignatureRegistry.
    PrimitiveAttributes attrs;
    // Logical position in the spatial catalog (cell + sector). Used by the
    // host culler to place the predicted primitive in cache-coherent order.
    CellId             hint_cell = kInvalidCell;
    SectorId           hint_sector = kInvalidSector;
    // Hot-path flag: when true, the host should also elevate CPU priority
    // for the expected DMA transfer (see HostPreRegistrar).
    bool               elevate_priority = false;
};

// ---------------------------------------------------------------------------
// Feature flags
// ---------------------------------------------------------------------------

// Each subsystem can be toggled at runtime via config without recompile.
// Disabled subsystems must be no-ops that return immediately on entry.
struct FeatureFlags {
    bool telemetry    = true;
    bool graph        = true;
    bool predictor    = true;
    bool preregister  = true;
    bool overlay      = false;  // opt-in
    bool persistence  = true;
    bool validator    = false;  // opt-in (has runtime cost)

    bool anything_enabled() const {
        return telemetry || graph || predictor || preregister ||
               overlay || persistence || validator;
    }
};

// ---------------------------------------------------------------------------
// Emulation mode
// ---------------------------------------------------------------------------

// Deterministic: pure host-side optimization. Zero CPU/GPU divergence.
//   RSIL only pre-warms host resources. Engine behavior unchanged.
//
// Enhanced: applies per-game engine patches (Layer 4). CPU divergence
//   is expected and intentional — the engine's streaming budget and LOD
//   distances are inflated. GPU emulation still produces exactly what
//   the (patched) engine commands; the host renderer is unchanged.
//
// Enhanced mode requires:
//   - 8MB RAM expansion enabled in DuckStation (provides space for the
//     larger streaming buffer)
//   - A matching patch manifest for the loaded executable
//   - Explicit user opt-in (never default)
enum class EmulationMode : uint8_t {
    Deterministic = 0,
    Enhanced,
};

}  // namespace rsil
