// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Top-level subsystem facade.
//
// The single entry point DuckStation integrates. Owns all RSIL submodules
// and wires them into the per-frame pipeline. Thread-safety: all public
// methods are safe to call from the GPU thread; the persistence worker
// runs on its own thread.

#pragma once

#include "rsil/Types.h"
#include "rsil/Config.h"
#include "rsil/TelemetryTap.h"
#include "rsil/ClusterSignature.h"
#include "rsil/SpatialCatalog.h"
#include "rsil/AdjacencyGraph.h"
#include "rsil/Predictor.h"
#include "rsil/HostPreRegistrar.h"
#include "rsil/Persistence.h"
#include "rsil/Validator.h"
#include "rsil/DebugOverlay.h"
#include "rsil/HeadlessPrePass.h"
#include "rsil/ScenePatchLayer.h"
#include "rsil/GpuPacketParser.h"
#include "rsil/MipsPatternScanner.h"

#include <memory>
#include <optional>

namespace rsil {

// Top-level subsystem. DuckStation holds one of these per running game.
class RSILSubsystem : public TelemetrySink {
public:
    // Factory: creates a subsystem bound to a host adapter. The host
    // adapter is owned by the caller (typically DuckStation's Vulkan
    // backend).
    static std::unique_ptr<RSILSubsystem> create(
        RSILConfig cfg,
        HostAdapter& host,
        std::unique_ptr<HashProvider> hash_provider = nullptr,
        std::unique_ptr<PersistenceBackend> persistence = nullptr);

    ~RSILSubsystem() override;

    // -------- Lifecycle --------

    // Called once when a game executable is loaded. Computes the
    // ExecutableSignature, attempts to load any cached metadata, and
    // resets per-game state.
    void on_executable_loaded(const ExecutableSignature& sig);

    // Called when the game is unloaded / emulator stopped. Flushes
    // persistence.
    void on_executable_unloaded();

    // -------- TelemetrySink (called from GPU thread) --------

    void on_gpu_command(const GpuCommandWord& w) override;
    void on_dma_packet(const DmaPacketObservation& p) override;
    void on_frame_boundary(FrameId frame) override;

    // -------- Per-frame pump --------
    //
    // Called once per VSync from the host's render thread. Drives:
    //   1. Cluster signature finalization (flush any in-flight cluster).
    //   2. Adjacency graph transition observation.
    //   3. Predictor look-ahead.
    //   4. Host pre-registration.
    //   5. Validator sampling.
    //   6. Persistence throttled save.
    void pump(FrameId frame);

    // -------- Overlay --------

    void draw_overlay();

    // -------- Config / flags --------

    void set_flags(const FeatureFlags& flags);
    const FeatureFlags& flags() const { return cfg_.flags; }
    const RSILConfig&   config() const { return cfg_; }

    // -------- Pre-pass mode --------
    //
    // When true, the subsystem runs in "pre-pass mode": telemetry, graph,
    // and catalog operate normally, but the predictor and host pre-registrar
    // are disabled (there is no host renderer to pre-warm). The persistence
    // layer saves aggressively (every checkpoint_interval frames).
    //
    // This mode is used by the `prewarm` CLI tool during the headless
    // pre-pass. On a normal launch, pre_pass_mode is false and the
    // CachePrimer loads any existing cache before the first frame.
    void set_pre_pass_mode(bool enabled);
    bool pre_pass_mode() const { return pre_pass_mode_; }

    // On normal launch: load any existing pre-pass cache. Returns true
    // if a cache was found and loaded (predictor will be confident from
    // frame 1).
    bool load_cache();

    // Run the headless pre-pass. The frame_advance callback is called
    // once per frame; it should advance the emulator by one frame and
    // return true to continue. See HeadlessPrePass for details.
    bool run_pre_pass(const PrePassConfig& pcfg,
                      HeadlessPrePass::FrameAdvanceFn advance_frame);

    PrePassProgress pre_pass_progress() const;

    // -------- Enhanced mode (Layer 4 — Engine Patch Layer) --------
    //
    // Enhanced mode applies per-game engine patches (streaming budget,
    // LOD distance) combined with DuckStation's 8MB RAM mode. This is
    // the GT2 "big drawing distance" technique.
    //
    // Enhanced mode is ALWAYS opt-in. Default is Deterministic.
    // CPU divergence is expected in Enhanced mode; GPU divergence is not.

    EmulationMode emulation_mode() const { return mode_; }

    // Set the emulation mode. When switching to Enhanced, the subsystem
    // will look for a matching patch manifest in the patches directory
    // and apply it via the RamAccess interface. When switching back to
    // Deterministic, patches are reverted.
    //
    // ram: DuckStation's RAM access interface (required for Enhanced).
    // patches_dir: directory containing patch manifest JSON files.
    void set_emulation_mode(EmulationMode mode,
                            RamAccess* ram = nullptr,
                            const std::filesystem::path& patches_dir = {});

    bool enhanced_mode_active() const {
        return mode_ == EmulationMode::Enhanced && epl_.is_applied();
    }
    const ScenePatchLayer& patch_layer() const { return epl_; }

    // -------- Auto-discovery (in-process MIPS scan) --------
    //
    // On first load of a new game, scan the PS-X EXE for culling
    // instruction patterns and populate the ScenePatchLayer manifest
    // automatically. This is the "Cemu shader cache build" pass —
    // first run takes ~50-200ms, subsequent loads skip the scan.
    //
    // The scan runs on the calling thread (GPU thread at boot). Results
    // are cached in the RSIL persistence database.
    //
    // exe_data: the raw bytes of the loaded game image (disc image or
    //   RAM dump). The scanner searches for the PS-X EXE magic.
    bool auto_discover_patches(const std::vector<uint8_t>& exe_data);

    // Whether the last auto_discover call found any candidates.
    bool has_discovered_patches() const { return scan_stats_.total_candidates > 0; }
    const MipsPatternScanner::Stats& scan_stats() const { return scan_stats_; }

    // -------- Deferred scan control --------
    //
    // The MIPS scan cannot run at BootSystem() time because the game's
    // executable isn't in RAM yet (BIOS hasn't booted). The caller sets
    // scan_deferred = true at boot, and the per-frame pump checks each
    // frame whether code pages exist in RAM. When they do, the scan
    // runs once and the flag is cleared.
    void set_scan_deferred(bool deferred) { scan_deferred_ = deferred; }
    bool scan_deferred() const { return scan_deferred_; }

    // -------- Accessors (read-only, for host integration tests) --------

    const SignatureRegistry& signatures() const { return sigs_; }
    const SpatialCatalog&    catalog()    const { return catalog_; }
    const AdjacencyGraph&    graph()      const { return graph_; }
    const Predictor::Stats&  predictor_stats() const;
    const HostPreRegistrar::Stats& prereg_stats() const;
    const Validator::Stats*  validator_stats() const;

    // Expose the tap so DuckStation can register additional sinks if needed.
    TelemetryTap& tap() { return tap_; }

    // -------- Corrected telemetry: accept decoded draw commands --------
    //
    // DuckStation's GPU backend decodes raw GP0 FIFO words into
    // GPUBackendDrawCommand structs with all fields populated. RSIL
    // should consume these directly instead of re-parsing the FIFO.
    //
    // This method is called from the CPU thread after FillDrawCommand().
    // The texpage/clut/attributes are extracted from the decoded command.
    //
    // texpage: raw 16-bit GPUDrawModeReg.bits
    // clut: raw 16-bit GPUTexturePaletteReg.bits
    // textured/translucent/gouraud/quad: decoded boolean flags
    // vertex_count: 3 (triangle), 4 (quad), 2 (line/rect)
    // vertices: array of {x, y} screen positions (for bbox computation)
    void on_decoded_draw(uint16_t texpage, uint16_t clut,
                         bool textured, bool translucent,
                         bool gouraud, bool quad,
                         uint32_t vertex_count,
                         const int16_t* vertices_xy,  // [vertex_count * 2]
                         FrameId frame);

private:
    RSILSubsystem(RSILConfig cfg,
                  HostAdapter& host,
                  std::unique_ptr<HashProvider> hash_provider,
                  std::unique_ptr<PersistenceBackend> persistence);

    // Internal: cluster signature finalization on primitive arrival.
    void on_cluster_closed(const ClusterEvent& ev);

    RSILConfig                    cfg_;
    HostAdapter&                  host_;
    std::unique_ptr<HashProvider> hash_provider_;
    std::unique_ptr<PersistenceBackend> persistence_backend_;
    std::unique_ptr<PersistenceManager> persistence_;

    TelemetryTap        tap_;
    PrimitiveClusterer  clusterer_;
    GpuPacketParser     parser_;
    SignatureRegistry   sigs_;
    SpatialCatalog      catalog_;
    AdjacencyGraph      graph_;
    Predictor           predictor_;
    HostPreRegistrar    prereg_;
    std::optional<Validator>    validator_;
    std::optional<DebugOverlay> overlay_;
    std::unique_ptr<HeadlessPrePass> pre_pass_;
    std::unique_ptr<CachePrimer>     cache_primer_;
    ScenePatchLayer                  epl_;
    MipsPatternScanner               scanner_;
    MipsPatternScanner::Stats        scan_stats_;
    RamAccess*                       ram_access_ = nullptr;

    ExecutableSignature exe_;
    bool                exe_loaded_ = false;
    bool                pre_pass_mode_ = false;
    bool                scan_deferred_ = false;
    EmulationMode       mode_ = EmulationMode::Deterministic;

    // Rolling context window for higher-order prediction (size =
    // cfg.lookahead_frames). Updated by on_cluster_closed.
    std::vector<ClusterSignatureId> history_;
};

}  // namespace rsil
