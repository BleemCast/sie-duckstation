// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Telemetry tap.
//
// Read-only observation layer over the PS1 GPU command FIFO and DMA
// controller. No data is mutated; the tap only inspects packets in flight.
//
// DuckStation integration: subclass `TelemetrySink` and route GPU command
// writes (0xA0 VRAM transfers, 0x80/0xC0 polygon packets) and DMA CH1/CH2
// transfers to `on_gpu_command` / `on_dma_packet`. RSIL handles grouping
// into ClusterEvents.

#pragma once

#include "rsil/Types.h"

#include <functional>
#include <mutex>
#include <vector>

namespace rsil {

// Raw GPU command word stream observed from the FIFO. Each entry is a
// 32-bit word as written to GP0/GP1 by the R3000A. The tap does NOT
// interpret commands; it forwards raw words to the clusterer.
struct GpuCommandWord {
    uint32_t address;   // GP0 (0) or GP1 (1), metadata only
    uint32_t word;
    FrameId  frame;
};

// Raw DMA packet observation. CH1 (GPU OT) and CH2 (GPU DMA) are the
// relevant channels for primitive streaming. The tap captures the source
// RAM address from the DMA chain header at observation time — this is a
// transient runtime value, NOT persisted.
struct DmaPacketObservation {
    uint8_t  channel;            // 1 or 2 typically
    uint32_t source_ram;         // transient, never persisted
    uint32_t dest_vram;          // transient, never persisted
    uint32_t word_count;
    FrameId  frame;
};

// TelemetrySink: subclass and register with TelemetryTap.
// All callbacks fire on the emulator's GPU thread; implementations MUST
// be non-blocking. RSIL's default implementation pushes events into a
// lock-free single-producer/single-consumer queue for off-thread analysis.
class TelemetrySink {
public:
    virtual ~TelemetrySink() = default;
    virtual void on_gpu_command(const GpuCommandWord& w) = 0;
    virtual void on_dma_packet(const DmaPacketObservation& p) = 0;
    virtual void on_frame_boundary(FrameId frame) = 0;
};

// TelemetryTap: owns the subscription list and dispatches events.
// Thread-safety: add_sink/remove_sink may be called from any thread;
// dispatch happens from the GPU thread.
class TelemetryTap {
public:
    void add_sink(TelemetrySink* sink);
    void remove_sink(TelemetrySink* sink);

    // Called from DuckStation's GPU backend on every GP0/GP1 write.
    void emit_gpu_command(uint32_t address, uint32_t word, FrameId frame);

    // Called from DuckStation's DMA backend on every CH1/CH2 transfer.
    void emit_dma_packet(uint8_t channel, uint32_t source_ram,
                         uint32_t dest_vram, uint32_t word_count, FrameId frame);

    // Called at VSync.
    void emit_frame_boundary(FrameId frame);

private:
    std::mutex sinks_mu_;
    std::vector<TelemetrySink*> sinks_;
};

}  // namespace rsil
