// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Headless Pre-Pass (HPP).
//
// The Cemu-cache pattern, applied to scheduling instead of shaders.
//
// ON FIRST PLAY OF A GAME:
//   1. DuckStation launches headless (--prewarm flag).
//   2. A save state is loaded (optional; per-game metadata identifies a
//      good starting point — typically the start of a race or the first
//      track sector).
//   3. Reference inputs are replayed (optional; for racing games this
//      is just "accelerate and steer mildly" for N minutes).
//   4. RSIL runs in pre-pass mode: telemetry + graph + catalog operate
//      normally, but the predictor and host pre-registrar are disabled
//      (there is no host renderer to pre-warm).
//   5. After N frames (default: 36000 = 10 minutes @60fps), RSIL saves
//      the fully-saturated cache to SQLite and exits.
//
// ON SUBSEQUENT PLAYS:
//   1. DuckStation launches normally.
//   2. RSIL loads the pre-pass cache.
//   3. The predictor is confident from frame 1 (the graph is saturated).
//   4. The host pre-registrar has the full signature vocabulary and
//      pre-allocates resources for the predicted clusters.
//   5. Host-side pop-in is eliminated from the first frame.
//
// WHAT THE CACHE CONTAINS (metadata only):
//   - Cluster signatures (non-reversible structural hashes)
//   - Adjacency graph edges with saturated transition confidences
//   - Spatial catalog (cell/sector/track assignments)
//   - Per-signature host preparation cost estimates
//
// WHAT THE CACHE DOES NOT CONTAIN:
//   - Vertex coordinates, meshes, textures, CLUTs
//   - GPU command buffers
//   - Anything copyrighted
//
// The cache is shareable between users (like Cemu's shader caches) and
// can be distributed as a small SQLite file per game executable.

#pragma once

#include "rsil/Types.h"
#include "rsil/Config.h"
#include "rsil/ClusterSignature.h"
#include "rsil/SpatialCatalog.h"
#include "rsil/AdjacencyGraph.h"
#include "rsil/Persistence.h"

#include <atomic>
#include <chrono>
#include <filesystem>
#include <functional>
#include <memory>
#include <mutex>
#include <string>

namespace rsil {

// ---------------------------------------------------------------------------
// PrePassConfig
// ---------------------------------------------------------------------------

struct PrePassConfig {
    // Number of frames to run the pre-pass. Default: 36000 (10 min @60fps).
    // Racing games with ~30s track loops saturate the graph in ~5 min;
    // the extra time covers alternate paths and loading screens.
    uint32_t target_frames = 36000;

    // Optional save state path to load before starting. Empty => start
    // from the game's default boot point. Using a save state that skips
    // the boot/menu sequence dramatically improves pre-pass efficiency.
    std::filesystem::path save_state_path;

    // Optional input replay file. Empty => no inputs injected (the game
    // runs whatever demo/attract mode it has). For racing games, a
    // simple "accelerate + mild steer" replay covers most track sectors.
    std::filesystem::path input_replay_path;

    // If true, the pre-pass runs even if a cache already exists. Useful
    // for refreshing after a DuckStation or RSIL upgrade.
    bool force = false;

    // If true, the pre-pass saves intermediate snapshots every
    // checkpoint_interval frames. If the pre-pass is interrupted, the
    // latest snapshot can be resumed.
    bool checkpoint = true;
    uint32_t checkpoint_interval = 6000;  // every ~100s @60fps

    static PrePassConfig defaults() { return {}; }
};

// ---------------------------------------------------------------------------
// PrePassProgress
// ---------------------------------------------------------------------------

struct PrePassProgress {
    uint32_t frames_elapsed = 0;
    uint32_t target_frames = 0;
    uint32_t signatures_observed = 0;
    uint32_t transitions_observed = 0;
    uint32_t cells_assigned = 0;
    enum class State { Idle, Running, Checkpointing, Finalizing, Done, Failed };
    State state = State::Idle;
    std::string error_message;
};

// ---------------------------------------------------------------------------
// HeadlessPrePass
// ---------------------------------------------------------------------------
//
// Drives the pre-pass. The actual emulator driving (loading save state,
// replaying inputs, advancing frames) is delegated to a callback — this
// class is emulator-agnostic and testable without DuckStation.

class HeadlessPrePass {
public:
    using FrameAdvanceFn = std::function<bool(uint32_t frame)>;
    // Returns false to stop the pre-pass early (e.g. emulator error).

    HeadlessPrePass(const RSILConfig& cfg,
                    SignatureRegistry& sigs,
                    SpatialCatalog& catalog,
                    AdjacencyGraph& graph,
                    PersistenceManager& persistence);

    // Run the pre-pass. `advance_frame` is called once per frame; it
    // should advance the emulator by one frame and return true to
    // continue, false to abort. Between calls, RSIL's telemetry sinks
    // will have populated the registry/catalog/graph.
    //
    // Returns true on successful completion, false on error.
    bool run(const PrePassConfig& pcfg, FrameAdvanceFn advance_frame);

    // Query progress (callable from another thread).
    PrePassProgress progress() const;

    // Request early termination. The run() loop will exit at the next
    // frame boundary and save whatever it has collected.
    void request_stop();

private:
    void update_progress();
    bool checkpoint(uint32_t frame);

    const RSILConfig&   cfg_;
    SignatureRegistry&  sigs_;
    SpatialCatalog&     catalog_;
    AdjacencyGraph&     graph_;
    PersistenceManager& persistence_;

    // PrePassProgress contains a std::string, so it's not trivially
    // copyable and can't be used with std::atomic. Use a mutex instead.
    mutable std::mutex  progress_mu_;
    PrePassProgress     progress_;
    std::atomic<bool>   stop_requested_{false};
};

// ---------------------------------------------------------------------------
// CachePrimer
// ---------------------------------------------------------------------------
//
// On a normal (non-pre-pass) launch, the CachePrimer loads the pre-pass
// cache into the live RSILSubsystem. If the cache is fresh (matching the
// current executable signature), the predictor and host pre-registrar
// start with a saturated graph and full signature vocabulary.

class CachePrimer {
public:
    CachePrimer(SignatureRegistry& sigs,
                SpatialCatalog& catalog,
                AdjacencyGraph& graph,
                PersistenceManager& persistence)
        : sigs_(sigs), catalog_(catalog), graph_(graph),
          persistence_(persistence) {}

    // Load the cache for the current executable. Returns true if a
    // matching cache was found and loaded.
    bool prime();

    // Check whether a cache exists for the current executable without
    // loading it. Used to decide whether to prompt the user to run a
    // pre-pass.
    bool has_cache() const;

    // Cache metadata for display in the overlay.
    struct CacheInfo {
        bool present = false;
        std::chrono::system_clock::time_point created;
        uint32_t signature_count = 0;
        uint32_t edge_count = 0;
        uint32_t cell_count = 0;
        std::string exe_display_name;
    };
    CacheInfo info() const;

private:
    SignatureRegistry&  sigs_;
    SpatialCatalog&     catalog_;
    AdjacencyGraph&     graph_;
    PersistenceManager& persistence_;
};

}  // namespace rsil
