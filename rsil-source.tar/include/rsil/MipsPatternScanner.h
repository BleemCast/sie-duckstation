// SPDX-License-Identifier: BSD-3-Clause
// RSIL — MIPS R3000A pattern scanner.
//
// The in-process equivalent of tools/wipeout_scanner.py. Scans the
// loaded PS-X EXE for draw-distance culling instruction patterns and
// produces PatchManifest entries that feed directly into ScenePatchLayer.
//
// This is the "Cemu shader cache build" pass for culling discovery:
//   - First boot of a new game: scan takes ~50-200ms on modern CPUs.
//   - Subsequent boots: results loaded from the RSIL SQLite cache.
//   - Discovered patches are available immediately in Enhanced Mode.
//
// The scanner finds 6 categories of culling patterns:
//   P1: slti/sltiu + branch (integer compare)
//   P2: subu/sub + bltz/bgez (subtraction compare)
//   P3: addiu + bltz/bgez (add-negative compare)
//   P4: c.le.s/c.lt.s + bc1t/bc1f (float compare) — manual investigation
//   P5: cfc2 + andi + bne/beq (GTE flag check) — manual investigation
//   P6: sltu + branch (unsigned range check)
//
// P1/P2/P3/P6 are auto-patchable (immediate replaced with 32767).
// P4/P5 are reported but not auto-patched (need different approach).

#pragma once

#include "rsil/Types.h"
#include "rsil/ScenePatchLayer.h"

#include <cstdint>
#include <string>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// MIPS instruction field extraction
// ---------------------------------------------------------------------------

namespace mips {

inline uint32_t bits(uint32_t word, int hi, int lo) {
    return (word >> lo) & ((1u << (hi - lo + 1)) - 1u);
}

inline int32_t sign_extend_16(uint32_t val) {
    if (val & 0x8000u) return static_cast<int32_t>(val | 0xFFFF0000u);
    return static_cast<int32_t>(val);
}

// Opcodes (bits 31-26)
constexpr uint32_t OP_SPECIAL = 0x00;
constexpr uint32_t OP_REGIMM  = 0x01;
constexpr uint32_t OP_J       = 0x02;
constexpr uint32_t OP_JAL     = 0x03;
constexpr uint32_t OP_BEQ     = 0x04;
constexpr uint32_t OP_BNE     = 0x05;
constexpr uint32_t OP_BLEZ    = 0x06;
constexpr uint32_t OP_BGTZ    = 0x07;
constexpr uint32_t OP_ADDI    = 0x08;
constexpr uint32_t OP_ADDIU   = 0x09;
constexpr uint32_t OP_SLTI    = 0x0A;
constexpr uint32_t OP_SLTIU   = 0x0B;
constexpr uint32_t OP_ANDI    = 0x0C;
constexpr uint32_t OP_ORI     = 0x0D;
constexpr uint32_t OP_LUI     = 0x0F;
constexpr uint32_t OP_COP1    = 0x11;
constexpr uint32_t OP_COP2    = 0x12;  // GTE coprocessor ops (mfc2, cfc2, etc.)
constexpr uint32_t OP_LW      = 0x23;
constexpr uint32_t OP_SW      = 0x2B;
// NOTE: lwc2 (op=0x32) loads FROM memory TO GTE — it is a GTE WRITE,
// not a read. Only mfc2 (op=0x12, rs=0x00) and cfc2 (op=0x12, rs=0x02)
// read FROM GTE to CPU registers. Do NOT treat lwc2 as a GTE read.

// SPECIAL funct codes (bits 5-0)
constexpr uint32_t F_SUB  = 0x22;
constexpr uint32_t F_SUBU = 0x23;
constexpr uint32_t F_SLT  = 0x2A;
constexpr uint32_t F_SLTU = 0x2B;

// REGIMM rt codes (bits 20-16)
constexpr uint32_t RT_BLTZ = 0x00;
constexpr uint32_t RT_BGEZ = 0x01;

}  // namespace mips

// ---------------------------------------------------------------------------
// Scan candidate
// ---------------------------------------------------------------------------

struct ScanCandidate {
    std::string pattern;       // "P1-slti", "P2-subu+bltz", etc.
    uint32_t    address = 0;   // virtual address in PS1 RAM
    int32_t     value = 0;     // the comparison threshold
    std::string disasm;        // human-readable disassembly
    std::string branch_type;   // "beq", "bltz", "bc1t", etc.
    uint32_t    word_offset = 0; // offset into the code buffer
    uint32_t    patch_word = 0; // the patched instruction word (0 = not auto-patchable)
    bool        auto_patchable = false;

    // AOB pattern bytes (the original 4 bytes of the instruction).
    std::array<uint8_t, 4> orig_bytes = {};
    std::array<uint8_t, 4> patch_bytes = {};
};

// ---------------------------------------------------------------------------
// PS-X EXE info
// ---------------------------------------------------------------------------

struct PsxExeInfo {
    uint32_t text_addr = 0;
    uint32_t text_size = 0;
    uint32_t initial_pc = 0;
    std::vector<uint8_t> code;  // the text section
};

// Find and parse the PS-X EXE header in a raw disc/RAM image.
// Returns false if no PS-X EXE magic is found.
bool parse_psx_exe(const uint8_t* data, size_t size, PsxExeInfo& out);

// ---------------------------------------------------------------------------
// MipsPatternScanner
// ---------------------------------------------------------------------------

class MipsPatternScanner {
public:
    MipsPatternScanner();

    // Set the value range to search (default: 50-1000).
    void set_value_range(int32_t min_val, int32_t max_val) {
        min_val_ = min_val;
        max_val_ = max_val;
    }

    // Enable float-compare scanning (P4). Off by default.
    void set_scan_floats(bool enabled) { scan_floats_ = enabled; }

    // Scan the given code buffer. Returns all candidates found.
    std::vector<ScanCandidate> scan(const PsxExeInfo& exe) const;

    // Convert candidates to a PatchManifest for ScenePatchLayer.
    // Only auto-patchable candidates (P1/P2/P3/P6) are included.
    PatchManifest to_manifest(const std::vector<ScanCandidate>& candidates,
                              const ExecutableSignature& exe_sig,
                              const std::string& display_name) const;

    // Stats from the last scan.
    struct Stats {
        uint32_t total_candidates = 0;
        uint32_t auto_patchable = 0;
        uint32_t float_candidates = 0;
        uint32_t gte_candidates = 0;
        uint64_t scan_time_us = 0;  // microseconds
    };
    const Stats& stats() const { return stats_; }

private:
    // Individual pattern detectors.
    void scan_pattern_1(const std::vector<uint8_t>& code, uint32_t text_addr,
                        std::vector<ScanCandidate>& out) const;
    void scan_pattern_2(const std::vector<uint8_t>& code, uint32_t text_addr,
                        std::vector<ScanCandidate>& out) const;
    void scan_pattern_3(const std::vector<uint8_t>& code, uint32_t text_addr,
                        std::vector<ScanCandidate>& out) const;
    void scan_pattern_4(const std::vector<uint8_t>& code, uint32_t text_addr,
                        std::vector<ScanCandidate>& out) const;
    void scan_pattern_5(const std::vector<uint8_t>& code, uint32_t text_addr,
                        std::vector<ScanCandidate>& out) const;
    void scan_pattern_6(const std::vector<uint8_t>& code, uint32_t text_addr,
                        std::vector<ScanCandidate>& out) const;

    // Helper: check if there's a conditional branch within max_dist instructions.
    bool check_branch_within(const std::vector<uint8_t>& code, size_t offset,
                             int max_dist, std::string& br_type, int& br_dist) const;

    int32_t min_val_ = 50;
    int32_t max_val_ = 1000;
    bool    scan_floats_ = false;
    mutable Stats stats_;
};

}  // namespace rsil
