// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Host-side pre-registration manager.
//
// Stage 5 of the RSIL pipeline. Translates PreRegistrationRequest objects
// into HostAdapter calls, manages the active pre-registration slot pool,
// and applies the max_active_preregs cap with LRU eviction by confidence.
//
// The manager is the single chokepoint between RSIL and the host GPU.
// All side effects on the host are issued from here, which makes the
// subsystem trivially disable-able: when FeatureFlags::preregister is
// false, on_request() becomes a no-op.

#pragma once

#include "rsil/Types.h"
#include "rsil/Config.h"

#include <chrono>
#include <unordered_map>
#include <vector>

namespace rsil {

class HostAdapter;

class HostPreRegistrar {
public:
    HostPreRegistrar(const RSILConfig& cfg, HostAdapter& host)
        : cfg_(cfg), host_(host) {}

    // Issue a batch of pre-registration requests. Idempotent: if a
    // request for the same signature is already active, it is refreshed
    // (no duplicate host call) and its confidence is updated.
    void on_requests(const std::vector<PreRegistrationRequest>& reqs,
                     FrameId frame);

    // Evict any active pre-registration whose host token has been
    // invalidated by the host (rare; e.g. VRAM pressure event).
    void on_host_eviction(HostPreRegToken token);

    // Periodic GC. Called once per frame. Evicts slots whose confidence
    // has decayed below a low-water mark.
    void gc(FrameId frame);

    // Stats for the overlay.
    struct Stats {
        uint32_t active_slots = 0;
        uint64_t total_issued = 0;
        uint64_t total_evicted = 0;
        uint64_t priority_elevations = 0;
    };
    const Stats& stats() const { return stats_; }

private:
    struct ActiveSlot {
        ClusterSignatureId signature = kInvalidSignature;
        HostPreRegToken    token = kInvalidToken;
        TransitionConfidence confidence = 0.0f;
        FrameId last_refreshed = 0;
    };

    const RSILConfig& cfg_;
    HostAdapter&      host_;
    std::unordered_map<ClusterSignatureId, ActiveSlot> active_;
    Stats             stats_;
};

}  // namespace rsil
