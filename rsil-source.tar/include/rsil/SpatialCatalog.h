// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Spatial catalog.
//
// Stage 3 of the RSIL pipeline. Builds a dynamic, cache-coherent spatial
// map of cluster signatures. Signatures are placed next to their inferred
// neighbors based on relative bounding-box edge deltas — NOT absolute
// world coordinates.
//
// The catalog is hierarchical:
//   Track > Sector > Visibility Cell > Cluster Signature
//
// Each level is identified by a stable ID. Cells and sectors are assigned
// lazily based on transition patterns observed in the AdjacencyGraph
// (see AdjacencyGraph.h).

#pragma once

#include "rsil/Types.h"
#include "rsil/ClusterSignature.h"

#include <optional>
#include <unordered_map>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// CatalogNode
// ---------------------------------------------------------------------------

struct CatalogNode {
    ClusterSignatureId signature = kInvalidSignature;
    CellId             cell      = kInvalidCell;
    SectorId           sector    = kInvalidSector;
    TrackId            track     = kInvalidTrack;

    // Logical neighbor list (signatures observed adjacent in submission
    // order with high confidence). Used to feed the host frustum culler.
    std::vector<ClusterSignatureId> neighbors;

    // Lifetime statistics (metadata only).
    uint32_t observation_count = 0;
    FrameId  first_seen = 0;
    FrameId  last_seen  = 0;

    // Relative edge delta to the previously-observed neighbor in submission
    // order. Used for spatial sorting. NOT an absolute coordinate.
    std::array<int16_t, 3> relative_delta = {0, 0, 0};
};

// ---------------------------------------------------------------------------
// SpatialCatalog
// ---------------------------------------------------------------------------

class SpatialCatalog {
public:
    // Register a cluster signature and return its catalog node. If new,
    // the node is placed next to the most-recently-observed neighbor
    // (inferred from `previous_signature`).
    CatalogNode& register_cluster(ClusterSignatureId sig,
                                  ClusterSignatureId previous_signature,
                                  FrameId frame);

    // Promote a cluster into a specific cell. Cells are typically assigned
    // by the AdjacencyGraph when it detects a stable repeating subsequence.
    void assign_cell(ClusterSignatureId sig, CellId cell);

    // Promote a cell to a sector (and a sector to a track) when enough
    // of its members co-occur.
    void assign_sector(CellId cell, SectorId sector);
    void assign_track(SectorId sector, TrackId track);

    // Lookup.
    const CatalogNode* find(ClusterSignatureId sig) const;
    CatalogNode*       find_mut(ClusterSignatureId sig);

    // All clusters known to belong to a cell / sector / track.
    std::vector<ClusterSignatureId> clusters_in_cell(CellId c) const;
    std::vector<ClusterSignatureId> clusters_in_sector(SectorId s) const;

    // Direct neighbors of a cluster (for culler feed).
    std::vector<ClusterSignatureId> neighbors_of(ClusterSignatureId sig) const;

    // Sorted catalog feed: returns signatures in their catalog order (cell
    // then submission order). This is what the host frustum culler consumes
    // to skip per-frame reorder cost.
    std::vector<ClusterSignatureId> sorted_feed() const;

    // Snapshot / restore for persistence.
    struct Snapshot {
        std::vector<CatalogNode> nodes;
        CellId   next_cell_id   = 1;
        SectorId next_sector_id = 1;
        TrackId  next_track_id  = 1;
    };
    Snapshot  snapshot() const;
    void      restore(const Snapshot& s);

    // Allocate next IDs (used internally and by graph for sector inference).
    CellId   allocate_cell()   { return next_cell_id_++; }
    SectorId allocate_sector() { return next_sector_id_++; }
    TrackId  allocate_track()  { return next_track_id_++; }

    void clear();

private:
    std::unordered_map<ClusterSignatureId, CatalogNode> nodes_;
    CellId   next_cell_id_   = 1;
    SectorId next_sector_id_ = 1;
    TrackId  next_track_id_  = 1;
};

}  // namespace rsil
