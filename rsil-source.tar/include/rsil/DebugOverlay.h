// SPDX-License-Identifier: BSD-3-Clause
// RSIL — ImGui debug overlay.
//
// Stage 8 of the RSIL pipeline. Visualizes the adjacency graph, cluster
// signatures, spatial catalog, pre-registration slots, and validator
// status. Renders through DuckStation's existing ImGui pass.
//
// All draw calls are guarded by FeatureFlags::overlay. When the flag is
// false, draw() is a no-op.

#pragma once

#include "rsil/Types.h"
#include "rsil/Config.h"
#include "rsil/ClusterSignature.h"
#include "rsil/SpatialCatalog.h"
#include "rsil/AdjacencyGraph.h"
#include "rsil/Predictor.h"
#include "rsil/HostPreRegistrar.h"
#include "rsil/Validator.h"

namespace rsil {

class DebugOverlay {
public:
    DebugOverlay(const RSILConfig& cfg,
                 const SignatureRegistry& sigs,
                 const SpatialCatalog&    catalog,
                 const AdjacencyGraph&    graph,
                 const Predictor&         predictor,
                 const HostPreRegistrar&  prereg,
                 const Validator*         validator)
        : cfg_(cfg), sigs_(sigs), catalog_(catalog), graph_(graph),
          predictor_(predictor), prereg_(prereg), validator_(validator) {}

    // Called from the host's ImGui pass. No-op if overlay disabled.
    void draw();

    // Toggles for sub-panels (set from ImGui menu or config).
    bool show_graph_panel       = true;
    bool show_catalog_panel     = true;
    bool show_predictor_panel   = true;
    bool show_prereg_panel      = true;
    bool show_validator_panel   = true;
    bool show_telemetry_panel   = true;

private:
    void draw_graph_panel();
    void draw_catalog_panel();
    void draw_predictor_panel();
    void draw_prereg_panel();
    void draw_validator_panel();
    void draw_telemetry_panel();

    const RSILConfig&         cfg_;
    const SignatureRegistry&  sigs_;
    const SpatialCatalog&     catalog_;
    const AdjacencyGraph&     graph_;
    const Predictor&          predictor_;
    const HostPreRegistrar&   prereg_;
    const Validator*          validator_;

    // Throttle: only refresh internal snapshots at overlay_refresh_hz.
    uint32_t last_refresh_frame_ = 0;
};

}  // namespace rsil
