// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Cluster signature & primitive clustering.
//
// Stage 2 of the RSIL pipeline. Groups consecutive primitives sharing
// identical Texpage, CLUT and attributes into ClusterEvents, and derives
// a stable, non-reversible ClusterSignatureId from metadata only.
//
// IRREVERSIBILITY CONTRACT
// ------------------------
// The signature is computed from:
//   - primitive topology
//   - vertex count
//   - texpage / clut identifiers
//   - rendering attributes (textured, gouraud, blended, lit)
//   - normalized relative bounding-box deltas (quantized int16)
//
// Normalization: bbox deltas are computed as (v - centroid) / max_axis_extent
// and then quantized. The original absolute coordinates CANNOT be recovered
// from the signature. This is by design: it permits persisting signatures
// across sessions without retaining copyrighted mesh data.

#pragma once

#include "rsil/Types.h"

#include <array>
#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <unordered_map>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// PrimitiveClusterer
// ---------------------------------------------------------------------------
//
// Consumes PrimitiveObservation stream and emits ClusterEvents. A new
// ClusterEvent is started whenever:
//   - the Texpage/CLUT/attributes change, OR
//   - the topology changes, OR
//   - a frame boundary is crossed.
//
// Vertex deltas within a cluster are aggregated into a single
// NormalizedBBox describing the cluster's relative shape.

class PrimitiveClusterer {
public:
    // Begin a new frame. Closes any in-flight cluster.
    void begin_frame(FrameId frame);

    // Push a primitive observation. May emit zero or one ClusterEvents.
    // Returns a non-null pointer if a cluster was just closed.
    const ClusterEvent* push_primitive(const PrimitiveObservation& obs);

    // Close the current cluster (e.g. at frame end).
    const ClusterEvent* flush();

    // Read-only access to the last-emitted cluster event (for telemetry).
    const ClusterEvent* last_event() const { return last_event_.get(); }

private:
    void close_current();

    FrameId current_frame_ = 0;
    bool    in_cluster_ = false;
    ClusterEvent pending_;

    // Aggregation state for the in-flight cluster.
    std::array<int32_t, 3> bbox_min_{0, 0, 0};
    std::array<int32_t, 3> bbox_max_{0, 0, 0};
    uint32_t vertex_count_accum_ = 0;
    uint32_t primitive_count_accum_ = 0;

    std::shared_ptr<ClusterEvent> last_event_;
};

// ---------------------------------------------------------------------------
// ClusterSignatureBuilder
// ---------------------------------------------------------------------------
//
// Deterministic 64-bit FNV-1a over the metadata fields above. The hash
// is intentionally simple and reproducible across runs; cryptographic
// strength is not required, only collision-resistance within a single
// game's primitive vocabulary (typically <10^6 distinct clusters).

class ClusterSignatureBuilder {
public:
    ClusterSignatureBuilder() = default;

    void add_topology(PrimitiveTopology t);
    void add_vertex_count(uint16_t n);
    void add_attributes(const PrimitiveAttributes& a);
    void add_bbox(const NormalizedBBox& b);

    // Finalize and reset. Returns the 64-bit signature.
    ClusterSignatureId finalize();

private:
    void add_bytes(const void* data, size_t n);

    uint64_t hash_ = 0xcbf29ce484222325ULL;  // FNV-1a 64-bit basis
};

// Convenience: compute the signature for an already-formed cluster event.
ClusterSignatureId compute_signature(const ClusterEvent& ev);

// ---------------------------------------------------------------------------
// SignatureRegistry
// ---------------------------------------------------------------------------
//
// Maps signature -> stable ClusterSignatureId and counts occurrences.
// Two clusters with identical metadata collapse to the same ID, which is
// the foundation of the Markov transition graph.

struct SignatureEntry {
    ClusterSignatureId id = kInvalidSignature;
    PrimitiveTopology  topology = PrimitiveTopology::Unknown;
    uint16_t           vertex_count = 0;
    PrimitiveAttributes attrs;
    NormalizedBBox     bbox;
    uint32_t           observation_count = 0;
    // First frame and last frame this signature was seen.
    FrameId first_frame = 0;
    FrameId last_frame  = 0;
};

class SignatureRegistry {
public:
    // Returns the canonical ID for the cluster, creating a new entry if
    // necessary. Bumps observation_count.
    ClusterSignatureId register_event(const ClusterEvent& ev);

    const SignatureEntry* lookup(ClusterSignatureId id) const;

    // Snapshot for persistence. Order is unspecified.
    std::vector<SignatureEntry> snapshot() const;

    // D13 fix: restore from a snapshot (inverse of snapshot()).
    void restore(const std::vector<SignatureEntry>& entries);

    void clear();

private:
    std::unordered_map<ClusterSignatureId, SignatureEntry> entries_;
};

}  // namespace rsil
