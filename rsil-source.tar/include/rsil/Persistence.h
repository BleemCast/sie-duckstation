// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Persistence layer.
//
// Stage 6 of the RSIL pipeline. Serializes the adjacency graph, cluster
// signatures, and spatial catalog to an external metadata-only cache,
// keyed by the game executable's MD5/CRC32 signature.
//
// STRICT CONSTRAINT: This layer MUST NOT persist:
//   - meshes, textures, vertex coordinates
//   - VRAM dumps, RAM dumps
//   - historical GPU command buffers
//
// Only metadata (signatures, edges, catalog nodes, stats) is stored.
//
// The default backend is SQLite; a JSON backend is provided for debugging
// and export. Backends are pluggable via the PersistenceBackend interface.

#pragma once

#include "rsil/Types.h"
#include "rsil/ClusterSignature.h"
#include "rsil/SpatialCatalog.h"
#include "rsil/AdjacencyGraph.h"

#include <filesystem>
#include <memory>
#include <string>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// PersistenceBackend
// ---------------------------------------------------------------------------

class PersistenceBackend {
public:
    virtual ~PersistenceBackend() = default;

    virtual bool open(const std::filesystem::path& path) = 0;
    virtual void close() = 0;

    // Save all state for a given executable signature. Atomic per call;
    // implementations should transactionally replace any prior entry.
    virtual bool save(const ExecutableSignature& exe,
                      const SignatureRegistry&  sigs,
                      const SpatialCatalog&     catalog,
                      const AdjacencyGraph&     graph) = 0;

    // Load state for a given executable signature. Returns false if no
    // entry exists.
    virtual bool load(const ExecutableSignature& exe,
                      SignatureRegistry&  sigs,
                      SpatialCatalog&     catalog,
                      AdjacencyGraph&     graph) = 0;

    // List all known executable signatures in the cache (for the overlay).
    virtual std::vector<ExecutableSignature> list_executables() = 0;
};

// SQLite backend (default). Depends on sqlite3.
std::unique_ptr<PersistenceBackend> make_sqlite_backend();

// JSON backend (debugging / export). Writes a single JSON file per exe.
std::unique_ptr<PersistenceBackend> make_json_backend(
    const std::filesystem::path& dir);

// ---------------------------------------------------------------------------
// PersistenceManager
// ---------------------------------------------------------------------------
//
// Owns the backend and provides a high-level save/load API. The manager
// is responsible for:
//   - Throttling saves (no more than once every N seconds unless forced).
//   - Coalescing concurrent save requests.
//   - Handing off load operations to a worker thread to avoid blocking
//     the GPU thread on first-run cache misses.

class PersistenceManager {
public:
    PersistenceManager(std::unique_ptr<PersistenceBackend> backend,
                       const ExecutableSignature& exe);

    // Asynchronous save (returns immediately; persists on worker thread).
    void save_async(const SignatureRegistry& sigs,
                    const SpatialCatalog&    catalog,
                    const AdjacencyGraph&    graph);

    // Synchronous save. Blocks until persistence is complete.
    bool save_sync(const SignatureRegistry& sigs,
                   const SpatialCatalog&    catalog,
                   const AdjacencyGraph&    graph);

    // Synchronous load. Called once at startup; subsequent calls are no-ops
    // if the cache was already loaded for this exe.
    bool load(SignatureRegistry& sigs,
              SpatialCatalog&    catalog,
              AdjacencyGraph&    graph);

    bool has_loaded() const { return loaded_; }

private:
    std::unique_ptr<PersistenceBackend> backend_;
    ExecutableSignature exe_;
    bool loaded_ = false;
};

}  // namespace rsil
