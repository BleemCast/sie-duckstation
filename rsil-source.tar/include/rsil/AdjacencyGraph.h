// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Adjacency graph & Markov model.
//
// Stage 3b/4 of the RSIL pipeline. Maintains a directed graph of
// ClusterSignature transitions and computes per-edge confidence using a
// decaying weighted moving average (WMA).
//
// The graph is the substrate for the look-ahead predictor. Each node is
// a ClusterSignatureId; each edge carries:
//   - observed_count (raw frequency)
//   - confidence     (decaying WMA in [0,1])
//
// Confidence update formula (on each observed transition from->to):
//   confidence = decay * confidence + (1 - decay) * indicator(to == actual_next)
// where `decay` is RSILConfig::transition_decay.
//
// This formulation rewards recency: a transition that was frequent in the
// past but has stopped occurring will gradually decay toward 0, allowing
// the predictor to adapt to scene-graph changes mid-race (e.g. entering
// a tunnel).

#pragma once

#include "rsil/Types.h"

#include <optional>
#include <unordered_map>
#include <vector>

namespace rsil {

struct AdjacencyEdge {
    ClusterSignatureId from = kInvalidSignature;
    ClusterSignatureId to   = kInvalidSignature;
    uint32_t           observed_count = 0;
    TransitionConfidence confidence = 0.0f;
    // Last frame this edge was traversed.
    FrameId last_traversed = 0;
};

class AdjacencyGraph {
public:
    explicit AdjacencyGraph(float decay = 0.95f,
                            uint32_t min_observations = 3)
        : decay_(decay), min_observations_(min_observations) {}

    // Record an observed transition. `actual_next` is the cluster signature
    // that *actually* followed `from` in this frame. ALL previously-tracked
    // candidate successors of `from` have their confidence updated:
    //   - The matching candidate gets +indicator boost.
    //   - All others get decayed.
    void observe_transition(ClusterSignatureId from,
                            ClusterSignatureId actual_next,
                            FrameId frame);

    // Returns the top-N candidate successors of `from` sorted by confidence
    // descending. Only edges with observed_count >= min_observations_ are
    // considered.
    std::vector<AdjacencyEdge> top_successors(ClusterSignatureId from,
                                              size_t top_n) const;

    // Returns the single highest-confidence successor (or empty optional).
    std::optional<AdjacencyEdge> best_successor(ClusterSignatureId from) const;

    // Snapshot for persistence.
    std::vector<AdjacencyEdge> snapshot() const;
    void restore(const std::vector<AdjacencyEdge>& edges);

    // Stats.
    size_t node_count() const  { return nodes_.size(); }
    size_t edge_count() const;

    void clear();

private:
    struct EdgeMap {
        std::unordered_map<ClusterSignatureId, AdjacencyEdge> out_edges;
    };

    std::unordered_map<ClusterSignatureId, EdgeMap> nodes_;
    float     decay_;
    uint32_t  min_observations_;
};

}  // namespace rsil
