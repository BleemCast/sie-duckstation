// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Deterministic validator.
//
// Stage 7 of the RSIL pipeline. Proves zero emulation divergence when
// RSIL is enabled by hashing emulated RAM, VRAM, CPU registers, and the
// GPU command stream on a sampled cadence.
//
// Two hash chains are maintained:
//   - baseline: hashes computed with RSIL fully disabled.
//   - rsil:     hashes computed with RSIL fully enabled.
//
// The two chains MUST be byte-identical. Any divergence is a critical
// bug and should fail loudly.
//
// SAMPLING
// --------
// Hashing every frame is expensive. Default sample rate is every frame
// (validator_sample_rate = 1). For long-running sessions, raise the rate
// to e.g. 60 (once per second @60fps).

#pragma once

#include "rsil/Types.h"
#include "rsil/Config.h"

#include <array>
#include <cstdint>
#include <deque>
#include <string>

namespace rsil {

// Hash provider interface. DuckStation supplies a concrete impl that
// reads CPU registers, RAM, VRAM, and the GPU command stream.
class HashProvider {
public:
    virtual ~HashProvider() = default;

    virtual std::array<uint8_t, 16> hash_cpu_registers() = 0;
    virtual std::array<uint8_t, 16> hash_ram() = 0;
    virtual std::array<uint8_t, 16> hash_vram() = 0;
    virtual std::array<uint8_t, 16> hash_gpu_command_stream() = 0;
};

// One frame's hash record.
struct FrameHash {
    FrameId frame = 0;
    std::array<uint8_t, 16> cpu_regs = {};
    std::array<uint8_t, 16> ram      = {};
    std::array<uint8_t, 16> vram     = {};
    std::array<uint8_t, 16> gpu_cmds = {};
};

// Hash chain comparison result.
struct DivergenceReport {
    bool    divergent = false;
    FrameId first_divergent_frame = 0;
    enum class Channel { CpuRegs, Ram, Vram, GpuCmds } channel = Channel::CpuRegs;
    std::array<uint8_t, 16> baseline_hash = {};
    std::array<uint8_t, 16> rsil_hash     = {};
};

class Validator {
public:
    Validator(const RSILConfig& cfg, HashProvider& provider)
        : cfg_(cfg), provider_(provider) {}

    // Sample one frame. Called from the GPU thread at VSync.
    void sample(FrameId frame);

    // Compare against the baseline chain. The baseline must have been
    // recorded in a prior session with RSIL fully disabled.
    DivergenceReport compare(const std::deque<FrameHash>& baseline) const;

    // Access the current chain (for save/load to compare across sessions).
    const std::deque<FrameHash>& chain() const { return chain_; }
    std::deque<FrameHash>&       chain_mut()   { return chain_; }

    // Stats for the overlay.
    struct Stats {
        uint64_t samples_taken = 0;
        uint64_t divergences_detected = 0;
    };
    const Stats& stats() const { return stats_; }

private:
    const RSILConfig& cfg_;
    HashProvider&     provider_;
    std::deque<FrameHash> chain_;
    Stats             stats_;
};

}  // namespace rsil
