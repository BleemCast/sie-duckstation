// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Look-ahead predictor.
//
// Stage 4 of the RSIL pipeline. Consumes the latest observed cluster
// signature and the AdjacencyGraph, and emits PreRegistrationRequest
// objects for clusters with confidence above the configured threshold.
//
// The predictor is *one mechanism inside the visibility completion
// engine*, not the engine itself. It is intentionally simple:
//   1. Query the top-K successors from the adjacency graph.
//   2. For each successor above confidence threshold:
//      a. Look up its catalog node for cell/sector hint.
//      b. Emit a PreRegistrationRequest.
//
// The host adapter is free to ignore any request. Correctness does not
// depend on the host honoring requests.

#pragma once

#include "rsil/Types.h"
#include "rsil/Config.h"
#include "rsil/AdjacencyGraph.h"
#include "rsil/SpatialCatalog.h"

#include <functional>
#include <vector>

namespace rsil {

class Predictor {
public:
    Predictor(const RSILConfig& cfg,
              AdjacencyGraph& graph,
              SpatialCatalog& catalog,
              const SignatureRegistry& sigs)
        : cfg_(cfg), graph_(graph), catalog_(catalog), sigs_(sigs) {}

    // Called when a new cluster signature is observed. Returns the list
    // of pre-registration requests the host should fulfill.
    std::vector<PreRegistrationRequest> on_cluster_observed(
        ClusterSignatureId current,
        FrameId frame);

    // Optional: a second-pass predictor that uses the previous *N* clusters
    // as context (Markov order N). Default impl uses order 1; subclasses
    // may override for higher-order prediction.
    virtual std::vector<PreRegistrationRequest> predict_with_context(
        std::span<const ClusterSignatureId> history,
        FrameId frame);

    // Stats for the overlay.
    struct Stats {
        uint64_t total_predictions = 0;
        uint64_t hits = 0;         // predictions that subsequently fired
        uint64_t misses = 0;       // predictions that did not fire
        uint64_t evictions = 0;    // active preregs evicted by cap
    };
    const Stats& stats() const { return stats_; }

    // Called when the host confirms a predicted cluster actually rendered.
    void record_hit(ClusterSignatureId sig);
    // Called when a predicted cluster failed to render within lookahead.
    void record_miss(ClusterSignatureId sig);

private:
    const RSILConfig&         cfg_;
    AdjacencyGraph&           graph_;
    SpatialCatalog&           catalog_;
    const SignatureRegistry&  sigs_;
    Stats                     stats_;
};

}  // namespace rsil
