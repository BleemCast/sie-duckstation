// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Runtime configuration & host adapter interface.

#pragma once

#include "rsil/Types.h"

#include <filesystem>
#include <functional>
#include <string>

namespace rsil {

// ---------------------------------------------------------------------------
// Runtime configuration
// ---------------------------------------------------------------------------

struct RSILConfig {
    FeatureFlags flags;

    // Persistence database location. Empty => in-memory only.
    std::filesystem::path db_path = "rsil_cache.sqlite";

    // Look-ahead depth. 1 = next frame, 2 = 2-frame look-ahead.
    uint32_t lookahead_frames = 2;

    // Markov transition decay factor in [0.5, 1.0). Higher = slower decay,
    // longer memory. 0.95 is a sensible default for ~30s track loops.
    float transition_decay = 0.95f;

    // Minimum observations before a transition is considered "confident".
    uint32_t min_observations = 3;

    // Confidence threshold in [0,1] above which pre-registration fires.
    float prereg_confidence_threshold = 0.6f;

    // Maximum number of pre-registration slots live at any time. Beyond
    // this, lowest-confidence slots are evicted.
    uint32_t max_active_preregs = 64;

    // Validator hash sample rate. 1 = every frame, N = every Nth frame.
    uint32_t validator_sample_rate = 1;

    // Overlay refresh rate in Hz. 0 = render every frame.
    uint32_t overlay_refresh_hz = 30;

    // When true, the host adapter will receive priority-elevation requests.
    // Disable on platforms where thread priority hints are unsupported.
    bool host_priority_elevation_enabled = true;

    static RSILConfig defaults() { return {}; }
};

// ---------------------------------------------------------------------------
// Host adapter
// ---------------------------------------------------------------------------
//
// RSIL never touches host GPU APIs directly. All host-side effects
// (descriptor pre-allocation, shader pre-compile, frustum culler feed)
// are issued through this interface. DuckStation provides a concrete
// implementation wired to its Vulkan/GL/D3D backend.
//
// All methods are advisory: the host is free to no-op or evict. RSIL
// does not depend on the host honoring requests for correctness; the
// emulation result is identical either way.

class HostAdapter {
public:
    virtual ~HostAdapter() = default;

    // Pre-register a descriptor set + texture bindings matching the given
    // texpage/CLUT state. Returns a token, or kInvalidToken if declined.
    virtual HostPreRegToken preregister_descriptor(
        TexpageId texpage, ClutId clut, CellId hint_cell) = 0;

    // Pre-compile shader variant matching the given attribute mask.
    virtual void preregister_shader(const PrimitiveAttributes& attrs) = 0;

    // Pre-allocate a command buffer / pipeline state slot for the
    // predicted cluster signature. Advisory.
    virtual void preregister_pipeline(ClusterSignatureId sig) = 0;

    // Release a previously issued pre-registration token.
    virtual void release_preregistration(HostPreRegToken token) = 0;

    // Elevate host CPU thread priority for the next N microseconds.
    // Implementations should clamp to a sensible cap and never actually
    // starve other threads; this is a hint to the OS scheduler.
    virtual void elevate_priority(uint32_t microseconds) = 0;

    // Feed the host-side frustum culler with a logical neighbor list for
    // the given cell. The culler may use this to skip per-frame reorder.
    virtual void feed_culler(CellId cell,
                             const std::vector<CellId>& neighbors) = 0;

    // ImGui draw hook (called from the host's debug UI pass when overlay
    // is enabled). Implementations must be safe to call from the render
    // thread.
    virtual void draw_overlay() = 0;
};

// Null host adapter: does nothing. Used when RSIL is disabled or when
// running headless tests.
class NullHostAdapter final : public HostAdapter {
public:
    HostPreRegToken preregister_descriptor(TexpageId, ClutId, CellId) override {
        return kInvalidToken;
    }
    void preregister_shader(const PrimitiveAttributes&) override {}
    void preregister_pipeline(ClusterSignatureId) override {}
    void release_preregistration(HostPreRegToken) override {}
    void elevate_priority(uint32_t) override {}
    void feed_culler(CellId, const std::vector<CellId>&) override {}
    void draw_overlay() override {}
};

}  // namespace rsil
