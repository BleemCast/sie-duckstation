// SPDX-License-Identifier: BSD-3-Clause
// RSIL — PS1 GPU packet parser.
//
// Stateful parser that accumulates GP0 FIFO words and emits complete
// PrimitiveObservation objects with ALL metadata populated:
//   - topology (polygon / line / rectangle)
//   - vertex count
//   - texpage (from embedded texcoord word or default from GP0(0xE1))
//   - clut (from embedded CLUT base in the first texcoord word)
//   - attributes (textured, gouraud, translucent, quad)
//   - normalized bbox (from vertex coordinates)
//
// PS1 GP0 COMMAND ENCODING
// ------------------------
// The command byte (low byte of the first word) determines the packet
// type and length:
//
//   0x20-0x3F: Polygon
//     bit 0 (0x01): Translucent
//     bit 2 (0x04): Textured
//     bit 3 (0x08): Gouraud
//     bit 4 (0x10): Quad (4 vertices) vs Triangle (3 vertices)
//
//   0x40-0x5F: Line
//     bit 0 (0x01): Translucent
//     bit 3 (0x08): Gouraud
//     bit 4 (0x10): Polyline (variable length)
//
//   0x60-0x7F: Rectangle (sprite)
//     bit 0 (0x01): Translucent
//     bit 2 (0x04): Textured
//     bits 5-6: Size (0=variable, 1=1x1, 2=8x8, 3=16x16)
//
//   0xA0: VRAM write (image transfer)
//   0xC0: VRAM read
//   0xE1: Set texpage (default texpage for subsequent primitives)
//   0xE2-0xE6: Other render state
//
// TEXTURE PAGE / CLUT EMBEDDING
// -----------------------------
// Textured primitives carry their texpage and CLUT in the texcoord
// words, NOT in a separate 0xE1 command:
//
//   First texcoord word (after the first vertex):
//     bits 0-7:   U coordinate
//     bits 8-15:  V coordinate
//     bits 16-31: CLUT base index
//       bits 16-21: CLUT X (0, 16, 32, ... in steps of 16)
//       bits 22-26: CLUT Y (0, 256, 512, ... in steps of 16... actually
//                    bits 22-31 is a packed field, but for RSIL we
//                    treat it as an opaque 16-bit CLUT identifier)
//
//   Second texcoord word (after the second vertex):
//     bits 0-7:   U coordinate
//     bits 8-15:  V coordinate
//     bits 16-31: Texpage
//       bits 16-19: TP X (0, 16, 32, ... in steps of 64)
//       bit 20:     TP Y (0 or 256)
//       bits 21-22: Transparency mode (0=off, 1-3=blend modes)
//       bits 23-24: Color depth (0=4bit, 1=8bit, 2=15bit)
//
// RSIL extracts the raw 16-bit texpage and CLUT fields as opaque
// identifiers. We do NOT interpret the bit fields — the host adapter
// receives the raw values and maps them to its own descriptor/shader
// keys.

#pragma once

#include "rsil/Types.h"

#include <array>
#include <cstdint>
#include <functional>
#include <vector>

namespace rsil {

// ---------------------------------------------------------------------------
// GpuPacketParser
// ---------------------------------------------------------------------------

class GpuPacketParser {
public:
    GpuPacketParser();

    // Callback invoked when a complete primitive packet has been parsed.
    // The PrimitiveObservation will have ALL fields populated.
    std::function<void(const PrimitiveObservation&)> on_primitive;

    // Feed one GP0 word. The parser accumulates words until a complete
    // packet is formed, then calls on_primitive.
    //
    // `word` is the raw 32-bit value written to GP0.
    // `frame` is the current frame ID (passed through to the observation).
    void on_word(uint32_t word, FrameId frame);

    // Reset parser state (e.g. at frame boundary, or after a desync).
    void reset();

    // Access the current default texpage (set by GP0(0xE1)).
    // Exposed for the overlay/debug layer.
    TexpageId current_texpage() const { return current_texpage_; }

    // Stats for the overlay.
    struct Stats {
        uint32_t packets_parsed = 0;
        uint32_t primitives_emitted = 0;
        uint32_t words_consumed = 0;
        uint32_t desyncs = 0;  // times the parser had to resync
    };
    const Stats& stats() const { return stats_; }

    // Compute normalized bbox from a list of vertex positions.
    // Normalization: subtract centroid, divide by max axis extent,
    // quantize to int16. Non-reversible.
    // PUBLIC: also used by RSILSubsystem::on_decoded_draw.
    static NormalizedBBox compute_normalized_bbox(
        const std::vector<std::array<int16_t, 2>>& vertices);

private:
    // Determine the number of words expected for a given command byte
    // (including the command word itself). Returns 0 for unknown commands.
    static uint32_t packet_length(uint8_t cmd);

    // Parse a complete accumulated packet into a PrimitiveObservation.
    void parse_packet(FrameId frame);

    // Extract texpage/CLUT from a texcoord word.
    static TexpageId extract_texpage(uint32_t texcoord_word);
    static ClutId    extract_clut(uint32_t texcoord_word);

    // Extract vertex X,Y from a vertex word.
    static std::array<int16_t, 2> extract_xy(uint32_t vertex_word);

    enum class State {
        Idle,           // waiting for a command word
        Accumulating,   // collecting data words for a known packet
        Syncing,        // recovering from a desync; skipping until next command
    };

    State   state_ = State::Idle;
    uint8_t pending_cmd_ = 0;
    uint32_t words_expected_ = 0;
    std::vector<uint32_t> packet_words_;

    // Default texpage set by GP0(0xE1). Used when a textured primitive
    // does not embed its own texpage (which is rare — most do).
    TexpageId current_texpage_ = 0;

    Stats stats_;
};

}  // namespace rsil
