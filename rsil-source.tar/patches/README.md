# RSIL Engine Patch Format

Per-game patch manifests for the RSIL Engine Patch Layer (Layer 4).
Combined with DuckStation's 8MB RAM mode, these patches inflate the
engine's streaming budget and LOD distances — the GT2 "big drawing
distance" technique.

## How patches work

Each patch is a byte-pattern substitution applied to the loaded game
executable in emulated RAM. The pattern is searched for at runtime
(signature-anchored, not address-anchored); when found, the matched
bytes are replaced. This makes patches portable across regional variants
(SCES/SCUS/SLUS/SLPS) and revisions.

## Manifest format

Each game has one JSON file in this directory, named by game title:

```
patches/
  wipeout_2097_sces00901.json
  ridge_racer_type4_sces01558.json
  nfs_high_stakes_slus00870.json
```

Schema:

```json
{
  "display_name": "Wipeout 2097 (SCES-00901)",
  "exe_md5": "abcdef0123456789abcdef0123456789",
  "exe_crc32": 1234567890,
  "exe_name": "SCES-00901",
  "recommend_8mb_ram": true,
  "recommend_fastboot": false,
  "patches": [
    {
      "name": "streaming_budget_2x",
      "description": "Doubles the per-frame DMA sector count.",
      "pattern": "8B 04 24 ?? ?? ?? ?? 8D 04 88",
      "replacement": "8B 04 24 00 04 00 00 8D 04 88",
      "category": "streaming_budget",
      "requires_8mb": true
    },
    {
      "name": "lod_distance_3x",
      "description": "Multiplies LOD switch distance by 3.",
      "pattern": "...",
      "replacement": "...",
      "category": "lod_distance",
      "requires_8mb": false
    }
  ]
}
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `display_name` | string | Human-readable game title for the overlay. |
| `exe_md5` | string (32 hex chars) | MD5 of the loaded PS-EXE image. Primary match key. |
| `exe_crc32` | number | CRC32 of the loaded PS-EXE image. Secondary check. |
| `exe_name` | string | Disc ID (e.g. "SCES-00901"). Metadata only. |
| `recommend_8mb_ram` | bool | Whether 8MB RAM mode should be enabled. |
| `recommend_fastboot` | bool | Whether DuckStation fastboot should be enabled. |
| `patches` | array | List of patch entries. |
| `patches[].name` | string | Short identifier. |
| `patches[].description` | string | Human-readable description. |
| `patches[].pattern` | string | Hex byte pattern with `??` wildcards, space-separated. |
| `patches[].replacement` | string | Replacement bytes (same length as pattern). `??` positions preserve original. |
| `patches[].category` | string | One of: `streaming_budget`, `lod_distance`, `vram_eviction`, `other`. |
| `patches[].requires_8mb` | bool | Whether this patch needs 8MB RAM mode. |

## How to author a patch

### Step 1: Identify the streaming buffer

Using a disassembler (Ghidra, IDA, or DuckStation's built-in debugger),
locate the engine's streaming buffer allocation. For PS1 racing games
this is typically:

- A `malloc`-style call early in track-load code
- Followed by a `memset` or DMA setup referencing the buffer
- The buffer size is usually a small constant (0x4000 = 16KB is common)

### Step 2: Find the size constant in the binary

The size constant appears as an immediate operand in the machine code.
For MIPS (PS1's R3000A), a typical pattern:

```
8B 04 24 00 40 00 00    # li $a0, 0x4000  (buffer size = 16KB)
8D 04 88                # lw $a0, ($a0)
```

The `00 40 00 00` is the size in little-endian. Doubling it to
`00 80 00 00` (32KB) or `00 00 01 00` (64KB) increases the buffer.

### Step 3: Construct the pattern

Use `??` for bytes that vary between regional variants (typically
register numbers and addresses). Keep the opcode bytes and the size
constant as literal matches.

### Step 4: Test

1. Enable 8MB RAM mode in DuckStation settings.
2. Launch the game with RSIL in Enhanced Mode.
3. Verify the patch applied (check the overlay — it shows applied patch
   count and addresses).
4. Play and observe whether draw distance increased.
5. If the game crashes, the buffer may need to be aligned to a specific
   boundary, or the engine may have a secondary size check. Adjust the
   patch and retry.

### Step 5: Publish

Submit the manifest JSON to the RSIL patches repository. The community
can verify and refine it.

## GT2 reference methodology

The Gran Turismo 2 "big drawing distance" mod follows this exact
methodology:

1. DuckStation's 8MB RAM mode provides the extra memory.
2. A community patch increases the track geometry streaming buffer from
   its original size to a larger value that fits in 8MB.
3. Optionally, LOD distance constants are patched to push model-swap
   thresholds further out.

The result: track geometry appears much further ahead, effectively
eliminating perceptible pop-in on most tracks.

The same methodology applies to Wipeout 2097, Ridge Racer Type 4, and
NFS High Stakes. Each game's streaming code must be analyzed
individually — the buffer size constant, its location, and the safe
expansion factor vary per engine.

## Disclaimer

Patches modify game executable code at runtime. This intentionally
diverges from original hardware behavior in CPU state. GPU emulation
remains accurate — the GPU still executes exactly what the (patched)
engine commands.

Enhanced Mode is always opt-in. Default mode (Deterministic) applies
no patches and has zero divergence.
