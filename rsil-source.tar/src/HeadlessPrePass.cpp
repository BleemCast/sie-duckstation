// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Headless Pre-Pass implementation.

#include "rsil/HeadlessPrePass.h"

#include <algorithm>
#include <thread>

namespace rsil {

// ---------------------------------------------------------------------------
// HeadlessPrePass
// ---------------------------------------------------------------------------

HeadlessPrePass::HeadlessPrePass(const RSILConfig& cfg,
                                 SignatureRegistry& sigs,
                                 SpatialCatalog& catalog,
                                 AdjacencyGraph& graph,
                                 PersistenceManager& persistence)
    : cfg_(cfg), sigs_(sigs), catalog_(catalog), graph_(graph),
      persistence_(persistence) {
    PrePassProgress p;
    p.state = PrePassProgress::State::Idle;
    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_ = p;
    }
}

bool HeadlessPrePass::run(const PrePassConfig& pcfg, FrameAdvanceFn advance_frame) {
    if (!advance_frame) {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Failed;
        progress_.error_message = "no frame advance callback provided";
        return false;
    }

    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Running;
        progress_.target_frames = pcfg.target_frames;
        progress_.frames_elapsed = 0;
        progress_.error_message.clear();
    }

    const uint32_t checkpoint_interval = pcfg.checkpoint
        ? pcfg.checkpoint_interval : 0;

    for (uint32_t frame = 0; frame < pcfg.target_frames; ++frame) {
        if (stop_requested_.load()) break;

        // Advance the emulator by one frame. RSIL's telemetry sinks
        // (wired into DuckStation's GPU/DMA callbacks) will populate
        // the registry/catalog/graph as a side effect.
        if (!advance_frame(frame)) {
            std::lock_guard<std::mutex> g(progress_mu_);
            progress_.state = PrePassProgress::State::Failed;
            progress_.error_message = "frame advance callback returned false";
            return false;
        }

        // Periodic checkpoint.
        if (checkpoint_interval > 0 &&
            (frame + 1) % checkpoint_interval == 0) {
            if (!checkpoint(frame + 1)) {
                // Checkpoint failure is non-fatal; continue.
            }
        }

        // Update progress every 60 frames (~1s @60fps).
        if ((frame + 1) % 60 == 0) {
            {
                std::lock_guard<std::mutex> g(progress_mu_);
                progress_.frames_elapsed = frame + 1;
            }
            update_progress();
            if ((frame + 1) % 600 == 0) {
                std::this_thread::yield();
            }
        }
    }

    // Final save.
    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Finalizing;
    }
    if (!persistence_.save_sync(sigs_, catalog_, graph_)) {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Failed;
        progress_.error_message = "persistence save failed";
        return false;
    }

    update_progress();
    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Done;
    }
    return true;
}

PrePassProgress HeadlessPrePass::progress() const {
    std::lock_guard<std::mutex> g(progress_mu_);
    return progress_;
}

void HeadlessPrePass::request_stop() {
    stop_requested_.store(true);
}

void HeadlessPrePass::update_progress() {
    PrePassProgress p;
    {
        std::lock_guard<std::mutex> g(progress_mu_);
        p = progress_;
    }
    auto sig_snap = sigs_.snapshot();
    p.signatures_observed = static_cast<uint32_t>(sig_snap.size());
    p.transitions_observed = static_cast<uint32_t>(graph_.edge_count());
    auto cat_snap = catalog_.snapshot();
    std::vector<CellId> cells;
    for (const auto& n : cat_snap.nodes) {
        if (n.cell != kInvalidCell) cells.push_back(n.cell);
    }
    std::sort(cells.begin(), cells.end());
    cells.erase(std::unique(cells.begin(), cells.end()), cells.end());
    p.cells_assigned = static_cast<uint32_t>(cells.size());
    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_ = p;
    }
}

bool HeadlessPrePass::checkpoint(uint32_t frame) {
    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Checkpointing;
        progress_.frames_elapsed = frame;
    }

    bool ok = persistence_.save_sync(sigs_, catalog_, graph_);

    {
        std::lock_guard<std::mutex> g(progress_mu_);
        progress_.state = PrePassProgress::State::Running;
    }
    return ok;
}

// ---------------------------------------------------------------------------
// CachePrimer
// ---------------------------------------------------------------------------

bool CachePrimer::prime() {
    return persistence_.load(sigs_, catalog_, graph_);
}

bool CachePrimer::has_cache() const {
    // The persistence manager's load() is idempotent: calling it twice
    // is safe but wasteful. We probe by attempting a load into throwaway
    // state. A real implementation would query the backend directly.
    // For the scaffold, we delegate to persistence_.load() semantics.
    //
    // Production: PersistenceBackend should expose a `bool exists(exe)`
    // method. For now, we return true and let prime() handle the miss.
    return true;
}

CachePrimer::CacheInfo CachePrimer::info() const {
    CacheInfo ci;
    // Production: query the backend for metadata without loading.
    // Scaffold: returns an empty info; the overlay will show "no cache".
    return ci;
}

}  // namespace rsil
