// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Top-level subsystem facade implementation.

#include "rsil/RSILSubsystem.h"

#include <algorithm>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <utility>

namespace {

// D10 fix: JSON string escaper. Prevents silent manifest parse failures
// when display_name or description contains ", \, or control characters.
std::string json_escape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 8);
    for (char c : s) {
        switch (c) {
            case '"':  out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof(buf), "\\u%04x",
                                  static_cast<unsigned int>(static_cast<unsigned char>(c)));
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

}  // namespace

namespace rsil {

// ---------------------------------------------------------------------------
// Factory
// ---------------------------------------------------------------------------

std::unique_ptr<RSILSubsystem> RSILSubsystem::create(
    RSILConfig cfg,
    HostAdapter& host,
    std::unique_ptr<HashProvider> hash_provider,
    std::unique_ptr<PersistenceBackend> persistence) {
    return std::unique_ptr<RSILSubsystem>(
        new RSILSubsystem(std::move(cfg), host, std::move(hash_provider),
                          std::move(persistence)));
}

RSILSubsystem::RSILSubsystem(RSILConfig cfg,
                             HostAdapter& host,
                             std::unique_ptr<HashProvider> hash_provider,
                             std::unique_ptr<PersistenceBackend> persistence)
    : cfg_(std::move(cfg)),
      host_(host),
      hash_provider_(std::move(hash_provider)),
      persistence_backend_(std::move(persistence)),
      graph_(cfg_.transition_decay, cfg_.min_observations),
      predictor_(cfg_, graph_, catalog_, sigs_),
      prereg_(cfg_, host) {
    tap_.add_sink(this);
    if (cfg_.flags.validator && hash_provider_) {
        validator_.emplace(cfg_, *hash_provider_);
    }
    // Wire the packet parser to the clusterer. Each complete primitive
    // packet parsed from the GP0 FIFO is forwarded to the clusterer for
    // grouping into ClusterEvents.
    parser_.on_primitive = [this](const PrimitiveObservation& obs) {
        clusterer_.push_primitive(obs);
    };
    // Overlay is constructed lazily on first draw to avoid pulling in
    // ImGui headers at construction time.
}

RSILSubsystem::~RSILSubsystem() {
    tap_.remove_sink(this);
    on_executable_unloaded();
}

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

void RSILSubsystem::on_executable_loaded(const ExecutableSignature& sig) {
    exe_ = sig;
    exe_loaded_ = true;

    sigs_.clear();
    catalog_.clear();
    graph_.clear();
    history_.clear();

    if (cfg_.flags.persistence && persistence_backend_) {
        persistence_ = std::make_unique<PersistenceManager>(
            std::move(persistence_backend_), exe_);
        cache_primer_ = std::make_unique<CachePrimer>(
            sigs_, catalog_, graph_, *persistence_);
        // In normal mode, eagerly load any existing cache so the
        // predictor is confident from frame 1. In pre-pass mode, we
        // start empty (the pre-pass is building the cache).
        if (!pre_pass_mode_) {
            load_cache();
        }
    }
}

void RSILSubsystem::on_executable_unloaded() {
    if (!exe_loaded_) return;
    exe_loaded_ = false;

    if (cfg_.flags.persistence && persistence_) {
        persistence_->save_sync(sigs_, catalog_, graph_);
    }
    persistence_.reset();
}

// ---------------------------------------------------------------------------
// Corrected telemetry: accept decoded draw commands
// ---------------------------------------------------------------------------

void RSILSubsystem::on_decoded_draw(uint16_t texpage, uint16_t clut,
                                    bool textured, bool translucent,
                                    bool gouraud, bool quad,
                                    uint32_t vertex_count,
                                    const int16_t* vertices_xy,
                                    FrameId frame) {
    if (!cfg_.flags.telemetry) return;

    // Build a PrimitiveObservation from the decoded command.
    // This is the CORRECT data path — no FIFO re-parsing needed.
    PrimitiveObservation obs;
    obs.topology = quad ? PrimitiveTopology::Quad : PrimitiveTopology::Polygon;
    obs.vertex_count = static_cast<uint16_t>(vertex_count);
    obs.attrs.texpage = texpage;
    obs.attrs.clut = clut;
    obs.attrs.textured = textured;
    obs.attrs.gouraud = gouraud;
    obs.attrs.blended = translucent;
    obs.attrs.lit = gouraud;
    obs.attrs.raw_cmd = 0;  // not available from decoded path; not needed

    // Compute normalized bbox from vertex positions.
    if (vertices_xy && vertex_count > 0) {
        std::vector<std::array<int16_t, 2>> verts(vertex_count);
        for (uint32_t i = 0; i < vertex_count; ++i) {
            verts[i] = {vertices_xy[i * 2], vertices_xy[i * 2 + 1]};
        }
        obs.bbox = GpuPacketParser::compute_normalized_bbox(verts);
    }

    clusterer_.push_primitive(obs);
}

// ---------------------------------------------------------------------------
// TelemetrySink
// ---------------------------------------------------------------------------

void RSILSubsystem::on_gpu_command(const GpuCommandWord& w) {
    if (!cfg_.flags.telemetry) return;

    // The parser accumulates words and emits complete PrimitiveObservation
    // objects with ALL metadata populated (topology, vertex count, texpage,
    // CLUT, attributes, normalized bbox). This replaces the old naive
    // single-word interpretation that produced garbage signatures.
    parser_.on_word(w.word, w.frame);
}

void RSILSubsystem::on_dma_packet(const DmaPacketObservation& /*p*/) {
    if (!cfg_.flags.telemetry) return;
    // DMA packets inform transient source/dest tracking but do not
    // directly emit ClusterEvents. The clusterer handles grouping.
    // Production: stash source_ram/dest_vram onto the next PrimitiveObs.
}

void RSILSubsystem::on_frame_boundary(FrameId frame) {
    if (!cfg_.flags.telemetry) return;
    clusterer_.begin_frame(frame);
}

// ---------------------------------------------------------------------------
// Per-frame pump
// ---------------------------------------------------------------------------

void RSILSubsystem::pump(FrameId frame) {
    // 1. Close any in-flight cluster.
    if (const ClusterEvent* ev = clusterer_.flush()) {
        on_cluster_closed(*ev);
    }

    // 2. Validator sampling (skipped in pre-pass mode; no point hashing
    //    since we're not comparing against a baseline).
    if (validator_ && !pre_pass_mode_) validator_->sample(frame);

    // 3. Host pre-registrar GC (skipped in pre-pass mode; no host
    //    renderer exists, so no pre-registration happens).
    if (cfg_.flags.preregister && !pre_pass_mode_) prereg_.gc(frame);

    // 4. Persistence: in pre-pass mode, checkpoint frequently (every
    //    checkpoint_interval frames). In normal mode, throttled save
    //    every 600 frames.
    if (cfg_.flags.persistence && persistence_) {
        if (pre_pass_mode_) {
            // Pre-pass checkpointing is driven by HeadlessPrePass::run,
            // not here. Nothing to do.
        } else if (frame % 600 == 0) {
            persistence_->save_async(sigs_, catalog_, graph_);
        }
    }
}

void RSILSubsystem::on_cluster_closed(const ClusterEvent& ev) {
    ClusterSignatureId id = sigs_.register_event(ev);

    // Update spatial catalog.
    ClusterSignatureId prev =
        history_.empty() ? kInvalidSignature : history_.back();
    catalog_.register_cluster(id, prev, ev.frame);

    // Update adjacency graph (observe the transition prev -> id).
    if (prev != kInvalidSignature && cfg_.flags.graph) {
        graph_.observe_transition(prev, id, ev.frame);
    }

    // Predictor look-ahead + host pre-registration.
    // Skipped in pre-pass mode: there's no host renderer to pre-warm,
    // and we want the pre-pass to be as fast as possible.
    if (!pre_pass_mode_ && cfg_.flags.predictor) {
        auto reqs = predictor_.on_cluster_observed(id, ev.frame);
        if (cfg_.flags.preregister && !reqs.empty()) {
            prereg_.on_requests(reqs, ev.frame);
        }
    }

    // Update history window.
    history_.push_back(id);
    if (history_.size() > cfg_.lookahead_frames * 4) history_.erase(history_.begin());
}

// ---------------------------------------------------------------------------
// Overlay
// ---------------------------------------------------------------------------

void RSILSubsystem::draw_overlay() {
    if (!cfg_.flags.overlay) return;
    if (!overlay_) {
        overlay_.emplace(cfg_, sigs_, catalog_, graph_, predictor_, prereg_,
                         validator_ ? &*validator_ : nullptr);
    }
    overlay_->draw();
}

// ---------------------------------------------------------------------------
// Config / flags
// ---------------------------------------------------------------------------

void RSILSubsystem::set_flags(const FeatureFlags& flags) {
    cfg_.flags = flags;
    if (flags.validator && !validator_ && hash_provider_) {
        validator_.emplace(cfg_, *hash_provider_);
    } else if (!flags.validator && validator_) {
        validator_.reset();
    }
    // Overlay is constructed lazily; reset if disabled.
    if (!flags.overlay) overlay_.reset();
}

const Predictor::Stats& RSILSubsystem::predictor_stats() const {
    return predictor_.stats();
}

const HostPreRegistrar::Stats& RSILSubsystem::prereg_stats() const {
    return prereg_.stats();
}

const Validator::Stats* RSILSubsystem::validator_stats() const {
    return validator_ ? &validator_->stats() : nullptr;
}

// ---------------------------------------------------------------------------
// Pre-pass mode
// ---------------------------------------------------------------------------

void RSILSubsystem::set_pre_pass_mode(bool enabled) {
    pre_pass_mode_ = enabled;
    // In pre-pass mode, disable predictor/preregister/validator/overlay
    // regardless of the FeatureFlags — they're useless without a host
    // renderer and just burn cycles.
    if (enabled) {
        FeatureFlags f = cfg_.flags;
        f.predictor   = false;
        f.preregister = false;
        f.overlay     = false;
        f.validator   = false;
        // Keep telemetry, graph, persistence enabled — those are what
        // the pre-pass is building.
        cfg_.flags = f;
        validator_.reset();
        overlay_.reset();
    }
}

bool RSILSubsystem::load_cache() {
    if (!cache_primer_) return false;
    bool loaded = cache_primer_->prime();
    if (loaded) {
        // The graph is now saturated; the predictor will return high-
        // confidence successors from frame 1.
    }
    return loaded;
}

bool RSILSubsystem::run_pre_pass(const PrePassConfig& pcfg,
                                 HeadlessPrePass::FrameAdvanceFn advance_frame) {
    if (!persistence_) {
        return false;
    }
    pre_pass_ = std::make_unique<HeadlessPrePass>(
        cfg_, sigs_, catalog_, graph_, *persistence_);
    set_pre_pass_mode(true);
    bool ok = pre_pass_->run(pcfg, std::move(advance_frame));
    set_pre_pass_mode(false);
    return ok;
}

PrePassProgress RSILSubsystem::pre_pass_progress() const {
    if (!pre_pass_) {
        PrePassProgress p;
        p.state = PrePassProgress::State::Idle;
        return p;
    }
    return pre_pass_->progress();
}

// ---------------------------------------------------------------------------
// Auto-discovery (in-process MIPS scan)
// ---------------------------------------------------------------------------

bool RSILSubsystem::auto_discover_patches(const std::vector<uint8_t>& exe_data) {
    if (exe_data.empty()) return false;

    // Parse the PS-X EXE from the raw image.
    PsxExeInfo exe_info;
    if (!parse_psx_exe(exe_data.data(), exe_data.size(), exe_info)) {
        return false;  // not a PS-X EXE
    }

    // Run the scan.
    scanner_.set_value_range(50, 1000);
    scanner_.set_scan_floats(true);
    auto candidates = scanner_.scan(exe_info);
    scan_stats_ = scanner_.stats();

    if (candidates.empty()) return false;

    // Convert to a PatchManifest and load it into the ScenePatchLayer.
    PatchManifest manifest = scanner_.to_manifest(
        candidates, exe_, exe_.display_name.empty() ? "Auto-discovered" : exe_.display_name);

    // Load the manifest into the EPL by writing it to a temp file and
    // using the standard load path. In production this would go through
    // a direct in-memory API; for now we use a temp file.
    if (!manifest.patches.empty()) {
        // Write manifest to a temp file.
        auto path = std::filesystem::temp_directory_path() / "rsil_auto_discovered.json";
        std::ofstream f(path);
        if (f) {
            // D10 fix: use json_escape for all string values.
            f << "{\n";
            f << "  \"display_name\": \"" << json_escape(manifest.display_name) << "\",\n";
            f << "  \"exe_md5\": \"";
            for (uint8_t b : manifest.exe_signature.md5)
                f << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(b);
            f << "\",\n";
            f << "  \"exe_crc32\": " << std::dec << manifest.exe_signature.crc32 << ",\n";
            f << "  \"exe_name\": \"" << json_escape(manifest.exe_signature.display_name) << "\",\n";
            f << "  \"recommend_8mb_ram\": " << (manifest.recommend_8mb_ram ? "true" : "false") << ",\n";
            f << "  \"recommend_fastboot\": false,\n";
            f << "  \"patches\": [\n";
            for (size_t i = 0; i < manifest.patches.size(); ++i) {
                const auto& p = manifest.patches[i];
                f << "    {\n";
                f << "      \"name\": \"" << json_escape(p.name) << "\",\n";
                f << "      \"description\": \"" << json_escape(p.description) << "\",\n";
                f << "      \"pattern\": \"" << json_escape(p.pattern_hex) << "\",\n";
                f << "      \"replacement\": \"" << json_escape(p.replacement_hex) << "\",\n";
                f << "      \"category\": \""
                  << (p.category == PatchEntry::Category::StreamingBudget ? "streaming_budget" :
                      p.category == PatchEntry::Category::LodDistance ? "lod_distance" :
                      p.category == PatchEntry::Category::VramEviction ? "vram_eviction" : "other")
                  << "\",\n";
                f << "      \"requires_8mb\": " << (p.requires_8mb ? "true" : "false") << "\n";
                f << "    }" << (i + 1 < manifest.patches.size() ? "," : "") << "\n";
            }
            f << "  ]\n}\n";
            f.close();
            epl_.load_manifest(path);
        }
    }

    return !manifest.patches.empty();
}

// ---------------------------------------------------------------------------
// Enhanced mode (Layer 4 — Engine Patch Layer)
// ---------------------------------------------------------------------------

void RSILSubsystem::set_emulation_mode(EmulationMode mode,
                                       RamAccess* ram,
                                       const std::filesystem::path& patches_dir) {
    if (mode == mode_) return;

    if (mode == EmulationMode::Enhanced) {
        // Switching TO Enhanced: find and apply patches.
        if (!ram) return;  // Cannot apply patches without RAM access.
        ram_access_ = ram;

        // If a patches_dir is specified, look for a manifest matching this exe.
        if (!patches_dir.empty()) {
            auto manifest_path = find_manifest_for_exe(patches_dir, exe_);
            if (!manifest_path.empty()) {
                epl_.load_manifest(manifest_path);
            }
        }

        // Apply the manifest — whether it was loaded from patches_dir above,
        // or from auto_discover_patches() earlier. This is the critical fix:
        // without this, auto-discovered patches were never applied.
        if (epl_.has_manifest() && !epl_.is_applied()) {
            uint32_t applied = epl_.apply(*ram_access_);
            INFO_LOG("RSIL: Enhanced mode — {} patches applied to RAM (JIT-safe via SafeWriteMemoryWord)",
                     applied);
        }

        mode_ = EmulationMode::Enhanced;
    } else {
        // Switching TO Deterministic: revert patches.
        if (epl_.is_applied() && ram_access_) {
            epl_.revert(*ram_access_);
        }
        ram_access_ = nullptr;
        mode_ = EmulationMode::Deterministic;
    }
}

}  // namespace rsil
