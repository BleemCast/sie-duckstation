// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Engine Patch Layer implementation.

#include "rsil/ScenePatchLayer.h"

#include <algorithm>
#include <cstring>
#include <fstream>
#include <sstream>

// Minimal JSON parsing for the patch manifest format.
// We avoid pulling in a full JSON library to keep RSIL dependency-free.
// The manifest format is simple enough that a hand-written parser suffices.

namespace rsil {

// ---------------------------------------------------------------------------
// Hex helpers
// ---------------------------------------------------------------------------

namespace {

bool hex_nibble(char c, uint8_t& out) {
    if (c >= '0' && c <= '9') { out = c - '0'; return true; }
    if (c >= 'a' && c <= 'f') { out = c - 'a' + 10; return true; }
    if (c >= 'A' && c <= 'F') { out = c - 'A' + 10; return true; }
    return false;
}

// Parse a hex byte or wildcard ("??"). Returns true if it's a literal
// byte (sets `out`), false if it's a wildcard (leaves `out` unchanged,
// sets `is_wildcard`).
bool parse_hex_byte(const std::string& tok, uint8_t& out, bool& is_wildcard) {
    is_wildcard = false;
    if (tok.size() == 2 && tok[0] == '?' && tok[1] == '?') {
        is_wildcard = true;
        return true;
    }
    if (tok.size() != 2) return false;
    uint8_t hi, lo;
    if (!hex_nibble(tok[0], hi) || !hex_nibble(tok[1], lo)) return false;
    out = (hi << 4) | lo;
    return true;
}

// Split a hex pattern string ("8B 04 ?? ??") into tokens.
std::vector<std::string> tokenize(const std::string& hex) {
    std::vector<std::string> tokens;
    std::string tok;
    for (char c : hex) {
        if (c == ' ' || c == '\t') {
            if (!tok.empty()) { tokens.push_back(tok); tok.clear(); }
        } else {
            tok.push_back(c);
        }
    }
    if (!tok.empty()) tokens.push_back(tok);
    return tokens;
}

}  // namespace

// ---------------------------------------------------------------------------
// Pattern compilation and scanning
// ---------------------------------------------------------------------------

CompiledPattern compile_pattern(const std::string& pattern_hex) {
    CompiledPattern cp;
    auto tokens = tokenize(pattern_hex);
    cp.length = tokens.size();
    cp.bytes.resize(cp.length);
    cp.mask.resize(cp.length, 0xFF);
    for (size_t i = 0; i < tokens.size(); ++i) {
        uint8_t b;
        bool wild;
        if (!parse_hex_byte(tokens[i], b, wild)) {
            // Malformed token; treat as wildcard to avoid false matches.
            cp.mask[i] = 0x00;
            cp.bytes[i] = 0;
            continue;
        }
        if (wild) {
            cp.mask[i] = 0x00;
            cp.bytes[i] = 0;
        } else {
            cp.mask[i] = 0xFF;
            cp.bytes[i] = b;
        }
    }
    return cp;
}

std::optional<size_t> scan_pattern(const uint8_t* data, size_t size,
                                   const CompiledPattern& pattern) {
    if (pattern.length == 0 || pattern.length > size) return std::nullopt;
    const size_t end = size - pattern.length;
    for (size_t i = 0; i <= end; ++i) {
        bool match = true;
        for (size_t j = 0; j < pattern.length; ++j) {
            if (pattern.mask[j] == 0xFF && data[i + j] != pattern.bytes[j]) {
                match = false;
                break;
            }
        }
        if (match) return i;
    }
    return std::nullopt;
}

// ---------------------------------------------------------------------------
// ScenePatchLayer
// ---------------------------------------------------------------------------

ScenePatchLayer::ScenePatchLayer() = default;

bool ScenePatchLayer::load_manifest(const std::filesystem::path& path) {
    has_manifest_ = false;
    manifest_ = {};
    if (!load_manifest_file(path, manifest_)) return false;
    has_manifest_ = true;
    return true;
}

bool ScenePatchLayer::matches_executable(const ExecutableSignature& sig) const {
    if (!has_manifest_) return false;
    // Match on MD5 (primary). CRC32 is a secondary check.
    return manifest_.exe_signature.md5 == sig.md5;
}

uint32_t ScenePatchLayer::apply(RamAccess& ram) {
    if (!has_manifest_ || applied_) return 0;

    stats_ = {};
    applied_patches_.clear();

    const size_t ram_sz = ram.ram_size();
    // Read the entire RAM into a local buffer for scanning.
    std::vector<uint8_t> ram_image(ram_sz);
    if (!ram.read(0, ram_image.data(), ram_sz)) {
        return 0;
    }

    for (const auto& patch : manifest_.patches) {
        CompiledPattern cp = compile_pattern(patch.pattern_hex);
        auto match = scan_pattern(ram_image.data(), ram_sz, cp);
        if (!match) {
            stats_.patches_failed++;
            continue;
        }

        uint32_t addr = static_cast<uint32_t>(*match);

        // Parse replacement bytes.
        auto repl_tokens = tokenize(patch.replacement_hex);
        if (repl_tokens.size() != cp.length) {
            stats_.patches_failed++;
            continue;
        }

        // Save original bytes and build patched bytes.
        AppliedPatch ap;
        ap.name = patch.name;
        ap.address = addr;
        ap.original_bytes.resize(cp.length);
        ap.patched_bytes.resize(cp.length);
        std::memcpy(ap.original_bytes.data(), ram_image.data() + addr, cp.length);

        for (size_t i = 0; i < cp.length; ++i) {
            uint8_t b;
            bool wild;
            if (!parse_hex_byte(repl_tokens[i], b, wild)) {
                ap.patched_bytes[i] = ap.original_bytes[i];
                continue;
            }
            // Wildcard positions preserve the original byte.
            ap.patched_bytes[i] = wild ? ap.original_bytes[i] : b;
        }

        // Write patched bytes to RAM.
        if (!ram.write(addr, ap.patched_bytes.data(), cp.length)) {
            stats_.patches_failed++;
            continue;
        }

        // Update the local image so subsequent pattern scans see the
        // patched bytes (avoids re-matching the same site).
        std::memcpy(ram_image.data() + addr, ap.patched_bytes.data(), cp.length);

        ap.active = true;
        applied_patches_.push_back(std::move(ap));
        stats_.patches_applied++;
    }

    applied_ = true;
    return stats_.patches_applied;
}

void ScenePatchLayer::revert(RamAccess& ram) {
    if (!applied_) return;
    // Revert in reverse order.
    for (auto it = applied_patches_.rbegin(); it != applied_patches_.rend(); ++it) {
        if (it->active) {
            ram.write(it->address, it->original_bytes.data(), it->original_bytes.size());
            it->active = false;
        }
    }
    applied_ = false;
}

// ---------------------------------------------------------------------------
// Minimal JSON parser for the manifest format
// ---------------------------------------------------------------------------

namespace {

// A very small JSON value parser. Supports objects, arrays, strings,
// numbers, booleans, and null. Sufficient for the patch manifest format.

class JsonParser {
public:
    JsonParser(const std::string& s) : s_(s), i_(0) {}

    char peek() const { return i_ < s_.size() ? s_[i_] : '\0'; }
    bool expect(char c) {
        if (peek() != c) return false;
        i_++;
        return true;
    }
    void skip_ws() {
        while (i_ < s_.size() && (s_[i_] == ' ' || s_[i_] == '\t' ||
               s_[i_] == '\n' || s_[i_] == '\r')) i_++;
    }
    size_t i_;  // public for inline access in parse_manifest_json

    bool parse_object(std::function<bool(const std::string&)> on_key) {
        skip_ws();
        if (!expect('{')) return false;
        skip_ws();
        if (peek() == '}') { i_++; return true; }
        while (true) {
            skip_ws();
            std::string key;
            if (!parse_string(key)) return false;
            skip_ws();
            if (!expect(':')) return false;
            if (!on_key(key)) return false;
            skip_ws();
            if (peek() == ',') { i_++; continue; }
            if (peek() == '}') { i_++; break; }
            return false;
        }
        return true;
    }

    bool parse_string(std::string& out) {
        skip_ws();
        if (!expect('"')) return false;
        out.clear();
        while (i_ < s_.size() && s_[i_] != '"') {
            if (s_[i_] == '\\' && i_ + 1 < s_.size()) {
                char next = s_[i_ + 1];
                switch (next) {
                    case 'n': out.push_back('\n'); break;
                    case 't': out.push_back('\t'); break;
                    case '"': out.push_back('"'); break;
                    case '\\': out.push_back('\\'); break;
                    case '/': out.push_back('/'); break;
                    default: out.push_back(next); break;
                }
                i_ += 2;
            } else {
                out.push_back(s_[i_++]);
            }
        }
        if (!expect('"')) return false;
        return true;
    }

    bool parse_bool(bool& out) {
        skip_ws();
        if (s_.compare(i_, 4, "true") == 0) { i_ += 4; out = true; return true; }
        if (s_.compare(i_, 5, "false") == 0) { i_ += 5; out = false; return true; }
        return false;
    }

    bool parse_number(int64_t& out) {
        skip_ws();
        size_t start = i_;
        if (peek() == '-') i_++;
        while (i_ < s_.size() && (s_[i_] >= '0' && s_[i_] <= '9')) i_++;
        if (i_ == start) return false;
        out = std::stoll(s_.substr(start, i_ - start));
        return true;
    }

    bool parse_array_strings(std::vector<std::string>& out) {
        skip_ws();
        if (!expect('[')) return false;
        skip_ws();
        if (peek() == ']') { i_++; return true; }
        while (true) {
            std::string s;
            if (!parse_string(s)) return false;
            out.push_back(s);
            skip_ws();
            if (peek() == ',') { i_++; continue; }
            if (peek() == ']') { i_++; break; }
            return false;
        }
        return true;
    }

    // Skip any JSON value (for keys we don't care about).
    bool skip_value() {
        skip_ws();
        char c = peek();
        if (c == '"') { std::string s; return parse_string(s); }
        if (c == '{') {
            return parse_object([&](const std::string&) { return skip_value(); });
        }
        if (c == '[') {
            if (!expect('[')) return false;
            skip_ws();
            if (peek() == ']') { i_++; return true; }
            while (true) {
                if (!skip_value()) return false;
                skip_ws();
                if (peek() == ',') { i_++; continue; }
                if (peek() == ']') { i_++; break; }
                return false;
            }
            return true;
        }
        if (c == 't' || c == 'f') { bool b; return parse_bool(b); }
        if (c == 'n') { if (s_.compare(i_, 4, "null") == 0) { i_ += 4; return true; } return false; }
        int64_t n; return parse_number(n);
    }

private:
    const std::string& s_;
};

}  // namespace

bool parse_manifest_json(const std::string& json, PatchManifest& out) {
    JsonParser p(json);
    return p.parse_object([&](const std::string& key) -> bool {
        if (key == "display_name") {
            return p.parse_string(out.display_name);
        }
        if (key == "recommend_8mb_ram") {
            return p.parse_bool(out.recommend_8mb_ram);
        }
        if (key == "recommend_fastboot") {
            return p.parse_bool(out.recommend_fastboot);
        }
        if (key == "exe_md5") {
            std::string md5_hex;
            if (!p.parse_string(md5_hex)) return false;
            // Parse 32-char hex string into 16 bytes.
            if (md5_hex.size() != 32) return false;
            for (int i = 0; i < 16; ++i) {
                uint8_t hi, lo;
                if (!hex_nibble(md5_hex[i*2], hi)) return false;
                if (!hex_nibble(md5_hex[i*2+1], lo)) return false;
                out.exe_signature.md5[i] = (hi << 4) | lo;
            }
            return true;
        }
        if (key == "exe_crc32") {
            int64_t v;
            if (!p.parse_number(v)) return false;
            out.exe_signature.crc32 = static_cast<uint32_t>(v);
            return true;
        }
        if (key == "exe_name") {
            return p.parse_string(out.exe_signature.display_name);
        }
        if (key == "patches") {
            // Array of patch objects.
            p.skip_ws();
            if (!p.expect('[')) return false;
            p.skip_ws();
            if (p.peek() == ']') { p.i_++; return true; }
            while (true) {
                PatchEntry pe;
                if (!p.parse_object([&](const std::string& pk) -> bool {
                    if (pk == "name")        return p.parse_string(pe.name);
                    if (pk == "description") return p.parse_string(pe.description);
                    if (pk == "pattern")     return p.parse_string(pe.pattern_hex);
                    if (pk == "replacement") return p.parse_string(pe.replacement_hex);
                    if (pk == "requires_8mb") return p.parse_bool(pe.requires_8mb);
                    if (pk == "category") {
                        std::string c;
                        if (!p.parse_string(c)) return false;
                        if (c == "streaming_budget") pe.category = PatchEntry::Category::StreamingBudget;
                        else if (c == "lod_distance") pe.category = PatchEntry::Category::LodDistance;
                        else if (c == "vram_eviction") pe.category = PatchEntry::Category::VramEviction;
                        else pe.category = PatchEntry::Category::Other;
                        return true;
                    }
                    return p.skip_value();
                })) return false;
                out.patches.push_back(std::move(pe));
                p.skip_ws();
                if (p.peek() == ',') { p.i_++; continue; }
                if (p.peek() == ']') { p.i_++; break; }
                return false;
            }
            return true;
        }
        // Unknown key: skip.
        return p.skip_value();
    });
}

bool load_manifest_file(const std::filesystem::path& path, PatchManifest& out) {
    std::ifstream f(path);
    if (!f) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    return parse_manifest_json(ss.str(), out);
}

std::filesystem::path find_manifest_for_exe(
    const std::filesystem::path& dir,
    const ExecutableSignature& sig) {
    if (!std::filesystem::exists(dir)) return {};
    for (const auto& entry : std::filesystem::directory_iterator(dir)) {
        if (entry.path().extension() != ".json") continue;
        PatchManifest m;
        if (!load_manifest_file(entry.path(), m)) continue;
        if (m.exe_signature.md5 == sig.md5) return entry.path();
    }
    return {};
}

}  // namespace rsil
