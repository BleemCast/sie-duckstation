// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Predictor implementation.

#include "rsil/Predictor.h"

#include <algorithm>

namespace rsil {

std::vector<PreRegistrationRequest> Predictor::on_cluster_observed(
    ClusterSignatureId current, FrameId frame) {
    if (!cfg_.flags.predictor) return {};
    if (current == kInvalidSignature) return {};

    auto top = graph_.top_successors(current, 4);
    std::vector<PreRegistrationRequest> out;
    out.reserve(top.size());

    for (const auto& edge : top) {
        if (edge.confidence < cfg_.prereg_confidence_threshold) continue;
        const CatalogNode* node = catalog_.find(edge.to);
        const SignatureEntry* entry = sigs_.lookup(edge.to);

        PreRegistrationRequest r;
        r.signature_id     = edge.to;
        // Populate REAL texpage/clut/attributes from the signature registry.
        // This gives the host adapter everything it needs to pre-allocate
        // the correct descriptor set AND pre-compile the correct shader
        // variant.
        if (entry) {
            r.texpage = entry->attrs.texpage;
            r.clut    = entry->attrs.clut;
            r.attrs   = entry->attrs;
        }
        r.hint_cell         = node ? node->cell   : kInvalidCell;
        r.hint_sector       = node ? node->sector : kInvalidSector;
        r.elevate_priority  = cfg_.host_priority_elevation_enabled &&
                              edge.confidence > 0.85f;
        out.push_back(r);
    }

    stats_.total_predictions += out.size();
    (void)frame;
    return out;
}

std::vector<PreRegistrationRequest> Predictor::predict_with_context(
    std::span<const ClusterSignatureId> history, FrameId /*frame*/) {
    // Default: order-1 fallback. Subclasses override for higher-order.
    if (history.empty()) return {};
    return on_cluster_observed(history.back(), 0);
}

void Predictor::record_hit(ClusterSignatureId /*sig*/)  { stats_.hits++; }
void Predictor::record_miss(ClusterSignatureId /*sig*/) { stats_.misses++; }

}  // namespace rsil
