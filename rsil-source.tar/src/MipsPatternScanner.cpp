// SPDX-License-Identifier: BSD-3-Clause
// RSIL — MIPS R3000A pattern scanner implementation.
//
// C++ port of tools/wipeout_scanner.py. Scans PS-X EXE code for
// draw-distance culling instruction patterns.

#include "rsil/MipsPatternScanner.h"

#include <algorithm>
#include <chrono>
#include <cstring>

namespace rsil {

// ---------------------------------------------------------------------------
// D3 fix: Branch-direction safety analysis
// ---------------------------------------------------------------------------
//
// Without this analysis, the scanner cannot distinguish:
//   cull-when-far  (branch skips draw when distance >= threshold) — SAFE to max
//   cull-when-near (branch skips draw when distance <  threshold) — UNSAFE to max
//
// Patching a cull-when-near pattern inverts culling → every polygon disappears.
//
// Two result types require different analysis:
//   ZeroOrOne     (from slti/sltu): result is 0 (far) or 1 (near)
//   GeneralValue  (from subu/addiu-neg): result = distance - threshold
//
// HEURISTIC ASSUMPTION: branch-taken = skip-draw (cull). This holds for the
// vast majority of PS1 racing cull patterns but is not provable without
// tracing the branch target for GP0 writes (0xBF801810). Future work (D4).

enum class ResultType { ZeroOrOne, GeneralValue };

struct BranchSafety {
    bool tests_result_reg = false;
    bool safe_to_max_imm = false;
    bool degenerate = false;  // branch doesn't depend on compare result
    std::string reason;
};

static inline uint32_t read_code_word(const std::vector<uint8_t>& code, size_t offset) {
    return static_cast<uint32_t>(code[offset]) |
           (static_cast<uint32_t>(code[offset + 1]) << 8) |
           (static_cast<uint32_t>(code[offset + 2]) << 16) |
           (static_cast<uint32_t>(code[offset + 3]) << 24);
}

static BranchSafety analyze_branch_safety(uint32_t branch_word, uint32_t result_reg,
                                          ResultType rt) {
    BranchSafety bs;
    uint32_t op = mips::bits(branch_word, 31, 26);
    uint32_t rs = mips::bits(branch_word, 25, 21);
    uint32_t rt_field = mips::bits(branch_word, 20, 16);

    if (op == mips::OP_BEQ || op == mips::OP_BNE) {
        bool tests_reg = (rs == result_reg && rt_field == 0) ||
                         (rt_field == result_reg && rs == 0);
        if (!tests_reg) {
            bs.reason = "branch does not test result register";
            return bs;
        }
        bs.tests_result_reg = true;
        if (rt == ResultType::ZeroOrOne) {
            if (op == mips::OP_BEQ) {
                bs.safe_to_max_imm = true;
                bs.reason = "beq $rt,$zero (cull-when-far, safe)";
            } else {
                bs.reason = "bne $rt,$zero (cull-when-near, UNSAFE)";
            }
        } else {
            bs.degenerate = true;
            bs.reason = "beq/bne on general value (equality, not cull)";
        }
        return bs;
    }

    if (op == mips::OP_BLEZ || op == mips::OP_BGTZ) {
        if (rs != result_reg) {
            bs.reason = "branch does not test result register";
            return bs;
        }
        bs.tests_result_reg = true;
        if (rt == ResultType::ZeroOrOne) {
            if (op == mips::OP_BLEZ) {
                bs.safe_to_max_imm = true;
                bs.reason = "blez $rt (cull-when-far, safe)";
            } else {
                bs.reason = "bgtz $rt (cull-when-near, UNSAFE)";
            }
        } else {
            if (op == mips::OP_BGTZ) {
                bs.safe_to_max_imm = true;
                bs.reason = "bgtz $rd (cull-when-far, safe)";
            } else {
                bs.reason = "blez $rd (cull-when-near, UNSAFE)";
            }
        }
        return bs;
    }

    if (op == mips::OP_REGIMM) {
        if (rs != result_reg) {
            bs.reason = "regimm does not test result register";
            return bs;
        }
        bs.tests_result_reg = true;
        if (rt == ResultType::ZeroOrOne) {
            bs.degenerate = true;
            bs.reason = (rt_field == mips::RT_BLTZ)
                ? "bltz $rt (never branches for 0/1)"
                : "bgez $rt (always branches for 0/1)";
        } else {
            if (rt_field == mips::RT_BGEZ) {
                bs.safe_to_max_imm = true;
                bs.reason = "bgez $rd (cull-when-far, safe)";
            } else {
                bs.reason = "bltz $rd (cull-when-near, UNSAFE)";
            }
        }
        return bs;
    }

    bs.reason = "not a conditional branch";
    return bs;
}

// ---------------------------------------------------------------------------
// PS-X EXE parser
// ---------------------------------------------------------------------------

static const char kPsxExeMagic[8] = {'P','S','-','X',' ','E','X','E'};

bool parse_psx_exe(const uint8_t* data, size_t size, PsxExeInfo& out) {
    // Search for the PS-X EXE magic in the first 64KB of the image.
    size_t search_end = std::min(size, static_cast<size_t>(0x10000));
    size_t magic_offset = size;
    for (size_t i = 0; i + 8 <= search_end; ++i) {
        if (std::memcmp(data + i, kPsxExeMagic, 8) == 0) {
            magic_offset = i;
            break;
        }
    }
    if (magic_offset >= size) return false;

    // Header is 0x800 bytes; the code starts at magic_offset + 0x800.
    if (magic_offset + 0x800 > size) return false;

    // Parse header fields (little-endian).
    const uint8_t* hdr = data + magic_offset;
    out.initial_pc = static_cast<uint32_t>(hdr[0x10]) |
                     (static_cast<uint32_t>(hdr[0x11]) << 8) |
                     (static_cast<uint32_t>(hdr[0x12]) << 16) |
                     (static_cast<uint32_t>(hdr[0x13]) << 24);
    out.text_addr = static_cast<uint32_t>(hdr[0x18]) |
                    (static_cast<uint32_t>(hdr[0x19]) << 8) |
                    (static_cast<uint32_t>(hdr[0x1A]) << 16) |
                    (static_cast<uint32_t>(hdr[0x1B]) << 24);
    out.text_size = static_cast<uint32_t>(hdr[0x1C]) |
                    (static_cast<uint32_t>(hdr[0x1D]) << 8) |
                    (static_cast<uint32_t>(hdr[0x1E]) << 16) |
                    (static_cast<uint32_t>(hdr[0x1F]) << 24);

    size_t code_offset = magic_offset + 0x800;
    if (out.text_size == 0 || out.text_size > 0x800000) {
        out.text_size = static_cast<uint32_t>(std::min(size - code_offset,
                                                       static_cast<size_t>(0x200000)));
    }
    size_t avail = std::min(size - code_offset, static_cast<size_t>(out.text_size));
    out.code.assign(data + code_offset, data + code_offset + avail);
    return true;
}

// ---------------------------------------------------------------------------
// MipsPatternScanner
// ---------------------------------------------------------------------------

MipsPatternScanner::MipsPatternScanner() = default;

bool MipsPatternScanner::check_branch_within(const std::vector<uint8_t>& code,
                                             size_t offset, int max_dist,
                                             std::string& br_type, int& br_dist) const {
    for (int j = 1; j <= max_dist && offset + static_cast<size_t>(j) * 4 + 4 <= code.size(); ++j) {
        size_t pos = offset + static_cast<size_t>(j) * 4;
        uint32_t word = static_cast<uint32_t>(code[pos]) |
                        (static_cast<uint32_t>(code[pos+1]) << 8) |
                        (static_cast<uint32_t>(code[pos+2]) << 16) |
                        (static_cast<uint32_t>(code[pos+3]) << 24);
        uint32_t op = mips::bits(word, 31, 26);
        uint32_t rt = mips::bits(word, 20, 16);

        if (op == mips::OP_BEQ)  { br_type = "beq";  br_dist = j; return true; }
        if (op == mips::OP_BNE)  { br_type = "bne";  br_dist = j; return true; }
        if (op == mips::OP_BLEZ) { br_type = "blez"; br_dist = j; return true; }
        if (op == mips::OP_BGTZ) { br_type = "bgtz"; br_dist = j; return true; }
        if (op == mips::OP_REGIMM) {
            if (rt == mips::RT_BLTZ) { br_type = "bltz"; br_dist = j; return true; }
            if (rt == mips::RT_BGEZ) { br_type = "bgez"; br_dist = j; return true; }
        }
        if (op == mips::OP_COP1) {
            uint32_t rs = mips::bits(word, 25, 21);
            if (rs == 0x08) {
                uint32_t tf = mips::bits(word, 16, 16);
                br_type = tf ? "bc1t" : "bc1f";
                br_dist = j;
                return true;
            }
        }
    }
    return false;
}

static inline ScanCandidate make_candidate(
    const std::string& pattern, uint32_t addr, int32_t value,
    const std::string& disasm, const std::string& br_type, int br_dist,
    size_t word_offset, uint32_t patch_word, bool auto_patchable,
    const std::vector<uint8_t>& code) {
    ScanCandidate c;
    c.pattern = pattern;
    c.address = addr;
    c.value = value;
    c.disasm = disasm;
    c.branch_type = br_type;
    c.word_offset = static_cast<uint32_t>(word_offset);
    c.patch_word = patch_word;
    c.auto_patchable = auto_patchable;
    if (word_offset + 4 <= code.size()) {
        std::memcpy(c.orig_bytes.data(), code.data() + word_offset, 4);
        if (auto_patchable) {
            uint32_t pw = patch_word;
            c.patch_bytes = {
                static_cast<uint8_t>(pw & 0xFF),
                static_cast<uint8_t>((pw >> 8) & 0xFF),
                static_cast<uint8_t>((pw >> 16) & 0xFF),
                static_cast<uint8_t>((pw >> 24) & 0xFF),
            };
        }
    }
    return c;
}

// ---------------------------------------------------------------------------
// Pattern 1: slti/sltiu + branch
// ---------------------------------------------------------------------------

void MipsPatternScanner::scan_pattern_1(const std::vector<uint8_t>& code,
                                        uint32_t text_addr,
                                        std::vector<ScanCandidate>& out) const {
    static const char* reg_names[32] = {
        "$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
        "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
        "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
        "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"
    };

    for (size_t i = 0; i + 8 <= code.size(); i += 4) {
        uint32_t word = read_code_word(code, i);
        uint32_t op = mips::bits(word, 31, 26);
        if (op != mips::OP_SLTI && op != mips::OP_SLTIU) continue;

        int32_t imm = mips::sign_extend_16(mips::bits(word, 15, 0));
        if (imm < min_val_ || imm > max_val_) continue;

        std::string br_type;
        int br_dist;
        if (!check_branch_within(code, i, 4, br_type, br_dist)) continue;

        uint32_t rs = mips::bits(word, 25, 21);
        uint32_t rt = mips::bits(word, 20, 16);

        // D3 fix: verify branch direction is cull-when-far (safe to max imm).
        size_t br_pos = i + static_cast<size_t>(br_dist) * 4;
        uint32_t br_word = read_code_word(code, br_pos);
        BranchSafety bs = analyze_branch_safety(br_word, rt, ResultType::ZeroOrOne);
        if (!bs.tests_result_reg || bs.degenerate) continue;

        const char* name = (op == mips::OP_SLTIU) ? "sltiu" : "slti";
        char disasm[192];
        std::snprintf(disasm, sizeof(disasm), "%s $%u, $%u, %d | %s | %s",
                      name, rt, rs, imm, br_type.c_str(), bs.reason.c_str());

        bool auto_patchable = bs.safe_to_max_imm;
        uint32_t patch = auto_patchable
            ? (op << 26) | (rs << 21) | (rt << 16) | (32767 & 0xFFFF)
            : 0;
        out.push_back(make_candidate(
            std::string("P1-") + name, text_addr + static_cast<uint32_t>(i),
            imm, disasm, br_type, br_dist, i, patch, auto_patchable, code));
    }
}

// ---------------------------------------------------------------------------
// Pattern 2: subu/sub + bltz/bgez
// ---------------------------------------------------------------------------

void MipsPatternScanner::scan_pattern_2(const std::vector<uint8_t>& code,
                                        uint32_t text_addr,
                                        std::vector<ScanCandidate>& out) const {
    if (code.size() < 12) return;
    for (size_t i = 4; i + 8 <= code.size(); i += 4) {
        uint32_t word = read_code_word(code, i);
        uint32_t op = mips::bits(word, 31, 26);
        uint32_t funct = mips::bits(word, 5, 0);
        if (op != mips::OP_SPECIAL || (funct != mips::F_SUB && funct != mips::F_SUBU)) continue;

        uint32_t rd = mips::bits(word, 15, 11);  // subu result register

        size_t prev_pos = i - 4;
        uint32_t prev_word = read_code_word(code, prev_pos);
        if (mips::bits(prev_word, 31, 26) != mips::OP_ADDIU) continue;
        int32_t prev_imm = mips::sign_extend_16(mips::bits(prev_word, 15, 0));
        if (std::abs(prev_imm) < min_val_ || std::abs(prev_imm) > max_val_) continue;

        if (i + 4 + 4 > code.size()) continue;
        size_t next_pos = i + 4;
        uint32_t next_word = read_code_word(code, next_pos);
        if (mips::bits(next_word, 31, 26) != mips::OP_REGIMM) continue;
        uint32_t next_rt = mips::bits(next_word, 20, 16);
        uint32_t next_rs = mips::bits(next_word, 25, 21);
        if (next_rt != mips::RT_BLTZ && next_rt != mips::RT_BGEZ) continue;
        if (next_rs != rd) continue;

        // D3 fix: subu result is GeneralValue (distance - threshold).
        // bgez = cull-when-far (safe), bltz = cull-when-near (unsafe).
        BranchSafety bs = analyze_branch_safety(next_word, rd, ResultType::GeneralValue);
        if (!bs.tests_result_reg || bs.degenerate) continue;

        uint32_t prev_rt_reg = mips::bits(prev_word, 20, 16);
        const char* br_name = (next_rt == mips::RT_BLTZ) ? "bltz" : "bgez";
        char disasm[192];
        std::snprintf(disasm, sizeof(disasm),
                      "addiu $%u, $zero, %d; sub%s + %s | %s",
                      prev_rt_reg, prev_imm,
                      (funct == mips::F_SUBU) ? "u" : "", br_name,
                      bs.reason.c_str());

        bool auto_patchable = bs.safe_to_max_imm;
        uint32_t patch = auto_patchable
            ? (mips::OP_ADDIU << 26) | (0 << 21) | (prev_rt_reg << 16) | (32767 & 0xFFFF)
            : 0;
        out.push_back(make_candidate(
            std::string("P2-") + (funct == mips::F_SUBU ? "subu+" : "sub+") + br_name,
            text_addr + static_cast<uint32_t>(prev_pos),
            std::abs(prev_imm), disasm, br_name, 2, prev_pos, patch, auto_patchable, code));
    }
}

// ---------------------------------------------------------------------------
// Pattern 3: addiu + bltz/bgez (add-negative compare)
// ---------------------------------------------------------------------------

void MipsPatternScanner::scan_pattern_3(const std::vector<uint8_t>& code,
                                        uint32_t text_addr,
                                        std::vector<ScanCandidate>& out) const {
    for (size_t i = 0; i + 8 <= code.size(); i += 4) {
        uint32_t word = read_code_word(code, i);
        if (mips::bits(word, 31, 26) != mips::OP_ADDIU) continue;
        int32_t imm = mips::sign_extend_16(mips::bits(word, 15, 0));
        if (imm >= 0 || std::abs(imm) < min_val_ || std::abs(imm) > max_val_) continue;

        uint32_t rt = mips::bits(word, 20, 16);
        uint32_t rs = mips::bits(word, 25, 21);

        size_t next_pos = i + 4;
        if (next_pos + 4 > code.size()) continue;
        uint32_t next_word = read_code_word(code, next_pos);
        if (mips::bits(next_word, 31, 26) != mips::OP_REGIMM) continue;
        uint32_t next_rt = mips::bits(next_word, 20, 16);
        uint32_t next_rs = mips::bits(next_word, 25, 21);
        if (next_rt != mips::RT_BLTZ && next_rt != mips::RT_BGEZ) continue;
        if (next_rs != rt) continue;

        // D3 fix: addiu result is GeneralValue (distance + negative_imm).
        // bgez = cull-when-far (safe), bltz = cull-when-near (unsafe).
        BranchSafety bs = analyze_branch_safety(next_word, rt, ResultType::GeneralValue);
        if (!bs.tests_result_reg || bs.degenerate) continue;

        const char* br_name = (next_rt == mips::RT_BLTZ) ? "bltz" : "bgez";
        char disasm[192];
        std::snprintf(disasm, sizeof(disasm),
                      "addiu $%u, $%u, %d; %s | %s",
                      rt, rs, imm, br_name, bs.reason.c_str());

        bool auto_patchable = bs.safe_to_max_imm;
        uint32_t patch = auto_patchable
            ? (mips::OP_ADDIU << 26) | (rs << 21) | (rt << 16) | (static_cast<uint32_t>(-32767) & 0xFFFF)
            : 0;
        out.push_back(make_candidate(
            std::string("P3-addiu+") + br_name,
            text_addr + static_cast<uint32_t>(i),
            std::abs(imm), disasm, br_name, 1, i, patch, auto_patchable, code));
    }
}

// ---------------------------------------------------------------------------
// Pattern 4: float compare (c.le.s/c.lt.s + bc1t/bc1f)
// ---------------------------------------------------------------------------

void MipsPatternScanner::scan_pattern_4(const std::vector<uint8_t>& code,
                                        uint32_t text_addr,
                                        std::vector<ScanCandidate>& out) const {
    for (size_t i = 0; i + 8 <= code.size(); i += 4) {
        uint32_t word = static_cast<uint32_t>(code[i]) |
                        (static_cast<uint32_t>(code[i+1]) << 8) |
                        (static_cast<uint32_t>(code[i+2]) << 16) |
                        (static_cast<uint32_t>(code[i+3]) << 24);
        if (mips::bits(word, 31, 26) != mips::OP_COP1) continue;
        uint32_t fmt = mips::bits(word, 25, 21);
        if (fmt != 0x10) continue;  // single precision
        uint32_t funct = mips::bits(word, 5, 0);
        if (funct != 0x3C && funct != 0x3D && funct != 0x3E && funct != 0x3F) continue;

        std::string br_type;
        int br_dist;
        if (!check_branch_within(code, i, 3, br_type, br_dist)) continue;

        const char* cond = (funct == 0x3C || funct == 0x3D) ? "c.lt.s" : "c.le.s";
        char disasm[128];
        std::snprintf(disasm, sizeof(disasm), "%s; %s", cond, br_type.c_str());

        out.push_back(make_candidate(
            "P4-float", text_addr + static_cast<uint32_t>(i),
            -1, disasm, br_type, br_dist, i, 0, false, code));
    }
}

// ---------------------------------------------------------------------------
// Pattern 5: GTE flag (cfc2 + andi + bne/beq)
// ---------------------------------------------------------------------------

void MipsPatternScanner::scan_pattern_5(const std::vector<uint8_t>& code,
                                        uint32_t text_addr,
                                        std::vector<ScanCandidate>& out) const {
    if (code.size() < 12) return;
    for (size_t i = 0; i + 12 <= code.size(); i += 4) {
        uint32_t word = static_cast<uint32_t>(code[i]) |
                        (static_cast<uint32_t>(code[i+1]) << 8) |
                        (static_cast<uint32_t>(code[i+2]) << 16) |
                        (static_cast<uint32_t>(code[i+3]) << 24);
        // Only match GTE READ instructions: mfc2 (rs=0x00) and cfc2 (rs=0x02).
        // Do NOT match lwc2 (op=0x32) — that's a GTE WRITE (memory→GTE),
        // not a read. lwc2 was previously misclassified as a GTE read,
        // causing false positives in code that writes to GTE.
        if (mips::bits(word, 31, 26) != mips::OP_COP2) continue;
        uint32_t rs = mips::bits(word, 25, 21);
        if (rs != 0x00 && rs != 0x02) continue;  // mfc2 or cfc2 only

        // Search for andi within 3 instructions.
        for (int j = 1; j <= 3 && i + static_cast<size_t>(j) * 4 + 4 <= code.size(); ++j) {
            size_t pos = i + static_cast<size_t>(j) * 4;
            uint32_t check = static_cast<uint32_t>(code[pos]) |
                             (static_cast<uint32_t>(code[pos+1]) << 8) |
                             (static_cast<uint32_t>(code[pos+2]) << 16) |
                             (static_cast<uint32_t>(code[pos+3]) << 24);
            if (mips::bits(check, 31, 26) != mips::OP_ANDI) continue;
            uint32_t andi_imm = mips::bits(check, 15, 0);
            if (andi_imm == 0) continue;

            std::string br_type;
            int br_dist;
            if (!check_branch_within(code, pos, 2, br_type, br_dist)) continue;

            char disasm[128];
            std::snprintf(disasm, sizeof(disasm),
                          "cfc2; andi 0x%04X; %s", andi_imm, br_type.c_str());
            out.push_back(make_candidate(
                "P5-GTE-flag", text_addr + static_cast<uint32_t>(i),
                static_cast<int32_t>(andi_imm), disasm, br_type, j + 1,
                i, 0, false, code));
            break;
        }
    }
}

// ---------------------------------------------------------------------------
// Pattern 6: sltu range check
// ---------------------------------------------------------------------------

void MipsPatternScanner::scan_pattern_6(const std::vector<uint8_t>& code,
                                        uint32_t text_addr,
                                        std::vector<ScanCandidate>& out) const {
    if (code.size() < 12) return;
    for (size_t i = 4; i + 8 <= code.size(); i += 4) {
        uint32_t word = read_code_word(code, i);
        if (mips::bits(word, 31, 26) != mips::OP_SPECIAL) continue;
        if (mips::bits(word, 5, 0) != mips::F_SLTU) continue;

        uint32_t rd = mips::bits(word, 15, 11);  // sltu result register

        size_t prev_pos = i - 4;
        uint32_t prev_word = read_code_word(code, prev_pos);
        if (mips::bits(prev_word, 31, 26) != mips::OP_ADDIU) continue;
        int32_t prev_imm = mips::sign_extend_16(mips::bits(prev_word, 15, 0));
        if (prev_imm < min_val_ || prev_imm > max_val_) continue;

        std::string br_type;
        int br_dist;
        if (!check_branch_within(code, i, 2, br_type, br_dist)) continue;

        // D3 fix: sltu result is ZeroOrOne (like slti).
        size_t br_pos = i + static_cast<size_t>(br_dist) * 4;
        uint32_t br_word = read_code_word(code, br_pos);
        BranchSafety bs = analyze_branch_safety(br_word, rd, ResultType::ZeroOrOne);
        if (!bs.tests_result_reg || bs.degenerate) continue;

        uint32_t prev_rt_reg = mips::bits(prev_word, 20, 16);
        char disasm[192];
        std::snprintf(disasm, sizeof(disasm),
                      "addiu $%u, $zero, %d; sltu + %s | %s",
                      prev_rt_reg, prev_imm, br_type.c_str(), bs.reason.c_str());

        bool auto_patchable = bs.safe_to_max_imm;
        uint32_t patch = auto_patchable
            ? (mips::OP_ADDIU << 26) | (0 << 21) | (prev_rt_reg << 16) | (32767 & 0xFFFF)
            : 0;
        out.push_back(make_candidate(
            "P6-sltu-range", text_addr + static_cast<uint32_t>(prev_pos),
            prev_imm, disasm, br_type, br_dist, prev_pos, patch, auto_patchable, code));
    }
}

// ---------------------------------------------------------------------------
// Scan + manifest
// ---------------------------------------------------------------------------

std::vector<ScanCandidate> MipsPatternScanner::scan(const PsxExeInfo& exe) const {
    auto t0 = std::chrono::high_resolution_clock::now();
    stats_ = {};
    std::vector<ScanCandidate> all;

    scan_pattern_1(exe.code, exe.text_addr, all);
    scan_pattern_2(exe.code, exe.text_addr, all);
    scan_pattern_3(exe.code, exe.text_addr, all);
    scan_pattern_6(exe.code, exe.text_addr, all);
    if (scan_floats_) {
        scan_pattern_4(exe.code, exe.text_addr, all);
    }
    scan_pattern_5(exe.code, exe.text_addr, all);

    // Sort: auto-patchable first, then by closeness to value 200.
    std::sort(all.begin(), all.end(), [](const ScanCandidate& a, const ScanCandidate& b) {
        if (a.auto_patchable != b.auto_patchable) return a.auto_patchable;
        int da = (a.value > 0) ? std::abs(a.value - 200) : 9999;
        int db = (b.value > 0) ? std::abs(b.value - 200) : 9999;
        return da < db;
    });

    auto t1 = std::chrono::high_resolution_clock::now();
    stats_.scan_time_us = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count());
    stats_.total_candidates = static_cast<uint32_t>(all.size());
    stats_.auto_patchable = static_cast<uint32_t>(
        std::count_if(all.begin(), all.end(),
                      [](const ScanCandidate& c) { return c.auto_patchable; }));
    stats_.float_candidates = static_cast<uint32_t>(
        std::count_if(all.begin(), all.end(),
                      [](const ScanCandidate& c) { return c.pattern == "P4-float"; }));
    stats_.gte_candidates = static_cast<uint32_t>(
        std::count_if(all.begin(), all.end(),
                      [](const ScanCandidate& c) { return c.pattern == "P5-GTE-flag"; }));

    return all;
}

PatchManifest MipsPatternScanner::to_manifest(
    const std::vector<ScanCandidate>& candidates,
    const ExecutableSignature& exe_sig,
    const std::string& display_name) const {
    PatchManifest m;
    m.exe_signature = exe_sig;
    m.display_name = display_name + " (auto-discovered)";
    m.recommend_8mb_ram = false;

    int idx = 0;
    for (const auto& c : candidates) {
        if (!c.auto_patchable) continue;
        if (++idx > 30) break;  // cap to avoid overwhelming

        PatchEntry pe;
        char name[128];
        std::snprintf(name, sizeof(name), "candidate_%d_%s_addr_%08X",
                      idx, c.pattern.c_str(), c.address);
        pe.name = name;

        char desc[256];
        std::snprintf(desc, sizeof(desc), "%s | original_value=%d | maxed_to=32767",
                      c.disasm.c_str(), c.value);
        pe.description = desc;

        // AOB pattern: the original 4 bytes.
        char pattern_hex[32];
        std::snprintf(pattern_hex, sizeof(pattern_hex), "%02X %02X %02X %02X",
                      c.orig_bytes[0], c.orig_bytes[1],
                      c.orig_bytes[2], c.orig_bytes[3]);
        pe.pattern_hex = pattern_hex;

        char repl_hex[32];
        std::snprintf(repl_hex, sizeof(repl_hex), "%02X %02X %02X %02X",
                      c.patch_bytes[0], c.patch_bytes[1],
                      c.patch_bytes[2], c.patch_bytes[3]);
        pe.replacement_hex = repl_hex;

        pe.category = (c.value < 500) ? PatchEntry::Category::StreamingBudget
                                      : PatchEntry::Category::LodDistance;
        pe.requires_8mb = (c.value > 200);
        if (pe.requires_8mb) m.recommend_8mb_ram = true;

        m.patches.push_back(std::move(pe));
    }

    return m;
}

}  // namespace rsil
