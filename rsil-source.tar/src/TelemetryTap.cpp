// SPDX-License-Identifier: BSD-3-Clause
// RSIL — TelemetryTap implementation.

#include "rsil/TelemetryTap.h"

#include <algorithm>

namespace rsil {

void TelemetryTap::add_sink(TelemetrySink* sink) {
    std::lock_guard<std::mutex> g(sinks_mu_);
    sinks_.push_back(sink);
}

void TelemetryTap::remove_sink(TelemetrySink* sink) {
    std::lock_guard<std::mutex> g(sinks_mu_);
    auto it = std::find(sinks_.begin(), sinks_.end(), sink);
    if (it != sinks_.end()) sinks_.erase(it);
}

void TelemetryTap::emit_gpu_command(uint32_t address, uint32_t word, FrameId frame) {
    GpuCommandWord w{address, word, frame};
    std::vector<TelemetrySink*> snapshot;
    {
        std::lock_guard<std::mutex> g(sinks_mu_);
        snapshot = sinks_;
    }
    for (auto* s : snapshot) s->on_gpu_command(w);
}

void TelemetryTap::emit_dma_packet(uint8_t channel, uint32_t source_ram,
                                   uint32_t dest_vram, uint32_t word_count,
                                   FrameId frame) {
    DmaPacketObservation p{channel, source_ram, dest_vram, word_count, frame};
    std::vector<TelemetrySink*> snapshot;
    {
        std::lock_guard<std::mutex> g(sinks_mu_);
        snapshot = sinks_;
    }
    for (auto* s : snapshot) s->on_dma_packet(p);
}

void TelemetryTap::emit_frame_boundary(FrameId frame) {
    std::vector<TelemetrySink*> snapshot;
    {
        std::lock_guard<std::mutex> g(sinks_mu_);
        snapshot = sinks_;
    }
    for (auto* s : snapshot) s->on_frame_boundary(frame);
}

}  // namespace rsil
