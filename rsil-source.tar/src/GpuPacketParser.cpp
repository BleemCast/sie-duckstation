// SPDX-License-Identifier: BSD-3-Clause
// RSIL — PS1 GPU packet parser implementation.

#include "rsil/GpuPacketParser.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace rsil {

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

// Packet lengths (including the command word) for each GP0 command.
// Unknown/uninteresting commands return 0 (skipped one word at a time).

// Polygon commands (0x20-0x3F):
//   bit 0 (0x01): Translucent
//   bit 2 (0x04): Textured
//   bit 3 (0x08): Quad (4 vertices) vs Triangle (3 vertices)
//   bit 4 (0x10): Gouraud shading
static uint32_t polygon_packet_length(uint8_t cmd) {
    const bool textured  = (cmd & 0x04) != 0;
    const bool gouraud   = (cmd & 0x10) != 0;
    const bool quad      = (cmd & 0x08) != 0;
    const uint32_t vcount = quad ? 4 : 3;

    if (textured && gouraud) {
        // cmd + vcount*(color + vertex + texcoord) = 1 + vcount*3
        return 1 + vcount * 3;
    } else if (textured) {
        // cmd + color + vcount*(vertex + texcoord) = 1 + 1 + vcount*2
        return 2 + vcount * 2;
    } else if (gouraud) {
        // cmd + vcount*(color + vertex) = 1 + vcount*2
        return 1 + vcount * 2;
    } else {
        // cmd + color + vcount*vertex = 1 + 1 + vcount
        return 2 + vcount;
    }
}

// Line commands (0x40-0x5F):
//   bit 0 (0x01): Translucent
//   bit 3 (0x08): Gouraud
//   bit 4 (0x10): Polyline (variable length)
static uint32_t line_packet_length(uint8_t cmd) {
    const bool gouraud  = (cmd & 0x08) != 0;
    const bool polyline = (cmd & 0x10) != 0;
    if (polyline) return 0;  // variable length; skip
    if (gouraud) return 5;   // cmd + 2*(color + vertex)
    return 4;                // cmd + color + 2*vertex
}

// Rectangle commands (0x60-0x7F):
//   cmd + color + pos + size = 4 (monochrome, variable size)
//   cmd + color + pos + texcoord + size = 5 (textured, variable size)
//   Sized rects (1x1, 8x8, 16x16) omit the size word.
// Size field is bits 4-3 of the command byte:
//   0x60-0x67: variable (need size word)
//   0x68-0x6F: 1x1
//   0x70-0x77: 8x8
//   0x78-0x7F: 16x16
static uint32_t rectangle_packet_length(uint8_t cmd) {
    const bool textured = (cmd & 0x04) != 0;
    const uint8_t size_field = (cmd >> 3) & 0x03;
    const bool variable_size = (size_field == 0);

    if (textured) {
        return variable_size ? 5 : 4;  // +1 for size, +1 for texcoord
    } else {
        return variable_size ? 4 : 3;  // +1 for size
    }
}

// VRAM transfer commands:
//   0xA0: VRAM write — cmd + source + dest + size + data... (variable)
//   0xC0: VRAM read  — cmd + source + dest + size = 4 words
// VRAM writes have variable-length data; we skip them (return 0).
// For RSIL's purposes, we don't need to parse VRAM transfers — they
// don't produce PrimitiveObservations.

// Special/render-state commands (0xE0-0xFF):
//   0xE1-0xE6: 1 word each (command + parameter packed into one word)
//   0xE1: Set texpage (we track this)
static uint32_t special_packet_length(uint8_t cmd) {
    (void)cmd;
    return 1;  // all 0xE1-0xE6 are single-word
}

// ---------------------------------------------------------------------------
// GpuPacketParser
// ---------------------------------------------------------------------------

GpuPacketParser::GpuPacketParser() {
    packet_words_.reserve(16);
}

uint32_t GpuPacketParser::packet_length(uint8_t cmd) {
    // Polygon: 0x20-0x3F
    if (cmd >= 0x20 && cmd <= 0x3F) return polygon_packet_length(cmd);
    // Line: 0x40-0x5F
    if (cmd >= 0x40 && cmd <= 0x5F) return line_packet_length(cmd);
    // Rectangle: 0x60-0x7F
    if (cmd >= 0x60 && cmd <= 0x7F) return rectangle_packet_length(cmd);
    // VRAM write: 0xA0 (variable — skip)
    if (cmd == 0xA0) return 0;
    // VRAM read: 0xC0
    if (cmd == 0xC0) return 4;
    // Render state: 0xE1-0xE6
    if (cmd >= 0xE1 && cmd <= 0xE6) return 1;
    // Misc/unknown
    return 0;
}

void GpuPacketParser::on_word(uint32_t word, FrameId frame) {
    stats_.words_consumed++;

    // D12 fix: desync watchdog. Max GP0 packet is 13 words (textured gouraud
    // quad). If Accumulating state persists beyond 16 words, the FIFO has
    // desynced — force-reset to prevent cascade corruption of all subsequent
    // telemetry.
    if (state_ == State::Accumulating && packet_words_.size() >= 16) {
        stats_.desyncs++;
        state_ = State::Idle;
        packet_words_.clear();
        words_expected_ = 0;
        pending_cmd_ = 0;
    }

    if (state_ == State::Idle) {
        // PS1 GP0 command byte is in the HIGH byte of the 32-bit word.
        // The low 24 bits are the first parameter (typically color for
        // drawing primitives, or the texpage register for 0xE1).
        const uint8_t cmd = static_cast<uint8_t>((word >> 24) & 0xFFu);

        // Handle render-state commands immediately (single-word).
        if (cmd == 0xE1) {
            // Set texpage. The texpage register is in the LOW 11 bits of
            // the word (bits 0-10).
            current_texpage_ = static_cast<TexpageId>(word & 0x07FFu);
            stats_.packets_parsed++;
            return;
        }
        if (cmd >= 0xE2 && cmd <= 0xE6) {
            // Other render state — ignore for RSIL purposes.
            stats_.packets_parsed++;
            return;
        }

        const uint32_t len = packet_length(cmd);
        if (len == 0) {
            // Unknown or variable-length command. Skip this word and
            // stay in Idle. This is a limitation: for VRAM writes and
            // polylines, we can't determine packet boundaries from a
            // single word. In practice this means RSIL misses those
            // primitives, which is acceptable (they're not track geometry).
            stats_.desyncs++;
            return;
        }

        pending_cmd_ = cmd;
        words_expected_ = len;
        packet_words_.clear();
        packet_words_.push_back(word);
        state_ = (len == 1) ? State::Idle : State::Accumulating;

        if (len == 1) {
            parse_packet(frame);
        }
    } else if (state_ == State::Accumulating) {
        packet_words_.push_back(word);
        if (packet_words_.size() >= words_expected_) {
            parse_packet(frame);
            state_ = State::Idle;
        }
    }
}

void GpuPacketParser::reset() {
    state_ = State::Idle;
    packet_words_.clear();
    words_expected_ = 0;
    pending_cmd_ = 0;
}

void GpuPacketParser::parse_packet(FrameId frame) {
    stats_.packets_parsed++;
    // Command byte is in the HIGH byte of the first word.
    const uint8_t cmd = pending_cmd_;

    // Only emit observations for drawing primitives.
    if (cmd < 0x20 || cmd > 0x7F) return;

    PrimitiveObservation obs;
    obs.attrs.raw_cmd = cmd;
    obs.attrs.textured = (cmd & 0x04) != 0;
    obs.attrs.gouraud  = (cmd & 0x10) != 0;  // bit 4 = gouraud
    obs.attrs.blended  = (cmd & 0x01) != 0;  // translucent
    obs.attrs.lit      = (cmd & 0x10) != 0;  // gouraud implies lit

    std::vector<std::array<int16_t, 2>> vertices;

    if (cmd >= 0x20 && cmd <= 0x3F) {
        // ---- Polygon ----
        obs.topology = PrimitiveTopology::Polygon;
        const bool textured  = obs.attrs.textured;
        const bool gouraud   = obs.attrs.gouraud;
        const bool quad      = (cmd & 0x08) != 0;  // bit 3 = quad
        obs.vertex_count = quad ? 4 : 3;

        // Parse vertices based on the packet layout.
        // Word 0: command. Then the layout varies:
        //   mono:       color, v1, v2, v3[, v4]
        //   textured:   color, v1, tc1, v2, tc2, v3, tc3[, v4, tc4]
        //   gouraud:    c1, v1, c2, v2, c3, v3[, c4, v4]
        //   tex+gour:   c1, v1, tc1, c2, v2, tc2, ...
        size_t idx = 1;  // skip command word
        if (textured && gouraud) {
            // Per-vertex: color, vertex, texcoord
            for (uint32_t i = 0; i < obs.vertex_count && idx + 2 < packet_words_.size(); ++i) {
                idx++;  // skip color
                auto xy = extract_xy(packet_words_[idx++]);
                vertices.push_back(xy);
                uint32_t tc_word = packet_words_[idx++];
                if (i == 0) obs.attrs.clut = extract_clut(tc_word);
                if (i == 1) obs.attrs.texpage = extract_texpage(tc_word);
            }
        } else if (textured) {
            // Single color, then per-vertex: vertex, texcoord
            idx++;  // skip color
            for (uint32_t i = 0; i < obs.vertex_count && idx + 1 < packet_words_.size(); ++i) {
                auto xy = extract_xy(packet_words_[idx++]);
                vertices.push_back(xy);
                uint32_t tc_word = packet_words_[idx++];
                if (i == 0) obs.attrs.clut = extract_clut(tc_word);
                if (i == 1) obs.attrs.texpage = extract_texpage(tc_word);
            }
        } else if (gouraud) {
            // Per-vertex: color, vertex
            for (uint32_t i = 0; i < obs.vertex_count && idx + 1 < packet_words_.size(); ++i) {
                idx++;  // skip color
                auto xy = extract_xy(packet_words_[idx++]);
                vertices.push_back(xy);
            }
        } else {
            // Monochrome: color, then vertices
            idx++;  // skip color
            for (uint32_t i = 0; i < obs.vertex_count && idx < packet_words_.size(); ++i) {
                auto xy = extract_xy(packet_words_[idx++]);
                vertices.push_back(xy);
            }
        }

        // If textured but no embedded texpage was found, use the default.
        if (textured && obs.attrs.texpage == 0) {
            obs.attrs.texpage = current_texpage_;
        }
    } else if (cmd >= 0x40 && cmd <= 0x5F) {
        // ---- Line ----
        obs.topology = PrimitiveTopology::Line;
        obs.vertex_count = 2;
        const bool gouraud = obs.attrs.gouraud;
        size_t idx = 1;
        if (gouraud) {
            // Per-vertex: color, vertex
            for (uint32_t i = 0; i < 2 && idx + 1 < packet_words_.size(); ++i) {
                idx++;
                auto xy = extract_xy(packet_words_[idx++]);
                vertices.push_back(xy);
            }
        } else {
            idx++;  // skip color
            for (uint32_t i = 0; i < 2 && idx < packet_words_.size(); ++i) {
                auto xy = extract_xy(packet_words_[idx++]);
                vertices.push_back(xy);
            }
        }
    } else if (cmd >= 0x60 && cmd <= 0x7F) {
        // ---- Rectangle (sprite) ----
        obs.topology = PrimitiveTopology::Sprite;
        obs.vertex_count = 4;  // rectangles are quads conceptually
        obs.attrs.textured = (cmd & 0x04) != 0;
        const uint8_t size_field = (cmd >> 3) & 0x03;
        const bool variable_size = (size_field == 0);

        size_t idx = 1;
        idx++;  // skip color

        // Position vertex
        if (idx < packet_words_.size()) {
            auto xy = extract_xy(packet_words_[idx++]);
            vertices.push_back(xy);
        }

        // Texcoord (if textured)
        if (obs.attrs.textured && idx < packet_words_.size()) {
            uint32_t tc_word = packet_words_[idx++];
            obs.attrs.clut = extract_clut(tc_word);
        }

        // Size (if variable)
        int16_t w = 1, h = 1;
        if (variable_size && idx < packet_words_.size()) {
            uint32_t size_word = packet_words_[idx++];
            w = static_cast<int16_t>(size_word & 0xFFFFu);
            h = static_cast<int16_t>((size_word >> 16) & 0xFFFFu);
        } else {
            switch (size_field) {
                case 1: w = 1; h = 1; break;
                case 2: w = 8; h = 8; break;
                case 3: w = 16; h = 16; break;
            }
        }

        // Expand the rectangle into 4 corners for bbox computation.
        if (!vertices.empty()) {
            int16_t x0 = vertices[0][0], y0 = vertices[0][1];
            vertices.clear();
            vertices.push_back({x0,     y0});
            vertices.push_back({(int16_t)(x0 + w), y0});
            vertices.push_back({(int16_t)(x0 + w), (int16_t)(y0 + h)});
            vertices.push_back({x0,     (int16_t)(y0 + h)});
        }

        if (obs.attrs.textured && obs.attrs.texpage == 0) {
            obs.attrs.texpage = current_texpage_;
        }
    }

    // Compute normalized bbox from the vertices we extracted.
    if (!vertices.empty()) {
        obs.bbox = compute_normalized_bbox(vertices);
    }

    stats_.primitives_emitted++;
    if (on_primitive) {
        on_primitive(obs);
    }
}

TexpageId GpuPacketParser::extract_texpage(uint32_t texcoord_word) {
    // The texpage is in the upper 16 bits of the texcoord word.
    // We extract the full 16-bit field as an opaque identifier.
    // The host adapter interprets the bit fields (TP X, TP Y, ABR, TP color depth).
    return static_cast<TexpageId>((texcoord_word >> 16) & 0xFFFFu);
}

ClutId GpuPacketParser::extract_clut(uint32_t texcoord_word) {
    // The CLUT base is in the upper 16 bits of the FIRST texcoord word.
    // Same extraction as texpage — the field is opaque to RSIL.
    return static_cast<ClutId>((texcoord_word >> 16) & 0xFFFFu);
}

std::array<int16_t, 2> GpuPacketParser::extract_xy(uint32_t vertex_word) {
    // PS1 vertex words pack X in the low 16 bits and Y in the high 16 bits.
    // Both are signed 16-bit values in screen space (offset from drawing area).
    int16_t x = static_cast<int16_t>(vertex_word & 0xFFFFu);
    int16_t y = static_cast<int16_t>((vertex_word >> 16) & 0xFFFFu);
    return {x, y};
}

NormalizedBBox GpuPacketParser::compute_normalized_bbox(
    const std::vector<std::array<int16_t, 2>>& vertices) {
    NormalizedBBox bbox = {};

    if (vertices.empty()) return bbox;

    // Compute raw min/max in 2D (PS1 primitives are 2D in screen space;
    // we use Z=0 for all vertices, so the bbox is flat in Z).
    int32_t min_x = vertices[0][0], max_x = min_x;
    int32_t min_y = vertices[0][1], max_y = min_y;

    for (const auto& v : vertices) {
        min_x = std::min(min_x, (int32_t)v[0]);
        max_x = std::max(max_x, (int32_t)v[0]);
        min_y = std::min(min_y, (int32_t)v[1]);
        max_y = std::max(max_y, (int32_t)v[1]);
    }

    // Compute centroid.
    int32_t cx = (min_x + max_x) / 2;
    int32_t cy = (min_y + max_y) / 2;

    // Compute max axis extent (half-diagonal). We use the maximum of
    // (max - centroid) and (centroid - min) across both axes. This is
    // the normalization factor — we divide all deltas by this value.
    int32_t extent_x = std::max(max_x - cx, cx - min_x);
    int32_t extent_y = std::max(max_y - cy, cy - min_y);
    int32_t max_extent = std::max({extent_x, extent_y, (int32_t)1});

    // Normalize: (v - centroid) / max_extent, quantized to int16 range.
    // We scale by 32000 (not 32767) to leave headroom and avoid overflow
    // during clustering aggregation.
    const int32_t SCALE = 32000;

    bbox.min_delta[0] = static_cast<int16_t>(
        ((min_x - cx) * SCALE) / max_extent);
    bbox.max_delta[0] = static_cast<int16_t>(
        ((max_x - cx) * SCALE) / max_extent);
    bbox.min_delta[1] = static_cast<int16_t>(
        ((min_y - cy) * SCALE) / max_extent);
    bbox.max_delta[1] = static_cast<int16_t>(
        ((max_y - cy) * SCALE) / max_extent);
    bbox.min_delta[2] = 0;
    bbox.max_delta[2] = 0;

    return bbox;
}

}  // namespace rsil
