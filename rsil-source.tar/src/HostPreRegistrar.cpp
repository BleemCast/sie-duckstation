// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Host pre-registration manager implementation.

#include "rsil/HostPreRegistrar.h"

#include <algorithm>
#include <chrono>

namespace rsil {

void HostPreRegistrar::on_requests(const std::vector<PreRegistrationRequest>& reqs,
                                   FrameId frame) {
    if (!cfg_.flags.preregister) return;

    for (const auto& r : reqs) {
        if (r.signature_id == kInvalidSignature) continue;

        auto it = active_.find(r.signature_id);
        if (it != active_.end()) {
            // Refresh existing slot.
            it->second.last_refreshed = frame;
            it->second.confidence =
                std::max(it->second.confidence, 0.5f);  // floor on refresh
            continue;
        }

        // Enforce cap.
        if (active_.size() >= cfg_.max_active_preregs) {
            // Evict lowest-confidence slot.
            auto victim = std::min_element(active_.begin(), active_.end(),
                [](const auto& a, const auto& b) {
                    return a.second.confidence < b.second.confidence;
                });
            if (victim != active_.end()) {
                host_.release_preregistration(victim->second.token);
                active_.erase(victim);
                stats_.total_evicted++;
            }
        }

        ActiveSlot slot;
        slot.signature = r.signature_id;
        slot.token = host_.preregister_descriptor(r.texpage, r.clut, r.hint_cell);
        if (r.elevate_priority && cfg_.host_priority_elevation_enabled) {
            host_.elevate_priority(2000);  // 2ms hint
            stats_.priority_elevations++;
        }
        // Pass the REAL PrimitiveAttributes (texpage, clut, raw_cmd,
        // textured/gouraud/blended/lit flags) to the shader pre-compiler.
        // Previously this passed a default-constructed struct (all zeros),
        // making shader pre-compilation useless.
        host_.preregister_shader(r.attrs);
        host_.preregister_pipeline(r.signature_id);
        // Note: culler feed (neighbor list) is issued from the main pump
        // path, not from the pre-registrar, to keep this class narrowly
        // focused on descriptor/shader/pipeline allocation.
        slot.confidence = 0.5f;  // initial; updated by graph decay
        slot.last_refreshed = frame;
        if (slot.token != kInvalidToken) {
            active_.emplace(r.signature_id, std::move(slot));
            stats_.total_issued++;
        }
    }
    stats_.active_slots = static_cast<uint32_t>(active_.size());
}

void HostPreRegistrar::on_host_eviction(HostPreRegToken token) {
    for (auto it = active_.begin(); it != active_.end(); ++it) {
        if (it->second.token == token) {
            active_.erase(it);
            stats_.total_evicted++;
            return;
        }
    }
}

void HostPreRegistrar::gc(FrameId frame) {
    const float low_water = cfg_.prereg_confidence_threshold * 0.25f;
    for (auto it = active_.begin(); it != active_.end(); ) {
        // Confidence decays over time as the graph's WMA pulls it down.
        // We simulate decay here by applying a per-frame multiplier.
        it->second.confidence *= 0.995f;
        if (it->second.confidence < low_water) {
            host_.release_preregistration(it->second.token);
            it = active_.erase(it);
            stats_.total_evicted++;
        } else {
            ++it;
        }
    }
    stats_.active_slots = static_cast<uint32_t>(active_.size());
    (void)frame;
}

}  // namespace rsil
