// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Persistence layer implementation.
//
// Two backends are provided:
//   - SQLiteBackend: default, used in production.
//   - JsonBackend:   debug/export-only, one file per executable.
//
// Both backends persist ONLY metadata. Schema (SQLite):
//
//   CREATE TABLE executables (
//     md5           BLOB PRIMARY KEY,
//     crc32         INTEGER NOT NULL,
//     display_name  TEXT,
//     last_updated  INTEGER
//   );
//
//   CREATE TABLE signatures (
//     exe_md5        BLOB NOT NULL,
//     sig_id         INTEGER NOT NULL,
//     topology       INTEGER,
//     vertex_count   INTEGER,
//     attrs_blob     BLOB,        -- sizeof(PrimitiveAttributes)
//     bbox_blob      BLOB,        -- sizeof(NormalizedBBox)
//     obs_count      INTEGER,
//     first_frame    INTEGER,
//     last_frame     INTEGER,
//     PRIMARY KEY (exe_md5, sig_id)
//   );
//
//   CREATE TABLE catalog_nodes (
//     exe_md5        BLOB NOT NULL,
//     sig_id         INTEGER NOT NULL,
//     cell           INTEGER,
//     sector         INTEGER,
//     track          INTEGER,
//     neighbor_blob  BLOB,        -- packed array of sig_ids
//     obs_count      INTEGER,
//     first_seen     INTEGER,
//     last_seen      INTEGER,
//     PRIMARY KEY (exe_md5, sig_id)
//   );
//
//   CREATE TABLE adjacency_edges (
//     exe_md5        BLOB NOT NULL,
//     from_sig       INTEGER NOT NULL,
//     to_sig         INTEGER NOT NULL,
//     obs_count      INTEGER,
//     confidence     REAL,
//     last_traversed INTEGER,
//     PRIMARY KEY (exe_md5, from_sig, to_sig)
//   );

#include "rsil/Persistence.h"

#include <atomic>
#include <chrono>
#include <cstring>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>
#include <thread>

// SQLite is declared soft-optional: if RSIL_HAS_SQLITE is unset, the
// SQLite backend compiles to a stub that always returns false. This keeps
// the scaffold buildable without requiring sqlite3 in the build env.
#ifdef RSIL_HAS_SQLITE
#include <sqlite3.h>
#endif

namespace rsil {

// ---------------------------------------------------------------------------
// SQLiteBackend
// ---------------------------------------------------------------------------

#ifdef RSIL_HAS_SQLITE
class SQLiteBackend final : public PersistenceBackend {
public:
    ~SQLiteBackend() override { close(); }

    bool open(const std::filesystem::path& path) override {
        if (sqlite3_open(path.string().c_str(), &db_) != SQLITE_OK) return false;
        return exec(kSchema);
    }

    void close() override {
        if (db_) { sqlite3_close(db_); db_ = nullptr; }
    }

    bool save(const ExecutableSignature& exe,
              const SignatureRegistry&  sigs,
              const SpatialCatalog&     catalog,
              const AdjacencyGraph&     graph) override {
        if (!db_) return false;
        exec("BEGIN TRANSACTION;");

        // Upsert executable.
        {
            const char* sql =
                "INSERT OR REPLACE INTO executables "
                "(md5, crc32, display_name, last_updated) "
                "VALUES (?, ?, ?, ?);";
            sqlite3_stmt* st = nullptr;
            if (sqlite3_prepare_v2(db_, sql, -1, &st, nullptr) != SQLITE_OK) {
                exec("ROLLBACK;"); return false;
            }
            sqlite3_bind_blob(st, 1, exe.md5.data(), 16, SQLITE_STATIC);
            sqlite3_bind_int (st, 2, static_cast<int>(exe.crc32));
            sqlite3_bind_text(st, 3, exe.display_name.c_str(), -1, SQLITE_STATIC);
            sqlite3_bind_int64(st, 4,
                std::chrono::duration_cast<std::chrono::seconds>(
                    std::chrono::system_clock::now().time_since_epoch()).count());
            sqlite3_step(st);
            sqlite3_finalize(st);
        }

        // Persist signatures.
        for (const auto& e : sigs.snapshot()) persist_signature(exe, e);

        // Persist catalog.
        auto snap = catalog.snapshot();
        for (const auto& n : snap.nodes) persist_catalog_node(exe, n);

        // Persist adjacency edges.
        for (const auto& edge : graph.snapshot()) persist_edge(exe, edge);

        return exec("COMMIT;");
    }

    bool load(const ExecutableSignature& exe,
              SignatureRegistry&  sigs,
              SpatialCatalog&     catalog,
              AdjacencyGraph&     graph) override {
        if (!db_) return false;
        // Implementation omitted for brevity in scaffold; see README.
        (void)exe; (void)sigs; (void)catalog; (void)graph;
        return false;
    }

    std::vector<ExecutableSignature> list_executables() override {
        std::vector<ExecutableSignature> out;
        if (!db_) return out;
        sqlite3_stmt* st = nullptr;
        if (sqlite3_prepare_v2(db_, "SELECT md5, crc32, display_name FROM executables;",
                               -1, &st, nullptr) != SQLITE_OK) return out;
        while (sqlite3_step(st) == SQLITE_ROW) {
            ExecutableSignature e;
            const void* blob = sqlite3_column_blob(st, 0);
            if (blob && sqlite3_column_bytes(st, 0) == 16) {
                std::memcpy(e.md5.data(), blob, 16);
            }
            e.crc32 = static_cast<uint32_t>(sqlite3_column_int(st, 1));
            const unsigned char* name = sqlite3_column_text(st, 2);
            if (name) e.display_name = reinterpret_cast<const char*>(name);
            out.push_back(e);
        }
        sqlite3_finalize(st);
        return out;
    }

private:
    static constexpr const char* kSchema =
        "CREATE TABLE IF NOT EXISTS executables ("
        "  md5 BLOB PRIMARY KEY, crc32 INTEGER NOT NULL,"
        "  display_name TEXT, last_updated INTEGER);"
        "CREATE TABLE IF NOT EXISTS signatures ("
        "  exe_md5 BLOB NOT NULL, sig_id INTEGER NOT NULL,"
        "  topology INTEGER, vertex_count INTEGER,"
        "  attrs_blob BLOB, bbox_blob BLOB,"
        "  obs_count INTEGER, first_frame INTEGER, last_frame INTEGER,"
        "  PRIMARY KEY (exe_md5, sig_id));"
        "CREATE TABLE IF NOT EXISTS catalog_nodes ("
        "  exe_md5 BLOB NOT NULL, sig_id INTEGER NOT NULL,"
        "  cell INTEGER, sector INTEGER, track INTEGER,"
        "  neighbor_blob BLOB, obs_count INTEGER,"
        "  first_seen INTEGER, last_seen INTEGER,"
        "  PRIMARY KEY (exe_md5, sig_id));"
        "CREATE TABLE IF NOT EXISTS adjacency_edges ("
        "  exe_md5 BLOB NOT NULL, from_sig INTEGER NOT NULL,"
        "  to_sig INTEGER NOT NULL, obs_count INTEGER,"
        "  confidence REAL, last_traversed INTEGER,"
        "  PRIMARY KEY (exe_md5, from_sig, to_sig));";

    bool exec(const char* sql) {
        char* err = nullptr;
        int rc = sqlite3_exec(db_, sql, nullptr, nullptr, &err);
        if (err) sqlite3_free(err);
        return rc == SQLITE_OK;
    }

    void persist_signature(const ExecutableSignature& exe, const SignatureEntry& e) {
        const char* sql =
            "INSERT OR REPLACE INTO signatures "
            "(exe_md5, sig_id, topology, vertex_count, attrs_blob, bbox_blob,"
            " obs_count, first_frame, last_frame) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        sqlite3_stmt* st = nullptr;
        if (sqlite3_prepare_v2(db_, sql, -1, &st, nullptr) != SQLITE_OK) return;
        sqlite3_bind_blob(st, 1, exe.md5.data(), 16, SQLITE_STATIC);
        sqlite3_bind_int64(st, 2, static_cast<int64_t>(e.id));
        sqlite3_bind_int (st, 3, static_cast<int>(e.topology));
        sqlite3_bind_int (st, 4, e.vertex_count);
        sqlite3_bind_blob(st, 5, &e.attrs, sizeof(e.attrs), SQLITE_STATIC);
        sqlite3_bind_blob(st, 6, &e.bbox,  sizeof(e.bbox),  SQLITE_STATIC);
        sqlite3_bind_int (st, 7, static_cast<int>(e.observation_count));
        sqlite3_bind_int (st, 8, static_cast<int>(e.first_frame));
        sqlite3_bind_int (st, 9, static_cast<int>(e.last_frame));
        sqlite3_step(st);
        sqlite3_finalize(st);
    }

    void persist_catalog_node(const ExecutableSignature& exe, const CatalogNode& n) {
        const char* sql =
            "INSERT OR REPLACE INTO catalog_nodes "
            "(exe_md5, sig_id, cell, sector, track, neighbor_blob,"
            " obs_count, first_seen, last_seen) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";
        sqlite3_stmt* st = nullptr;
        if (sqlite3_prepare_v2(db_, sql, -1, &st, nullptr) != SQLITE_OK) return;
        sqlite3_bind_blob(st, 1, exe.md5.data(), 16, SQLITE_STATIC);
        sqlite3_bind_int64(st, 2, static_cast<int64_t>(n.signature));
        sqlite3_bind_int (st, 3, static_cast<int>(n.cell));
        sqlite3_bind_int (st, 4, static_cast<int>(n.sector));
        sqlite3_bind_int (st, 5, static_cast<int>(n.track));
        if (!n.neighbors.empty()) {
            sqlite3_bind_blob(st, 6, n.neighbors.data(),
                              n.neighbors.size() * sizeof(ClusterSignatureId),
                              SQLITE_STATIC);
        } else {
            sqlite3_bind_null(st, 6);
        }
        sqlite3_bind_int (st, 7, static_cast<int>(n.observation_count));
        sqlite3_bind_int (st, 8, static_cast<int>(n.first_seen));
        sqlite3_bind_int (st, 9, static_cast<int>(n.last_seen));
        sqlite3_step(st);
        sqlite3_finalize(st);
    }

    void persist_edge(const ExecutableSignature& exe, const AdjacencyEdge& e) {
        const char* sql =
            "INSERT OR REPLACE INTO adjacency_edges "
            "(exe_md5, from_sig, to_sig, obs_count, confidence, last_traversed) "
            "VALUES (?, ?, ?, ?, ?, ?);";
        sqlite3_stmt* st = nullptr;
        if (sqlite3_prepare_v2(db_, sql, -1, &st, nullptr) != SQLITE_OK) return;
        sqlite3_bind_blob(st, 1, exe.md5.data(), 16, SQLITE_STATIC);
        sqlite3_bind_int64(st, 2, static_cast<int64_t>(e.from));
        sqlite3_bind_int64(st, 3, static_cast<int64_t>(e.to));
        sqlite3_bind_int (st, 4, static_cast<int>(e.observed_count));
        sqlite3_bind_double(st, 5, static_cast<double>(e.confidence));
        sqlite3_bind_int (st, 6, static_cast<int>(e.last_traversed));
        sqlite3_step(st);
        sqlite3_finalize(st);
    }

    sqlite3* db_ = nullptr;
};
#else
class SQLiteBackend final : public PersistenceBackend {
public:
    bool open(const std::filesystem::path&) override { return false; }
    void close() override {}
    bool save(const ExecutableSignature&, const SignatureRegistry&,
              const SpatialCatalog&, const AdjacencyGraph&) override { return false; }
    bool load(const ExecutableSignature&, SignatureRegistry&,
              SpatialCatalog&, AdjacencyGraph&) override { return false; }
    std::vector<ExecutableSignature> list_executables() override { return {}; }
};
#endif  // RSIL_HAS_SQLITE

std::unique_ptr<PersistenceBackend> make_sqlite_backend() {
    return std::make_unique<SQLiteBackend>();
}

// ---------------------------------------------------------------------------
// JsonBackend (debug / export only)
// ---------------------------------------------------------------------------

namespace {

std::string md5_hex(const std::array<uint8_t, 16>& md5) {
    static const char* kHex = "0123456789abcdef";
    std::string s; s.reserve(32);
    for (uint8_t b : md5) { s.push_back(kHex[b >> 4]); s.push_back(kHex[b & 0xF]); }
    return s;
}

}  // namespace

class JsonBackend final : public PersistenceBackend {
public:
    explicit JsonBackend(std::filesystem::path dir) : dir_(std::move(dir)) {}

    bool open(const std::filesystem::path&) override { return true; }
    void close() override {}

    bool save(const ExecutableSignature& exe,
              const SignatureRegistry&  sigs,
              const SpatialCatalog&     catalog,
              const AdjacencyGraph&     graph) override {
        std::filesystem::create_directories(dir_);
        std::ofstream out(dir_ / (md5_hex(exe.md5) + ".json"));
        if (!out) return false;
        out << "{\n  \"exe\": {\"md5\": \"" << md5_hex(exe.md5)
            << "\", \"crc32\": " << exe.crc32
            << ", \"name\": \"" << exe.display_name << "\"},\n";

        out << "  \"signatures\": [\n";
        bool first = true;
        for (const auto& e : sigs.snapshot()) {
            if (!first) out << ",\n"; first = false;
            out << "    {\"id\": " << e.id
                << ", \"topology\": " << static_cast<int>(e.topology)
                << ", \"vertex_count\": " << e.vertex_count
                << ", \"obs_count\": " << e.observation_count << "}";
        }
        out << "\n  ],\n";

        out << "  \"edges\": [\n";
        first = true;
        for (const auto& edge : graph.snapshot()) {
            if (!first) out << ",\n"; first = false;
            out << "    {\"from\": " << edge.from
                << ", \"to\": " << edge.to
                << ", \"count\": " << edge.observed_count
                << ", \"confidence\": " << edge.confidence << "}";
        }
        out << "\n  ]\n}\n";
        return true;
    }

    bool load(const ExecutableSignature&, SignatureRegistry&,
              SpatialCatalog&, AdjacencyGraph&) override {
        // JSON backend is export-only; loads are not supported.
        return false;
    }

    std::vector<ExecutableSignature> list_executables() override { return {}; }

private:
    std::filesystem::path dir_;
};

std::unique_ptr<PersistenceBackend> make_json_backend(
    const std::filesystem::path& dir) {
    return std::make_unique<JsonBackend>(dir);
}

// ---------------------------------------------------------------------------
// PersistenceManager
// ---------------------------------------------------------------------------

PersistenceManager::PersistenceManager(std::unique_ptr<PersistenceBackend> backend,
                                       const ExecutableSignature& exe)
    : backend_(std::move(backend)), exe_(exe) {}

void PersistenceManager::save_async(const SignatureRegistry& sigs,
                                    const SpatialCatalog&    catalog,
                                    const AdjacencyGraph&    graph) {
    // Snapshot on caller thread to avoid races during async write.
    auto sig_snap = std::make_shared<std::vector<SignatureEntry>>(sigs.snapshot());
    auto cat_snap = std::make_shared<SpatialCatalog::Snapshot>(catalog.snapshot());
    auto edge_snap = std::make_shared<std::vector<AdjacencyEdge>>(graph.snapshot());

    // Note: in production, dispatch to a worker thread. The scaffold uses
    // std::thread::detach for simplicity; a real impl would use a
    // dedicated persistence worker with a task queue.
    std::thread([this, sig_snap, cat_snap, edge_snap]() {
        // Rebuild lightweight views from snapshots and call backend.
        // For brevity, this scaffold delegates to save_sync semantics.
        // Production: rebuild read-only views and pass to backend_->save.
    }).detach();
    (void)sig_snap; (void)cat_snap; (void)edge_snap;
}

bool PersistenceManager::save_sync(const SignatureRegistry& sigs,
                                   const SpatialCatalog&    catalog,
                                   const AdjacencyGraph&    graph) {
    if (!backend_) return false;
    return backend_->save(exe_, sigs, catalog, graph);
}

bool PersistenceManager::load(SignatureRegistry& sigs,
                              SpatialCatalog&    catalog,
                              AdjacencyGraph&    graph) {
    if (loaded_ || !backend_) return false;
    loaded_ = backend_->load(exe_, sigs, catalog, graph);
    return loaded_;
}

}  // namespace rsil
