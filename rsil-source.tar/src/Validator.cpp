// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Validator implementation.

#include "rsil/Validator.h"

#include <algorithm>
#include <cstring>

namespace rsil {

void Validator::sample(FrameId frame) {
    if (!cfg_.flags.validator) return;
    if (cfg_.validator_sample_rate == 0) return;
    if (frame % cfg_.validator_sample_rate != 0) return;

    FrameHash h;
    h.frame    = frame;
    h.cpu_regs = provider_.hash_cpu_registers();
    h.ram      = provider_.hash_ram();
    h.vram     = provider_.hash_vram();
    h.gpu_cmds = provider_.hash_gpu_command_stream();

    chain_.push_back(std::move(h));
    stats_.samples_taken++;

    // Cap chain length to bound memory.
    if (chain_.size() > 4096) chain_.pop_front();
}

DivergenceReport Validator::compare(const std::deque<FrameHash>& baseline) const {
    DivergenceReport report;
    const size_t n = std::min(chain_.size(), baseline.size());
    for (size_t i = 0; i < n; ++i) {
        const auto& a = baseline[i];
        const auto& b = chain_[i];
        if (a.cpu_regs != b.cpu_regs) {
            report.divergent = true;
            report.first_divergent_frame = a.frame;
            report.channel = DivergenceReport::Channel::CpuRegs;
            report.baseline_hash = a.cpu_regs;
            report.rsil_hash     = b.cpu_regs;
            return report;
        }
        if (a.ram != b.ram) {
            report.divergent = true;
            report.first_divergent_frame = a.frame;
            report.channel = DivergenceReport::Channel::Ram;
            report.baseline_hash = a.ram;
            report.rsil_hash     = b.ram;
            return report;
        }
        if (a.vram != b.vram) {
            report.divergent = true;
            report.first_divergent_frame = a.frame;
            report.channel = DivergenceReport::Channel::Vram;
            report.baseline_hash = a.vram;
            report.rsil_hash     = b.vram;
            return report;
        }
        if (a.gpu_cmds != b.gpu_cmds) {
            report.divergent = true;
            report.first_divergent_frame = a.frame;
            report.channel = DivergenceReport::Channel::GpuCmds;
            report.baseline_hash = a.gpu_cmds;
            report.rsil_hash     = b.gpu_cmds;
            return report;
        }
    }
    return report;
}

}  // namespace rsil
