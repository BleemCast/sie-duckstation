// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Adjacency graph & Markov model implementation.

#include "rsil/AdjacencyGraph.h"

#include <algorithm>
#include <cmath>

namespace rsil {

void AdjacencyGraph::observe_transition(ClusterSignatureId from,
                                        ClusterSignatureId actual_next,
                                        FrameId frame) {
    if (from == kInvalidSignature || actual_next == kInvalidSignature) return;

    auto& edge_map = nodes_[from];
    auto& edge = edge_map.out_edges[actual_next];

    if (edge.from == kInvalidSignature) {
        edge.from = from;
        edge.to   = actual_next;
        edge.confidence = 0.0f;
    }
    edge.observed_count++;
    edge.last_traversed = frame;

    // Update ALL candidate successors of `from` with decaying WMA.
    // The matching successor gets +indicator boost; others decay.
    for (auto& [_, e] : edge_map.out_edges) {
        const float indicator = (e.to == actual_next) ? 1.0f : 0.0f;
        e.confidence = decay_ * e.confidence + (1.0f - decay_) * indicator;
    }
}

std::vector<AdjacencyEdge> AdjacencyGraph::top_successors(ClusterSignatureId from,
                                                           size_t top_n) const {
    std::vector<AdjacencyEdge> out;
    auto it = nodes_.find(from);
    if (it == nodes_.end()) return out;

    out.reserve(it->second.out_edges.size());
    for (const auto& [_, e] : it->second.out_edges) {
        if (e.observed_count >= min_observations_) {
            out.push_back(e);
        }
    }
    std::sort(out.begin(), out.end(),
              [](const AdjacencyEdge& a, const AdjacencyEdge& b) {
                  if (a.confidence != b.confidence) return a.confidence > b.confidence;
                  return a.observed_count > b.observed_count;
              });
    if (out.size() > top_n) out.resize(top_n);
    return out;
}

std::optional<AdjacencyEdge> AdjacencyGraph::best_successor(ClusterSignatureId from) const {
    auto top = top_successors(from, 1);
    if (top.empty()) return std::nullopt;
    return top.front();
}

std::vector<AdjacencyEdge> AdjacencyGraph::snapshot() const {
    std::vector<AdjacencyEdge> out;
    for (const auto& [_, em] : nodes_) {
        for (const auto& [_, e] : em.out_edges) out.push_back(e);
    }
    return out;
}

void AdjacencyGraph::restore(const std::vector<AdjacencyEdge>& edges) {
    nodes_.clear();
    for (const auto& e : edges) {
        nodes_[e.from].out_edges[e.to] = e;
    }
}

size_t AdjacencyGraph::edge_count() const {
    size_t n = 0;
    for (const auto& [_, em] : nodes_) n += em.out_edges.size();
    return n;
}

void AdjacencyGraph::clear() { nodes_.clear(); }

}  // namespace rsil
