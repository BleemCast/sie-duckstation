// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Primitive clusterer & signature builder implementation.

#include "rsil/ClusterSignature.h"

#include <algorithm>
#include <cstring>
#include <new>

namespace rsil {

// ---------------------------------------------------------------------------
// PrimitiveClusterer
// ---------------------------------------------------------------------------

void PrimitiveClusterer::begin_frame(FrameId frame) {
    if (in_cluster_) flush();
    current_frame_ = frame;
}

const ClusterEvent* PrimitiveClusterer::push_primitive(const PrimitiveObservation& obs) {
    const bool same_attrs = in_cluster_ && pending_.attrs == obs.attrs &&
                            pending_.topology == obs.topology;
    if (!in_cluster_ || !same_attrs) {
        if (in_cluster_) close_current();
        in_cluster_ = true;
        pending_ = ClusterEvent{};
        pending_.frame = current_frame_;
        pending_.attrs = obs.attrs;
        pending_.topology = obs.topology;
        bbox_min_ = { obs.bbox.min_delta[0], obs.bbox.min_delta[1], obs.bbox.min_delta[2] };
        bbox_max_ = { obs.bbox.max_delta[0], obs.bbox.max_delta[1], obs.bbox.max_delta[2] };
        vertex_count_accum_ = obs.vertex_count;
        primitive_count_accum_ = 1;
    } else {
        for (int i = 0; i < 3; ++i) {
            bbox_min_[i] = std::min(bbox_min_[i], (int32_t)obs.bbox.min_delta[i]);
            bbox_max_[i] = std::max(bbox_max_[i], (int32_t)obs.bbox.max_delta[i]);
        }
        vertex_count_accum_ += obs.vertex_count;
        primitive_count_accum_++;
    }
    return nullptr;  // cluster is still open
}

const ClusterEvent* PrimitiveClusterer::flush() {
    if (!in_cluster_) return nullptr;
    close_current();
    return last_event_.get();
}

void PrimitiveClusterer::close_current() {
    if (!in_cluster_) return;

    pending_.primitive_count   = primitive_count_accum_;
    pending_.total_vertex_count = vertex_count_accum_;
    for (int i = 0; i < 3; ++i) {
        pending_.aggregate_bbox.min_delta[i] =
            (int16_t)std::clamp<int32_t>(bbox_min_[i], INT16_MIN, INT16_MAX);
        pending_.aggregate_bbox.max_delta[i] =
            (int16_t)std::clamp<int32_t>(bbox_max_[i], INT16_MIN, INT16_MAX);
    }
    pending_.signature_id = compute_signature(pending_);

    last_event_ = std::make_shared<ClusterEvent>(pending_);
    in_cluster_ = false;
}

// ---------------------------------------------------------------------------
// ClusterSignatureBuilder
// ---------------------------------------------------------------------------

void ClusterSignatureBuilder::add_bytes(const void* data, size_t n) {
    const uint8_t* p = static_cast<const uint8_t*>(data);
    for (size_t i = 0; i < n; ++i) {
        hash_ ^= p[i];
        hash_ *= 0x100000001b3ULL;  // FNV-1a 64-bit prime
    }
}

void ClusterSignatureBuilder::add_topology(PrimitiveTopology t) {
    uint8_t v = static_cast<uint8_t>(t);
    add_bytes(&v, sizeof(v));
}

void ClusterSignatureBuilder::add_vertex_count(uint16_t n) {
    add_bytes(&n, sizeof(n));
}

void ClusterSignatureBuilder::add_attributes(const PrimitiveAttributes& a) {
    add_bytes(&a, sizeof(a));
}

void ClusterSignatureBuilder::add_bbox(const NormalizedBBox& b) {
    add_bytes(&b, sizeof(b));
}

ClusterSignatureId ClusterSignatureBuilder::finalize() {
    ClusterSignatureId result = hash_;
    if (result == kInvalidSignature) result = 1;  // avoid sentinel collision
    hash_ = 0xcbf29ce484222325ULL;
    return result;
}

ClusterSignatureId compute_signature(const ClusterEvent& ev) {
    ClusterSignatureBuilder b;
    b.add_topology(ev.topology);
    b.add_vertex_count(static_cast<uint16_t>(ev.total_vertex_count));
    b.add_attributes(ev.attrs);
    b.add_bbox(ev.aggregate_bbox);
    return b.finalize();
}

// ---------------------------------------------------------------------------
// SignatureRegistry
// ---------------------------------------------------------------------------

ClusterSignatureId SignatureRegistry::register_event(const ClusterEvent& ev) {
    ClusterSignatureId id = ev.signature_id;
    if (id == kInvalidSignature) {
        id = compute_signature(ev);
    }
    auto it = entries_.find(id);
    if (it == entries_.end()) {
        SignatureEntry e;
        e.id = id;
        e.topology = ev.topology;
        e.vertex_count = static_cast<uint16_t>(ev.total_vertex_count);
        e.attrs = ev.attrs;
        e.bbox = ev.aggregate_bbox;
        e.observation_count = 1;
        e.first_frame = ev.frame;
        e.last_frame  = ev.frame;
        entries_.emplace(id, std::move(e));
    } else {
        it->second.observation_count++;
        it->second.last_frame = ev.frame;
    }
    return id;
}

const SignatureEntry* SignatureRegistry::lookup(ClusterSignatureId id) const {
    auto it = entries_.find(id);
    return it == entries_.end() ? nullptr : &it->second;
}

std::vector<SignatureEntry> SignatureRegistry::snapshot() const {
    std::vector<SignatureEntry> out;
    out.reserve(entries_.size());
    for (const auto& [_, e] : entries_) out.push_back(e);
    return out;
}

void SignatureRegistry::clear() { entries_.clear(); }

void SignatureRegistry::restore(const std::vector<SignatureEntry>& entries) {
    entries_.clear();
    entries_.reserve(entries.size());
    for (const auto& e : entries) {
        if (e.id == kInvalidSignature) continue;
        entries_.emplace(e.id, e);
    }
}

}  // namespace rsil
