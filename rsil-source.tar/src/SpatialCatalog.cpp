// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Spatial catalog implementation.

#include "rsil/SpatialCatalog.h"

#include <algorithm>
#include <stdexcept>

namespace rsil {

CatalogNode& SpatialCatalog::register_cluster(ClusterSignatureId sig,
                                              ClusterSignatureId previous_signature,
                                              FrameId frame) {
    auto it = nodes_.find(sig);
    if (it == nodes_.end()) {
        CatalogNode n;
        n.signature = sig;
        n.first_seen = frame;
        n.last_seen = frame;
        n.observation_count = 1;
        // Inherit cell/sector from the previous signature if known. This
        // is the spatial-continuity heuristic: clusters emitted back-to-back
        // by the engine are likely spatially adjacent.
        if (previous_signature != kInvalidSignature) {
            if (auto* prev = find_mut(previous_signature); prev != nullptr) {
                n.cell = prev->cell;
                n.sector = prev->sector;
                n.track = prev->track;
                // Compute relative delta from previous neighbor (normalized
                // bbox center difference). We use the previous cluster's
                // bbox max as a proxy since we don't have absolute coords.
                for (int i = 0; i < 3; ++i) {
                    n.relative_delta[i] = prev->relative_delta[i];  // placeholder
                }
                // Register bidirectional neighbor link.
                prev->neighbors.push_back(sig);
                n.neighbors.push_back(previous_signature);
            }
        }
        it = nodes_.emplace(sig, std::move(n)).first;
    } else {
        it->second.observation_count++;
        it->second.last_seen = frame;
    }
    return it->second;
}

void SpatialCatalog::assign_cell(ClusterSignatureId sig, CellId cell) {
    if (auto* n = find_mut(sig)) {
        n->cell = cell;
    }
}

void SpatialCatalog::assign_sector(CellId cell, SectorId sector) {
    for (auto& [_, n] : nodes_) {
        if (n.cell == cell) n.sector = sector;
    }
}

void SpatialCatalog::assign_track(SectorId sector, TrackId track) {
    for (auto& [_, n] : nodes_) {
        if (n.sector == sector) n.track = track;
    }
}

const CatalogNode* SpatialCatalog::find(ClusterSignatureId sig) const {
    auto it = nodes_.find(sig);
    return it == nodes_.end() ? nullptr : &it->second;
}

CatalogNode* SpatialCatalog::find_mut(ClusterSignatureId sig) {
    auto it = nodes_.find(sig);
    return it == nodes_.end() ? nullptr : &it->second;
}

std::vector<ClusterSignatureId> SpatialCatalog::clusters_in_cell(CellId c) const {
    std::vector<ClusterSignatureId> out;
    for (const auto& [id, n] : nodes_) {
        if (n.cell == c) out.push_back(id);
    }
    return out;
}

std::vector<ClusterSignatureId> SpatialCatalog::clusters_in_sector(SectorId s) const {
    std::vector<ClusterSignatureId> out;
    for (const auto& [id, n] : nodes_) {
        if (n.sector == s) out.push_back(id);
    }
    return out;
}

std::vector<ClusterSignatureId> SpatialCatalog::neighbors_of(ClusterSignatureId sig) const {
    if (auto* n = find(sig)) return n->neighbors;
    return {};
}

std::vector<ClusterSignatureId> SpatialCatalog::sorted_feed() const {
    std::vector<ClusterSignatureId> out;
    out.reserve(nodes_.size());
    // Sort by (track, sector, cell, first_seen). This produces a cache-
    // coherent iteration order for the host frustum culler.
    std::vector<const CatalogNode*> ptrs;
    ptrs.reserve(nodes_.size());
    for (const auto& [_, n] : nodes_) ptrs.push_back(&n);
    std::sort(ptrs.begin(), ptrs.end(), [](const CatalogNode* a, const CatalogNode* b) {
        if (a->track  != b->track)  return a->track  < b->track;
        if (a->sector != b->sector) return a->sector < b->sector;
        if (a->cell   != b->cell)   return a->cell   < b->cell;
        return a->first_seen < b->first_seen;
    });
    for (const auto* p : ptrs) out.push_back(p->signature);
    return out;
}

SpatialCatalog::Snapshot SpatialCatalog::snapshot() const {
    Snapshot s;
    for (const auto& [_, n] : nodes_) s.nodes.push_back(n);
    s.next_cell_id = next_cell_id_;
    s.next_sector_id = next_sector_id_;
    s.next_track_id = next_track_id_;
    return s;
}

void SpatialCatalog::restore(const Snapshot& s) {
    nodes_.clear();
    for (const auto& n : s.nodes) nodes_.emplace(n.signature, n);
    next_cell_id_ = s.next_cell_id;
    next_sector_id_ = s.next_sector_id;
    next_track_id_ = s.next_track_id;
}

void SpatialCatalog::clear() {
    nodes_.clear();
    next_cell_id_ = 1;
    next_sector_id_ = 1;
    next_track_id_ = 1;
}

}  // namespace rsil
