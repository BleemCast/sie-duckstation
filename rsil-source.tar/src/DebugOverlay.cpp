// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Debug overlay implementation.
//
// This file is guarded by RSIL_HAS_IMGUI. When ImGui is not available,
// all methods compile to no-ops, allowing the scaffold to build in
// headless environments.

#include "rsil/DebugOverlay.h"

#ifdef RSIL_HAS_IMGUI
#include <imgui.h>
#endif

namespace rsil {

void DebugOverlay::draw() {
    if (!cfg_.flags.overlay) return;

#ifdef RSIL_HAS_IMGUI
    if (ImGui::Begin("RSIL Overlay", &cfg_.flags.overlay)) {
        if (ImGui::BeginTabBar("RSILTabs")) {
            if (show_graph_panel     && ImGui::BeginTabItem("Graph"))     { draw_graph_panel();     ImGui::EndTabItem(); }
            if (show_catalog_panel   && ImGui::BeginTabItem("Catalog"))   { draw_catalog_panel();   ImGui::EndTabItem(); }
            if (show_predictor_panel && ImGui::BeginTabItem("Predictor")) { draw_predictor_panel(); ImGui::EndTabItem(); }
            if (show_prereg_panel    && ImGui::BeginTabItem("PreReg"))    { draw_prereg_panel();    ImGui::EndTabItem(); }
            if (show_validator_panel && ImGui::BeginTabItem("Validator")) { draw_validator_panel(); ImGui::EndTabItem(); }
            if (show_telemetry_panel && ImGui::BeginTabItem("Telemetry")) { draw_telemetry_panel(); ImGui::EndTabItem(); }
            ImGui::EndTabBar();
        }
    }
    ImGui::End();
#else
    // No ImGui available; overlay is a no-op.
#endif
}

#ifdef RSIL_HAS_IMGUI
void DebugOverlay::draw_graph_panel() {
    ImGui::Text("Nodes: %zu  Edges: %zu", graph_.node_count(), graph_.edge_count());
    ImGui::Separator();
    // Iterate the top-N most-confident edges.
    // (Production: cache snapshot at overlay_refresh_hz.)
    ImGui::TextDisabled("Top transitions (refresh at %u Hz)", cfg_.overlay_refresh_hz);
}

void DebugOverlay::draw_catalog_panel() {
    auto feed = catalog_.sorted_feed();
    ImGui::Text("Catalog entries: %zu", feed.size());
    if (ImGui::BeginChild("CatalogList", ImVec2(0, 200), true)) {
        for (size_t i = 0; i < feed.size() && i < 200; ++i) {
            ImGui::Text("sig=%016llx", static_cast<unsigned long long>(feed[i]));
        }
    }
    ImGui::EndChild();
}

void DebugOverlay::draw_predictor_panel() {
    const auto& s = predictor_.stats();
    ImGui::Text("Predictions: %llu", static_cast<unsigned long long>(s.total_predictions));
    ImGui::Text("Hits: %llu   Misses: %llu",
                static_cast<unsigned long long>(s.hits),
                static_cast<unsigned long long>(s.misses));
    if (s.total_predictions > 0) {
        float rate = static_cast<float>(s.hits) / static_cast<float>(s.total_predictions);
        ImGui::ProgressBar(rate, ImVec2(0, 0), "hit rate");
    }
}

void DebugOverlay::draw_prereg_panel() {
    const auto& s = prereg_.stats();
    ImGui::Text("Active slots: %u / %u", s.active_slots, cfg_.max_active_preregs);
    ImGui::Text("Issued: %llu   Evicted: %llu",
                static_cast<unsigned long long>(s.total_issued),
                static_cast<unsigned long long>(s.total_evicted));
    ImGui::Text("Priority elevations: %llu",
                static_cast<unsigned long long>(s.priority_elevations));
}

void DebugOverlay::draw_validator_panel() {
    if (!validator_) { ImGui::TextDisabled("Validator disabled"); return; }
    const auto& s = validator_->stats();
    ImGui::Text("Samples: %llu", static_cast<unsigned long long>(s.samples_taken));
    ImGui::Text("Divergences: %llu",
                static_cast<unsigned long long>(s.divergences_detected));
}

void DebugOverlay::draw_telemetry_panel() {
    ImGui::Text("Signatures observed: %zu", sigs_.snapshot().size());
}
#else
void DebugOverlay::draw_graph_panel()     {}
void DebugOverlay::draw_catalog_panel()   {}
void DebugOverlay::draw_predictor_panel() {}
void DebugOverlay::draw_prereg_panel()    {}
void DebugOverlay::draw_validator_panel() {}
void DebugOverlay::draw_telemetry_panel() {}
#endif

}  // namespace rsil
