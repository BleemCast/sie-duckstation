// SPDX-License-Identifier: BSD-3-Clause
// RSIL — GpuPacketParser test.
//
// Verifies the parser correctly decodes realistic PS1 GP0 packet streams:
//   1. Texpage state tracking (0xE1 command)
//   2. Monochrome triangle (0x20) — 5 words, vertices extracted
//   3. Textured triangle (0x24) — 8 words, texpage+CLUT extracted
//   4. Textured quad (0x2C) — 10 words, 4 vertices
//   5. Gouraud triangle (0x30) — 7 words, per-vertex colors skipped
//   6. Rectangle (0x64) — textured sprite, expanded to 4 corners
//   7. Bbox normalization produces non-zero deltas

#include "rsil/GpuPacketParser.h"
#include "rsil/ClusterSignature.h"

#include <cassert>
#include <cstdio>

using namespace rsil;

// Helper: feed a vector of words to the parser.
static void feed(GpuPacketParser& p, const std::vector<uint32_t>& words, FrameId frame = 1) {
    for (uint32_t w : words) p.on_word(w, frame);
}

// Pack X,Y into a vertex word.
static uint32_t vtx(int16_t x, int16_t y) {
    return (static_cast<uint32_t>(static_cast<uint16_t>(y)) << 16) |
           static_cast<uint32_t>(static_cast<uint16_t>(x));
}

// Pack U,V + 16-bit upper field (CLUT or texpage) into a texcoord word.
static uint32_t tex(uint8_t u, uint8_t v, uint16_t upper) {
    return (static_cast<uint32_t>(upper) << 16) |
           (static_cast<uint32_t>(v) << 8) | u;
}

int main() {
    // 1. Texpage state tracking via 0xE1.
    {
        GpuPacketParser p;
        PrimitiveObservation last;
        p.on_primitive = [&](const PrimitiveObservation& o) { last = o; };

        // Set default texpage to 0x01FF.
        // GP0(0xE1) word: high byte = 0xE1, low 11 bits = texpage register.
        p.on_word(0xE1000000u | 0x01FFu, 1);
        assert(p.current_texpage() == 0x01FF);
        std::printf("OK: texpage state tracked via 0xE1 = 0x%04X\n", p.current_texpage());
    }

    // 2. Monochrome triangle (0x20): cmd, color, v1, v2, v3.
    {
        GpuPacketParser p;
        PrimitiveObservation last;
        bool got = false;
        p.on_primitive = [&](const PrimitiveObservation& o) { last = o; got = true; };

        feed(p, {
            0x20000000u,           // command: monochrome triangle
            0x00FFFFFFu,           // color: white
            vtx(100, 200),         // v1
            vtx(300, 200),         // v2
            vtx(200, 100),         // v3
        });

        assert(got);
        assert(last.topology == PrimitiveTopology::Polygon);
        assert(last.vertex_count == 3);
        assert(!last.attrs.textured);
        assert(!last.attrs.gouraud);
        // Bbox should have non-zero deltas (vertices span 100..300 in X, 100..200 in Y).
        assert(last.bbox.min_delta[0] != 0 || last.bbox.max_delta[0] != 0);
        assert(last.bbox.min_delta[1] != 0 || last.bbox.max_delta[1] != 0);
        std::printf("OK: mono triangle parsed (vc=%u, bbox X:[%d..%d] Y:[%d..%d])\n",
            last.vertex_count,
            last.bbox.min_delta[0], last.bbox.max_delta[0],
            last.bbox.min_delta[1], last.bbox.max_delta[1]);
    }

    // 3. Textured triangle (0x24): cmd, color, v1, tc1+CLUT, v2, tc2+texpage, v3, tc3.
    {
        GpuPacketParser p;
        PrimitiveObservation last;
        bool got = false;
        p.on_primitive = [&](const PrimitiveObservation& o) { last = o; got = true; };

        feed(p, {
            0x24000000u,           // command: textured triangle
            0x00808080u,           // color
            vtx(50, 60),           // v1
            tex(10, 20, 0x1234),   // tc1 + CLUT = 0x1234
            vtx(150, 60),          // v2
            tex(30, 20, 0x5678),   // tc2 + texpage = 0x5678
            vtx(100, 160),         // v3
            tex(20, 40, 0x0000),   // tc3 (padding)
        });

        assert(got);
        assert(last.attrs.textured);
        assert(last.vertex_count == 3);
        assert(last.attrs.clut == 0x1234);
        assert(last.attrs.texpage == 0x5678);
        std::printf("OK: textured triangle parsed (texpage=0x%04X clut=0x%04X)\n",
            last.attrs.texpage, last.attrs.clut);
    }

    // 4. Textured quad (0x2C): 10 words.
    {
        GpuPacketParser p;
        PrimitiveObservation last;
        bool got = false;
        p.on_primitive = [&](const PrimitiveObservation& o) { last = o; got = true; };

        feed(p, {
            0x2C000000u,           // command: textured quad
            0x00FFFFFFu,           // color
            vtx(0, 0),     tex(0, 0, 0x1111),
            vtx(100, 0),   tex(100, 0, 0x2222),
            vtx(100, 100), tex(100, 100, 0x0000),
            vtx(0, 100),   tex(0, 100, 0x0000),
        });

        assert(got);
        assert(last.vertex_count == 4);
        assert(last.attrs.clut == 0x1111);
        assert(last.attrs.texpage == 0x2222);
        std::printf("OK: textured quad parsed (vc=%u)\n", last.vertex_count);
    }

    // 5. Gouraud triangle (0x30): cmd, c1, v1, c2, v2, c3, v3.
    {
        GpuPacketParser p;
        PrimitiveObservation last;
        bool got = false;
        p.on_primitive = [&](const PrimitiveObservation& o) { last = o; got = true; };

        feed(p, {
            0x30000000u,           // command: gouraud triangle
            0x00FF0000u,           // c1 (red)
            vtx(10, 10),
            0x0000FF00u,           // c2 (green)
            vtx(100, 10),
            0x000000FFu,           // c3 (blue)
            vtx(50, 100),
        });

        assert(got);
        assert(last.attrs.gouraud);
        assert(last.attrs.lit);
        assert(!last.attrs.textured);
        assert(last.vertex_count == 3);
        std::printf("OK: gouraud triangle parsed\n");
    }

    // 6. Rectangle (0x64): textured, variable size.
    {
        GpuPacketParser p;
        PrimitiveObservation last;
        bool got = false;
        p.on_primitive = [&](const PrimitiveObservation& o) { last = o; got = true; };

        // 0x64 = textured rectangle, variable size.
        // bit 2 (0x04) = textured, bits 4-3 = 00 = variable size.
        feed(p, {
            0x64000000u,           // command: textured rectangle, variable size
            0x00FFFFFFu,           // color
            vtx(200, 300),         // position
            tex(0, 0, 0xABCD),     // texcoord + CLUT
            (32u) | (32u << 16),   // size: 32x32
        });

        assert(got);
        assert(last.topology == PrimitiveTopology::Sprite);
        assert(last.attrs.textured);
        assert(last.attrs.clut == 0xABCD);
        // Rectangle should be expanded to 4 corners.
        assert(last.vertex_count == 4);
        std::printf("OK: textured rectangle parsed (expanded to %u corners)\n",
            last.vertex_count);
    }

    // 7. Two textured triangles with DIFFERENT texpages produce DIFFERENT
    //    cluster signatures. This is the critical test — it proves the
    //    signature pipeline now differentiates clusters by texture state.
    {
        GpuPacketParser p1, p2;
        ClusterEvent ev1, ev2;
        p1.on_primitive = [&](const PrimitiveObservation& o) {
            // Simulate clusterer behavior: register the primitive.
        };

        // Build two clusters with different texpages.
        PrimitiveClusterer c1, c2;
        c1.begin_frame(1);
        c2.begin_frame(1);

        GpuPacketParser parser1, parser2;
        parser1.on_primitive = [&](const PrimitiveObservation& o) { c1.push_primitive(o); };
        parser2.on_primitive = [&](const PrimitiveObservation& o) { c2.push_primitive(o); };

        // Cluster 1: texpage 0x1111
        feed(parser1, {
            0x24000000u, 0x00FFFFFFu, vtx(10,10), tex(0,0,0xAAAA),
            vtx(100,10), tex(50,0,0x1111), vtx(50,100), tex(25,50,0),
        });

        // Cluster 2: texpage 0x2222 (different!)
        feed(parser2, {
            0x24000000u, 0x00FFFFFFu, vtx(10,10), tex(0,0,0xAAAA),
            vtx(100,10), tex(50,0,0x2222), vtx(50,100), tex(25,50,0),
        });

        const ClusterEvent* e1 = c1.flush();
        const ClusterEvent* e2 = c2.flush();
        assert(e1 && e2);
        assert(e1->signature_id != e2->signature_id);
        std::printf("OK: different texpages -> different signatures (%016llx != %016llx)\n",
            (unsigned long long)e1->signature_id,
            (unsigned long long)e2->signature_id);
    }

    // 8. Stats.
    {
        GpuPacketParser p;
        p.on_primitive = [](const PrimitiveObservation&) {};
        feed(p, { 0x20000000u, 0xFFFFFFFFu, vtx(0,0), vtx(10,0), vtx(5,10) });
        feed(p, { 0x20000000u, 0xFFFFFFFFu, vtx(0,0), vtx(20,0), vtx(10,20) });
        const auto& s = p.stats();
        assert(s.packets_parsed >= 2);
        assert(s.primitives_emitted == 2);
        assert(s.words_consumed == 10);
        std::printf("OK: stats (packets=%u primitives=%u words=%u)\n",
            s.packets_parsed, s.primitives_emitted, s.words_consumed);
    }

    std::printf("\nAll GpuPacketParser tests passed.\n");
    return 0;
}
