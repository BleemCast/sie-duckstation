// SPDX-License-Identifier: BSD-3-Clause
// RSIL — Smoke test for the cluster-signature + adjacency-graph path.
//
// Exercises the core metadata pipeline without requiring a host GPU:
//   1. Synthesize a stream of PrimitiveObservations.
//   2. Verify clusters collapse to identical signatures for identical
//      metadata, and distinct signatures for distinct metadata.
//   3. Verify the adjacency graph records transitions and produces
//      a best-successor with confidence > 0 after repeated observation.

#include "rsil/ClusterSignature.h"
#include "rsil/SpatialCatalog.h"
#include "rsil/AdjacencyGraph.h"
#include "rsil/Predictor.h"
#include "rsil/Config.h"

#include <cassert>
#include <cstdio>

using namespace rsil;

static PrimitiveObservation make_obs(uint8_t cmd, uint16_t vc,
                                     TexpageId tp, ClutId cl,
                                     bool textured, bool gouraud) {
    PrimitiveObservation o;
    o.topology = PrimitiveTopology::Polygon;
    o.vertex_count = vc;
    o.attrs.raw_cmd  = cmd;
    o.attrs.texpage  = tp;
    o.attrs.clut     = cl;
    o.attrs.textured = textured;
    o.attrs.gouraud  = gouraud;
    o.bbox.min_delta = { 0, 0, 0 };
    o.bbox.max_delta = { 100, 100, 100 };
    return o;
}

int main() {
    // 1. Two identical metadata streams must produce identical signatures.
    PrimitiveClusterer c1, c2;
    c1.begin_frame(1);
    c2.begin_frame(1);
    for (int i = 0; i < 5; ++i) {
        c1.push_primitive(make_obs(0x24, 3, 0x10, 0x20, true, false));
        c2.push_primitive(make_obs(0x24, 3, 0x10, 0x20, true, false));
    }
    const ClusterEvent* e1 = c1.flush();
    const ClusterEvent* e2 = c2.flush();
    assert(e1 && e2);
    assert(e1->signature_id == e2->signature_id);
    std::printf("OK: identical metadata -> identical signature %016llx\n",
                static_cast<unsigned long long>(e1->signature_id));

    // 2. Different texpage -> different signature.
    PrimitiveClusterer c3;
    c3.begin_frame(1);
    for (int i = 0; i < 5; ++i) {
        c3.push_primitive(make_obs(0x24, 3, 0x11, 0x20, true, false));
    }
    const ClusterEvent* e3 = c3.flush();
    assert(e3);
    assert(e3->signature_id != e1->signature_id);
    std::printf("OK: distinct texpage -> distinct signature %016llx\n",
                static_cast<unsigned long long>(e3->signature_id));

    // 3. Adjacency graph: A -> B observed 10x should yield confidence ~1.
    RSILConfig cfg = RSILConfig::defaults();
    AdjacencyGraph g(cfg.transition_decay, cfg.min_observations);
    SignatureRegistry reg;
    SpatialCatalog cat;
    ClusterSignatureId a = e1->signature_id;
    reg.register_event(*e1);
    reg.register_event(*e3);

    for (uint32_t f = 0; f < 20; ++f) {
        g.observe_transition(a, e3->signature_id, f);
    }
    auto best = g.best_successor(a);
    assert(best.has_value());
    assert(best->to == e3->signature_id);
    // After 20 observations of A->B at decay=0.95, confidence approaches
    // 1 - 0.95^20 ≈ 0.64. The threshold here verifies the WMA is
    // accumulating correctly, not that it has converged.
    assert(best->confidence > 0.5f);
    std::printf("OK: A->B confidence after 20 observations = %.3f\n",
                best->confidence);

    // 4. Predictor emits a pre-reg request when above threshold.
    Predictor p(cfg, g, cat, reg);
    auto reqs = p.on_cluster_observed(a, 100);
    assert(!reqs.empty());
    assert(reqs[0].signature_id == e3->signature_id);
    std::printf("OK: predictor emitted %zu pre-reg request(s)\n", reqs.size());

    // 5. Spatial catalog assigns neighbors on transition.
    cat.register_cluster(a, kInvalidSignature, 1);
    cat.register_cluster(e3->signature_id, a, 2);
    auto neighbors = cat.neighbors_of(a);
    assert(!neighbors.empty());
    assert(neighbors[0] == e3->signature_id);
    std::printf("OK: catalog recorded neighbor link A -> B\n");

    std::printf("\nAll smoke tests passed.\n");
    return 0;
}
