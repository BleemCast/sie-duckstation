// D3/D10/D12/D13 verification stress test.
// Tests all 4 MIPS culling patterns for branch-direction safety,
// JSON escaping, parser desync watchdog, and registry restore.

#include "rsil/MipsPatternScanner.h"
#include "rsil/ScenePatchLayer.h"
#include "rsil/ClusterSignature.h"
#include "rsil/GpuPacketParser.h"
#include "rsil/AdjacencyGraph.h"
#include "rsil/Predictor.h"
#include "rsil/SpatialCatalog.h"
#include "rsil/TelemetryTap.h"
#include "rsil/Config.h"

#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace rsil;

static int g_failures = 0;
#define CHECK(cond, msg) do { \
    if (!(cond)) { std::printf("FAIL: %s (line %d)\n", msg, __LINE__); g_failures++; } \
    else { std::printf("OK:   %s\n", msg); } \
} while(0)

static void emit_word(std::vector<uint8_t>& buf, uint32_t w) {
    buf.push_back(static_cast<uint8_t>(w & 0xFF));
    buf.push_back(static_cast<uint8_t>((w >> 8) & 0xFF));
    buf.push_back(static_cast<uint8_t>((w >> 16) & 0xFF));
    buf.push_back(static_cast<uint8_t>((w >> 24) & 0xFF));
}

static std::vector<uint8_t> build_exe(const std::vector<uint8_t>& code) {
    std::vector<uint8_t> exe(0x800 + code.size(), 0);
    std::memcpy(exe.data(), "PS-X EXE", 8);
    std::memcpy(exe.data() + 0x10, "\x00\x00\x01\x80", 4);
    std::memcpy(exe.data() + 0x18, "\x00\x00\x01\x80", 4);
    uint32_t sz = static_cast<uint32_t>(code.size());
    std::memcpy(exe.data() + 0x1C, &sz, 4);
    std::memcpy(exe.data() + 0x800, code.data(), code.size());
    return exe;
}

// ============================================================================
// D3: P1 branch-direction (slti + beq/bne)
// ============================================================================
static void test_d3_p1() {
    std::printf("\n=== D3: P1 slti + beq/bne ===\n");
    uint32_t slti = (0x0A << 26) | (4 << 21) | (8 << 16) | 200;
    uint32_t beq  = (0x04 << 26) | (8 << 21) | (0 << 16) | 4;
    uint32_t bne  = (0x05 << 26) | (8 << 21) | (0 << 16) | 4;

    MipsPatternScanner scanner;
    scanner.set_value_range(50, 1000);

    // beq = cull-when-far = SAFE
    { std::vector<uint8_t> code; emit_word(code, slti); emit_word(code, beq); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      CHECK(!c.empty(), "P1 beq: found"); if (!c.empty()) {
          CHECK(c[0].auto_patchable, "P1 beq: auto-patchable (safe)");
          CHECK(c[0].patch_word == ((0x0A<<26)|(4<<21)|(8<<16)|32767), "P1 beq: patch word correct");
      }
    }
    // bne = cull-when-near = UNSAFE
    { std::vector<uint8_t> code; emit_word(code, slti); emit_word(code, bne); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      CHECK(!c.empty(), "P1 bne: found"); if (!c.empty()) {
          CHECK(!c[0].auto_patchable, "P1 bne: NOT auto-patchable (unsafe)");
          CHECK(c[0].patch_word == 0, "P1 bne: no patch word");
      }
    }
}

// ============================================================================
// D3: P2 branch-direction (addiu + subu + bltz/bgez)
// ============================================================================
static void test_d3_p2() {
    std::printf("\n=== D3: P2 addiu+subu + bltz/bgez ===\n");
    // addiu $t0, $zero, 200: op=0x09, rt=8, rs=0, imm=200
    uint32_t addiu = (0x09 << 26) | (0 << 21) | (8 << 16) | 200;
    // subu $t1, $a0, $t0: op=0x00, rs=4, rt=8, rd=9, funct=0x23
    uint32_t subu  = (0x00 << 26) | (4 << 21) | (8 << 16) | (9 << 11) | 0x23;
    // bgez $t1, +1: op=0x01, rs=9, rt=0x01, imm=1
    uint32_t bgez  = (0x01 << 26) | (9 << 21) | (0x01 << 16) | 1;
    // bltz $t1, +1: op=0x01, rs=9, rt=0x00, imm=1
    uint32_t bltz  = (0x01 << 26) | (9 << 21) | (0x00 << 16) | 1;

    MipsPatternScanner scanner;
    scanner.set_value_range(50, 1000);

    // bgez = cull-when-far = SAFE
    { std::vector<uint8_t> code; emit_word(code, addiu); emit_word(code, subu); emit_word(code, bgez); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      bool found = false;
      for (auto& cand : c) if (cand.pattern.find("P2") != std::string::npos) { found = true;
          CHECK(cand.auto_patchable, "P2 bgez: auto-patchable (safe)");
      }
      CHECK(found, "P2 bgez: found");
    }
    // bltz = cull-when-near = UNSAFE
    { std::vector<uint8_t> code; emit_word(code, addiu); emit_word(code, subu); emit_word(code, bltz); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      bool found = false;
      for (auto& cand : c) if (cand.pattern.find("P2") != std::string::npos) { found = true;
          CHECK(!cand.auto_patchable, "P2 bltz: NOT auto-patchable (unsafe)");
      }
      CHECK(found, "P2 bltz: found");
    }
}

// ============================================================================
// D3: P3 branch-direction (addiu-neg + bltz/bgez)
// ============================================================================
static void test_d3_p3() {
    std::printf("\n=== D3: P3 addiu-neg + bltz/bgez ===\n");
    // addiu $t0, $a0, -200: op=0x09, rs=4, rt=8, imm=-200
    uint32_t addiu = (0x09 << 26) | (4 << 21) | (8 << 16) | (static_cast<uint16_t>(-200));
    uint32_t bgez  = (0x01 << 26) | (8 << 21) | (0x01 << 16) | 1;
    uint32_t bltz  = (0x01 << 26) | (8 << 21) | (0x00 << 16) | 1;

    MipsPatternScanner scanner;
    scanner.set_value_range(50, 1000);

    // bgez = cull-when-far = SAFE
    { std::vector<uint8_t> code; emit_word(code, addiu); emit_word(code, bgez); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      bool found = false;
      for (auto& cand : c) if (cand.pattern.find("P3") != std::string::npos) { found = true;
          CHECK(cand.auto_patchable, "P3 bgez: auto-patchable (safe)");
      }
      CHECK(found, "P3 bgez: found");
    }
    // bltz = cull-when-near = UNSAFE
    { std::vector<uint8_t> code; emit_word(code, addiu); emit_word(code, bltz); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      bool found = false;
      for (auto& cand : c) if (cand.pattern.find("P3") != std::string::npos) { found = true;
          CHECK(!cand.auto_patchable, "P3 bltz: NOT auto-patchable (unsafe)");
      }
      CHECK(found, "P3 bltz: found");
    }
}

// ============================================================================
// D3: P6 branch-direction (addiu + sltu + beq/bne)
// ============================================================================
static void test_d3_p6() {
    std::printf("\n=== D3: P6 addiu+sltu + beq/bne ===\n");
    // addiu $t0, $zero, 200: op=0x09, rt=8, rs=0, imm=200
    uint32_t addiu = (0x09 << 26) | (0 << 21) | (8 << 16) | 200;
    // sltu $t1, $a0, $t0: op=0x00, rs=4, rt=8, rd=9, funct=0x2B
    uint32_t sltu  = (0x00 << 26) | (4 << 21) | (8 << 16) | (9 << 11) | 0x2B;
    uint32_t beq   = (0x04 << 26) | (9 << 21) | (0 << 16) | 1;
    uint32_t bne   = (0x05 << 26) | (9 << 21) | (0 << 16) | 1;

    MipsPatternScanner scanner;
    scanner.set_value_range(50, 1000);

    // beq = cull-when-far = SAFE
    { std::vector<uint8_t> code; emit_word(code, addiu); emit_word(code, sltu); emit_word(code, beq); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      bool found = false;
      for (auto& cand : c) if (cand.pattern.find("P6") != std::string::npos) { found = true;
          CHECK(cand.auto_patchable, "P6 beq: auto-patchable (safe)");
      }
      CHECK(found, "P6 beq: found");
    }
    // bne = cull-when-near = UNSAFE
    { std::vector<uint8_t> code; emit_word(code, addiu); emit_word(code, sltu); emit_word(code, bne); code.resize(0x1000, 0);
      PsxExeInfo exe; parse_psx_exe(build_exe(code).data(), 0x900 + code.size(), exe);
      auto c = scanner.scan(exe);
      bool found = false;
      for (auto& cand : c) if (cand.pattern.find("P6") != std::string::npos) { found = true;
          CHECK(!cand.auto_patchable, "P6 bne: NOT auto-patchable (unsafe)");
      }
      CHECK(found, "P6 bne: found");
    }
}

// ============================================================================
// D10: JSON escaping
// ============================================================================
static void test_d10() {
    std::printf("\n=== D10: JSON escaping ===\n");
    // Unescaped quote breaks parsing
    std::string bad_json = "{\n  \"display_name\": \"Test\"Game\",\n  \"patches\": []\n}\n";
    PatchManifest parsed_bad;
    CHECK(!parse_manifest_json(bad_json, parsed_bad), "Unescaped quote fails (bug repro)");

    // Escaped quote parses correctly
    std::string good_json = "{\n  \"display_name\": \"Test\\\"Game\",\n  \"patches\": []\n}\n";
    PatchManifest parsed_good;
    CHECK(parse_manifest_json(good_json, parsed_good), "D10: escaped JSON parses");
    if (parse_manifest_json(good_json, parsed_good)) {
        CHECK(parsed_good.display_name == "Test\"Game", "D10: round-trip correct");
    }
}

// ============================================================================
// D12: Parser desync watchdog
// ============================================================================
static void test_d12() {
    std::printf("\n=== D12: Parser desync watchdog ===\n");
    GpuPacketParser parser;
    // 0x3C = textured gouraud quad, expects 13 words
    uint32_t quad_cmd = (0x3C << 24) | 0xFFFFFF;
    parser.on_word(quad_cmd, 0);  // cmd word, expects 13 total
    // Feed 17 more words — watchdog triggers at 16 accumulated
    for (int i = 0; i < 17; ++i) parser.on_word(0xDEADBEEF, 0);
    CHECK(parser.stats().desyncs >= 1, "D12: watchdog triggered on stuck accumulation");

    // Verify parser recovers and can parse normally
    GpuPacketParser parser2;
    uint32_t tri_cmd = (0x24 << 24) | 0xFFFFFF;
    parser2.on_word(tri_cmd, 0);
    parser2.on_word(0x00010000, 0); parser2.on_word(0x00010000, 0);
    parser2.on_word(0x00000000, 0); parser2.on_word(0x00100000, 0);
    parser2.on_word(0x00000000, 0); parser2.on_word(0x00200000, 0);
    parser2.on_word(0x00000000, 0);
    CHECK(parser2.stats().primitives_emitted >= 1, "D12: parser recovers, triangle parsed");
}

// ============================================================================
// D13: SignatureRegistry::restore()
// ============================================================================
static void test_d13() {
    std::printf("\n=== D13: SignatureRegistry restore ===\n");
    SignatureRegistry reg;
    ClusterEvent ev;
    ev.topology = PrimitiveTopology::Polygon;
    ev.attrs.texpage = 0x100;
    ev.total_vertex_count = 3;
    ev.frame = 1;
    ev.signature_id = compute_signature(ev);
    reg.register_event(ev);
    auto snap = reg.snapshot();
    CHECK(snap.size() == 1, "Snapshot has 1 entry");

    SignatureRegistry reg2;
    reg2.restore(snap);
    const SignatureEntry* reloaded = reg2.lookup(ev.signature_id);
    CHECK(reloaded != nullptr, "D13: restore() makes entry lookable");
    if (reloaded) {
        CHECK(reloaded->attrs.texpage == 0x100, "D13: texpage preserved");
        CHECK(reloaded->observation_count == 1, "D13: obs count preserved");
    }
}

int main() {
    test_d3_p1();
    test_d3_p2();
    test_d3_p3();
    test_d3_p6();
    test_d10();
    test_d12();
    test_d13();
    std::printf("\n=== Summary: %d failures ===\n", g_failures);
    return g_failures == 0 ? 0 : 1;
}
