// SPDX-License-Identifier: BSD-3-Clause
// RSIL — MipsPatternScanner test.
//
// Verifies the C++ scanner finds the same patterns as the Python scanner.
// Uses a synthetic PS-X EXE with known culling instruction patterns.

#include "rsil/MipsPatternScanner.h"

#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace rsil;

// Pack a 32-bit MIPS word into a little-endian byte buffer.
static void emit_word(std::vector<uint8_t>& buf, uint32_t w) {
    buf.push_back(static_cast<uint8_t>(w & 0xFF));
    buf.push_back(static_cast<uint8_t>((w >> 8) & 0xFF));
    buf.push_back(static_cast<uint8_t>((w >> 16) & 0xFF));
    buf.push_back(static_cast<uint8_t>((w >> 24) & 0xFF));
}

// Build a minimal PS-X EXE image with the given code.
static std::vector<uint8_t> build_exe(const std::vector<uint8_t>& code) {
    std::vector<uint8_t> exe(0x800 + code.size(), 0);
    // Magic
    std::memcpy(exe.data(), "PS-X EXE", 8);
    // initial_pc at 0x10
    std::memcpy(exe.data() + 0x10, "\x00\x00\x01\x80", 4);
    // text_addr at 0x18
    std::memcpy(exe.data() + 0x18, "\x00\x00\x01\x80", 4);
    // text_size at 0x1C
    uint32_t sz = static_cast<uint32_t>(code.size());
    std::memcpy(exe.data() + 0x1C, &sz, 4);
    // Code at 0x800
    std::memcpy(exe.data() + 0x800, code.data(), code.size());
    return exe;
}

int main() {
    // Build code with a known slti+branch pattern.
    // slti $t0, $a0, 200: op=0x0A, rs=4($a0), rt=8($t0), imm=200
    uint32_t slti = (0x0A << 26) | (4 << 21) | (8 << 16) | 200;
    // D3 fix: beq (cull-when-far) is the SAFE branch direction.
    // The old test used bne (cull-when-near) which D3 now correctly rejects.
    uint32_t beq  = (0x04 << 26) | (8 << 21) | (0 << 16) | 4;

    std::vector<uint8_t> code;
    emit_word(code, slti);
    emit_word(code, beq);
    // Pad to 0x1000
    code.resize(0x1000, 0);

    auto exe_data = build_exe(code);

    // 1. Parse the PS-X EXE.
    PsxExeInfo exe;
    bool parsed = parse_psx_exe(exe_data.data(), exe_data.size(), exe);
    assert(parsed);
    assert(exe.text_addr == 0x80010000);
    assert(exe.code.size() >= 8);
    std::printf("OK: PS-X EXE parsed (text_addr=0x%08X, %zu bytes)\n",
                exe.text_addr, exe.code.size());

    // 2. Scan.
    MipsPatternScanner scanner;
    scanner.set_value_range(50, 1000);
    scanner.set_scan_floats(true);
    auto candidates = scanner.scan(exe);

    assert(!candidates.empty());
    assert(candidates[0].pattern == "P1-slti");
    assert(candidates[0].value == 200);
    assert(candidates[0].auto_patchable);
    std::printf("OK: found P1-slti candidate at 0x%08X (value=%d, auto=%d)\n",
                candidates[0].address, candidates[0].value,
                candidates[0].auto_patchable ? 1 : 0);

    // 3. Verify the AOB bytes match the original instruction.
    assert(candidates[0].orig_bytes[0] == (slti & 0xFF));
    assert(candidates[0].orig_bytes[1] == ((slti >> 8) & 0xFF));
    std::printf("OK: AOB bytes = %02X %02X %02X %02X\n",
                candidates[0].orig_bytes[0], candidates[0].orig_bytes[1],
                candidates[0].orig_bytes[2], candidates[0].orig_bytes[3]);

    // 4. Verify the patch word replaces the immediate with 32767.
    uint32_t expected_patch = (0x0A << 26) | (4 << 21) | (8 << 16) | 32767;
    assert(candidates[0].patch_word == expected_patch);
    std::printf("OK: patch word = 0x%08X (immediate maxed to 32767)\n",
                candidates[0].patch_word);

    // 5. Convert to manifest.
    ExecutableSignature sig;
    sig.display_name = "Test Game";
    auto manifest = scanner.to_manifest(candidates, sig, "Test Game");
    assert(!manifest.patches.empty());
    assert(manifest.patches[0].pattern_hex.size() > 0);
    std::printf("OK: manifest has %zu patches\n", manifest.patches.size());
    std::printf("    patch[0].pattern = \"%s\"\n", manifest.patches[0].pattern_hex.c_str());
    std::printf("    patch[0].replacement = \"%s\"\n", manifest.patches[0].replacement_hex.c_str());

    // 6. Stats.
    const auto& s = scanner.stats();
    assert(s.total_candidates >= 1);
    assert(s.auto_patchable >= 1);
    std::printf("OK: stats (total=%u, auto=%u, scan_time=%llu us)\n",
                s.total_candidates, s.auto_patchable,
                (unsigned long long)s.scan_time_us);

    std::printf("\nAll MipsPatternScanner tests passed.\n");
    return 0;
}
