// SPDX-License-Identifier: BSD-3-Clause
// RSIL — DuckStation HostAdapter (v0.1-11515) implementation.

#include "DuckStationHostAdapter.h"

// DuckStation headers needed for SafeWriteMemoryWord (JIT-safe RAM writes)
// and Bus::g_ram_size. These are resolved via the DuckStation include
// paths configured in CMakeLists.txt.
// When building standalone (without DuckStation), these includes are
// absent and the DuckStationRamAccess methods compile to stubs.
#ifdef RSIL_DUCKSTATION_INTEGRATED
#include "cpu_core.h"       // CPU::SafeWriteMemoryWord, CPU::SafeReadMemoryBytes
#include "bus.h"            // Bus::g_ram_size
#include "cpu_code_cache.h" // CPU::CodeCache (for documentation; called internally by SafeWrite)
#endif

// For thread-priority elevation.
#ifdef _WIN32
#include <windows.h>
#else
#include <sched.h>
#include <thread>
#endif

namespace rsil {

// ---------------------------------------------------------------------------
// DuckStationRamAccess — JIT-safe RAM access for ScenePatchLayer
// ---------------------------------------------------------------------------

bool DuckStationRamAccess::read(uint32_t address, uint8_t* dest, size_t size) {
#ifdef RSIL_DUCKSTATION_INTEGRATED
    // CPU::SafeReadMemoryBytes handles address translation (KUSEG/KSEG0/KSEG1)
    // and RAM mirroring. It reads from g_unprotected_ram (safe for code pages).
    return CPU::SafeReadMemoryBytes(address, dest, static_cast<u32>(size));
#else
    // Standalone mode: no DuckStation headers available. Return false to
    // indicate the operation is not supported.
    (void)address; (void)dest; (void)size;
    return false;
#endif
}

bool DuckStationRamAccess::write(uint32_t address, const uint8_t* src, size_t size) {
#ifdef RSIL_DUCKSTATION_INTEGRATED
    // CRITICAL: we must use CPU::SafeWriteMemoryBytes (or word/halfword
    // variants) instead of writing to g_unprotected_ram directly.
    //
    // SafeWriteMemoryWord does three things:
    //   1. Writes to g_unprotected_ram[offset] (bypasses page protection)
    //   2. Checks g_ram_code_bits[page_index] — is this a code page?
    //   3. If yes, calls CPU::CodeCache::InvalidateBlocksWithPageIndex(page_index)
    //      — flushes the JIT cache for that page so the patched code
    //        takes effect immediately
    //
    // If we bypassed this and wrote to g_unprotected_ram directly, the
    // JIT cache would still contain the old (unpatched) code, and the
    // patches would have no effect until the block was naturally evicted.
    //
    // CPU::SafeWriteMemoryBytes internally calls SafeWriteMemoryByte for
    // each byte, which triggers the same invalidation path. For aligned
    // word writes, we use SafeWriteMemoryWord directly for efficiency.
    //
    // The address must be a virtual address (e.g. 0x80010000 for the
    // typical PS-X EXE load address). SafeWriteMemoryWord handles the
    // KUSEG/KSEG0/KSEG1 segment translation internally.
    return CPU::SafeWriteMemoryBytes(address, src, static_cast<u32>(size));
#else
    (void)address; (void)src; (void)size;
    return false;
#endif
}

size_t DuckStationRamAccess::ram_size() {
#ifdef RSIL_DUCKSTATION_INTEGRATED
    return Bus::g_ram_size;
#else
    return 0;
#endif
}

// ---------------------------------------------------------------------------
// DuckStationHostAdapter
// ---------------------------------------------------------------------------

DuckStationHostAdapter::DuckStationHostAdapter() = default;
DuckStationHostAdapter::~DuckStationHostAdapter() = default;

HostPreRegToken DuckStationHostAdapter::preregister_descriptor(
    TexpageId texpage, ClutId clut, CellId hint_cell) {
    // In DuckStation v0.1-11515, there are no per-draw descriptor sets.
    // DuckStation uses push constants and a fixed binding model. The
    // "descriptor pre-registration" concept from the original RSIL
    // design doesn't apply here.
    //
    // What we COULD do is hint the texture cache to pre-validate the
    // VRAM region for (texpage, clut). However, DuckStation's
    // GPUTextureCache::LookupSource takes a SourceKey that encodes
    // PS1 VRAM page coordinates, not raw texpage/CLUT values. Converting
    // between them requires the same bit-field extraction the GPU
    // backend does, which would duplicate engine logic.
    //
    // For now, this is a no-op that mints a token so RSIL's accounting
    // (active slot count) remains consistent. The real benefit comes
    // from elevate_priority() below.
    std::lock_guard<std::mutex> g(mu_);
    (void)texpage; (void)clut; (void)hint_cell;
    HostPreRegToken token = next_token_++;
    stats_.total_hints_issued++;
    stats_.active_hints++;
    return token;
}

void DuckStationHostAdapter::preregister_shader(const PrimitiveAttributes& attrs) {
    // DuckStation pre-compiles all shader variants at startup via
    // GPU_HW::CreatePipelines(). The GPUShaderCache is disk-persistent.
    // No action needed.
    (void)attrs;
}

void DuckStationHostAdapter::preregister_pipeline(ClusterSignatureId sig) {
    // DuckStation pre-creates all m_batch_pipelines variants at startup.
    // No action needed.
    (void)sig;
}

void DuckStationHostAdapter::release_preregistration(HostPreRegToken token) {
    std::lock_guard<std::mutex> g(mu_);
    (void)token;
    if (stats_.active_hints > 0) stats_.active_hints--;
}

void DuckStationHostAdapter::elevate_priority(uint32_t microseconds) {
    // Hint to the OS scheduler. On Windows we briefly raise the GPU
    // thread priority. This is the primary mechanism by which RSIL
    // reduces host-side frame-time variance in DuckStation: by ensuring
    // the emulated DMA transfer for a predicted sector completes within
    // the current frame budget.
    //
    // The duration is capped at 5ms to avoid pathological scenarios.
    if (microseconds > 5000) microseconds = 5000;

#ifdef _WIN32
    HANDLE t = GetCurrentThread();
    int prev = GetThreadPriority(t);
    SetThreadPriority(t, THREAD_PRIORITY_ABOVE_NORMAL);
    // The OS reverts at the next scheduler tick when the thread blocks.
    (void)prev;
#else
    std::this_thread::yield();
#endif
    std::lock_guard<std::mutex> g(mu_);
    stats_.priority_elevations++;
    (void)microseconds;
}

void DuckStationHostAdapter::feed_culler(CellId cell,
                                         const std::vector<CellId>& neighbors) {
    // DuckStation doesn't have a separate host-side frustum culler for
    // PS1 geometry (the PS1 engine does its own culling). No action.
    (void)cell; (void)neighbors;
}

void DuckStationHostAdapter::draw_overlay() {
    // The overlay is drawn by RSIL's DebugOverlay, invoked from
    // ImGuiManager::RenderDebugWindows via System::GetRSIL()->DrawOverlay().
    // This method is a no-op.
}

}  // namespace rsil
