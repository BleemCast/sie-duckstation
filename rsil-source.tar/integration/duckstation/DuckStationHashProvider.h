// SPDX-License-Identifier: BSD-3-Clause
// RSIL — DuckStation HashProvider.
//
// Concrete HashProvider that reads CPU registers, RAM, VRAM, and the GPU
// command stream from DuckStation's live emulator state. Used by the
// Validator to prove zero emulation divergence.
//
// DuckStation integration notes
// -----------------------------
// The relevant DuckStation classes:
//   - CPU::Core (src/core/cpu_core.h) — register file access
//   - Bus       (src/core/bus.h)      — main RAM access
//   - GPU       (src/core/gpu.h)      — VRAM access + command log
//
// Hashing strategy: MD5 of the raw byte ranges. MD5 is sufficient
// because the validator only needs collision-resistance within a single
// game session, not cryptographic strength. (CRC32 would also work but
// has higher collision rates over ~2MB VRAM ranges.)

#pragma once

#include "rsil/Validator.h"

// Forward declarations.
namespace CPU { class Core; }
namespace Bus { class Bus; }
class GPU;

namespace rsil {

class DuckStationHashProvider final : public HashProvider {
public:
    DuckStationHashProvider();
    ~DuckStationHashProvider() override;

    // Bind to live emulator state. All pointers must outlive the
    // provider; DuckStation guarantees this for the duration of a game
    // session.
    void bind_state(CPU::Core* cpu, Bus::Bus* bus, GPU* gpu);

    // -------- HashProvider interface --------
    std::array<uint8_t, 16> hash_cpu_registers() override;
    std::array<uint8_t, 16> hash_ram() override;
    std::array<uint8_t, 16> hash_vram() override;
    std::array<uint8_t, 16> hash_gpu_command_stream() override;

private:
    CPU::Core* cpu_ = nullptr;
    Bus::Bus*  bus_ = nullptr;
    GPU*       gpu_ = nullptr;
};

}  // namespace rsil
