// SPDX-License-Identifier: BSD-3-Clause
// RSIL — DuckStation HashProvider implementation.

#include "DuckStationHashProvider.h"

#include "core/cpu_core.h"
#include "core/bus.h"
#include "core/gpu.h"

// Tiny embedded MD5 (or use DuckStation's existing MD5 util if present).
// We use DuckStation's MD5 helper when available; otherwise fall back to
// a small inline implementation. To keep this file self-contained, we
// use DuckStation's common/MD5Digest.h.

#include "common/MD5Digest.h"

namespace rsil {

namespace {

template <typename T>
std::array<uint8_t, 16> md5_of(const T* data, size_t bytes) {
    std::array<uint8_t, 16> out{};
    MD5Digest digest;
    digest.Update(static_cast<const u8*>(static_cast<const void*>(data)),
                  static_cast<u32>(bytes));
    digest.Final(out.data());
    return out;
}

}  // namespace

DuckStationHashProvider::DuckStationHashProvider() = default;
DuckStationHashProvider::~DuckStationHashProvider() = default;

void DuckStationHashProvider::bind_state(CPU::Core* cpu, Bus::Bus* bus, GPU* gpu) {
    cpu_ = cpu; bus_ = bus; gpu_ = gpu;
}

std::array<uint8_t, 16> DuckStationHashProvider::hash_cpu_registers() {
    if (!cpu_) return {};
    // CPU::Core exposes the register file via cpu_->regs (an array of
    // 32 u32 GPRs + HI + LO + PC). The exact layout is version-stable
    // within DuckStation's main branch.
    return md5_of(cpu_->regs.data(),
                  cpu_->regs.size() * sizeof(u32));
}

std::array<uint8_t, 16> DuckStationHashProvider::hash_ram() {
    if (!bus_) return {};
    // Bus exposes RAM as a contiguous 2MB byte array via bus_->m_RAMPtr.
    // We hash the full 2MB; this is ~6ms on modern CPUs and runs once
    // per sampled frame.
    return md5_of(bus_->m_RAMPtr, Bus::RAM_SIZE);
}

std::array<uint8_t, 16> DuckStationHashProvider::hash_vram() {
    if (!gpu_) return {};
    // GPU exposes VRAM as a 1MB byte array (1024x512x2 bytes).
    return md5_of(gpu_->GetVRAM().data(),
                  gpu_->GetVRAM().size() * sizeof(u16));
}

std::array<uint8_t, 16> DuckStationHashProvider::hash_gpu_command_stream() {
    if (!gpu_) return {};
    // GPU exposes a bounded ring buffer of recently-received GP0/GP1
    // words. Hashing this ring proves the command stream is identical.
    const auto& ring = gpu_->GetCommandRing();
    return md5_of(ring.data(), ring.size() * sizeof(u32));
}

}  // namespace rsil
