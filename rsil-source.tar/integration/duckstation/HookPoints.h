// SPDX-License-Identifier: BSD-3-Clause
// RSIL — DuckStation hook points.
//
// This file documents the EXACT lines in DuckStation's source tree where
// RSIL integration is performed. The apply_rsil.sh / apply_rsil.ps1
// patch scripts read this manifest and emit the corresponding patches.
//
// Hook points are versioned by git commit hash. When DuckStation's API
// drifts, the patch scripts will fail loudly and the manifest must be
// updated. This is intentional: silent API drift would corrupt the
// emulator.

#pragma once

#include <string>
#include <vector>

namespace rsil {
namespace integration {

struct HookPoint {
    // Relative path inside the DuckStation source tree.
    std::string file;
    // Anchor string: a unique substring of the line being patched.
    // The patch script searches for this anchor and inserts before/after.
    std::string anchor;
    // "before" | "after" | "replace"
    std::string mode;
    // The code to insert (or the replacement).
    std::string code;
    // Human-readable description for the patch log.
    std::string description;
};

// All hook points required for full RSIL integration.
// Order matters: patches are applied top-to-bottom.
inline std::vector<HookPoint> hook_points() {
    return {
        // 1. System header: add RSILSubsystem member to System class.
        {
            "core/system.h",
            "class HostInterface;",
            "before",
            "#include \"rsil/rsil_subsystem_fwd.h\"\n"
            "namespace rsil { class RSILSubsystem; }",
            "Forward-declare RSILSubsystem in System header"
        },

        // 2. System header: add member field.
        {
            "core/system.h",
            "std::unique_ptr<GPU> m_gpu;",
            "after",
            "    std::unique_ptr<rsil::RSILSubsystem> m_rsil;",
            "Add RSILSubsystem member to System"
        },

        // 3. System::Initialize: construct RSIL after GPU.
        {
            "core/system.cpp",
            "m_gpu = GPU::CreateHardwareRenderer();",
            "after",
            "    // RSIL: construct subsystem bound to the new GPU.\n"
            "    m_rsil = rsil::RSILSubsystem::create(\n"
            "        rsil::RSILConfig::defaults(),\n"
            "        *m_host_adapter,\n"
            "        std::make_unique<rsil::DuckStationHashProvider>(),\n"
            "        rsil::make_sqlite_backend());\n"
            "    if (m_rsil) m_rsil->on_executable_loaded(m_exe_signature);",
            "Construct RSILSubsystem after GPU creation"
        },

        // 4. GPU command write: tap GP0/GP1 writes.
        {
            "core/gpu.cpp",
            "void GPU::WriteGP0(u32 value) {",
            "after",
            "    // RSIL: tap the command stream (read-only).\n"
            "    if (m_system.HasRSIL()) {\n"
            "        m_system.GetRSIL().GetTelemetryTap().emit_gpu_command(0, value, m_frame_number);\n"
            "    }",
            "Tap GP0 writes for RSIL telemetry"
        },

        // 5. DMA transfer: tap CH1/CH2.
        {
            "core/gpu.cpp",
            "void GPU::DMARead(u32* words, u32 word_count) {",
            "after",
            "    // RSIL: tap DMA reads (read-only).\n"
            "    if (m_system.HasRSIL()) {\n"
            "        m_system.GetRSIL().GetTelemetryTap().emit_dma_packet(\n"
            "            1, 0 /*src*/, 0 /*dst*/, word_count, m_frame_number);\n"
            "    }",
            "Tap DMA reads for RSIL telemetry"
        },

        // 6. VSync: pump RSIL per frame.
        {
            "core/gpu.cpp",
            "void GPU::VSync() {",
            "after",
            "    // RSIL: per-frame pump. Drives cluster finalization,\n"
            "    // predictor look-ahead, host pre-registration, validator.\n"
            "    if (m_system.HasRSIL()) {\n"
            "        m_system.GetRSIL().Pump(m_frame_number);\n"
            "    }",
            "Pump RSIL per VSync"
        },

        // 7. ImGui overlay: draw RSIL panels.
        {
            "frontend-common/imgui_manager.cpp",
            "void ImGuiManager::RenderDebugWindows() {",
            "after",
            "    // RSIL: draw overlay panels if enabled.\n"
            "    if (m_system && m_system->HasRSIL()) {\n"
            "        m_system->GetRSIL().DrawOverlay();\n"
            "    }",
            "Draw RSIL overlay in ImGui pass"
        },

        // 8. Executable load: compute ExecutableSignature.
        {
            "core/system.cpp",
            "bool System::LoadEXE(const char* path) {",
            "after",
            "    // RSIL: compute MD5/CRC32 of the loaded executable image.\n"
            "    m_exe_signature = rsil::integration::compute_exe_signature(exe_data);",
            "Compute ExecutableSignature on game load"
        },

        // 9. System::Destroy: flush persistence.
        {
            "core/system.cpp",
            "void System::Destroy() {",
            "after",
            "    // RSIL: flush persistence before tearing down.\n"
            "    if (m_rsil) m_rsil->on_executable_unloaded();\n"
            "    m_rsil.reset();",
            "Flush RSIL persistence on shutdown"
        },
    };
}

// Compute an ExecutableSignature from a loaded PS-EXE image.
// Implemented in DuckStationHashProvider.cpp.
struct ExecutableSignature compute_exe_signature(const std::vector<uint8_t>& exe_data);

}  // namespace integration
}  // namespace rsil
