// SPDX-License-Identifier: BSD-3-Clause
// RSIL — DuckStation HostAdapter (v0.1-11515).
//
// Concrete HostAdapter wired to DuckStation's renderer API.
//
// ARCHITECTURE NOTE
// -----------------
// DuckStation v0.1-11515 already pre-creates ALL pipeline variants at
// startup (m_batch_pipelines is a 7-dimensional array built in
// GPU_HW::CreatePipelines). There is no lazy PSO compilation at draw
// time. The shader cache (GPUShaderCache) is disk-persistent. Descriptor
// sets are not per-draw (DuckStation uses push constants).
//
// This means three of the four original RSIL pre-registration targets
// are already solved by DuckStation:
//   - Pipeline state objects: pre-created at startup. RSIL does nothing.
//   - Shader variants: disk-cached. RSIL does nothing.
//   - Descriptor sets: not used per-draw. RSIL does nothing.
//
// The remaining lever is TEXTURE RESIDENCY. DuckStation's GPUTextureCache
// lazily uploads PS1 VRAM regions to host GPU textures on first reference.
// When a new track sector streams in, the first draw referencing its
// textures triggers a VRAM-to-host-texture upload, which can cause a
// frame-time spike.
//
// RSIL's role: predict which VRAM regions will be needed soon (based on
// the cluster signature + spatial catalog) and hint the texture cache
// to pre-validate those regions before the actual draw arrives. This is
// advisory — the texture cache is free to ignore the hint.
//
// The HostAdapter also provides the priority-elevation hint for the
// predicted DMA transfer window, which IS useful (ensures the emulated
// DMA completes within the frame budget).
//
// CODE CACHE SAFETY
// -----------------
// The DuckStationRamAccess class (defined below) implements RSIL's
// RamAccess interface using CPU::SafeWriteMemoryWord. This is CRITICAL:
// writing to a code page via SafeWriteMemoryWord triggers JIT cache
// invalidation via CPU::CodeCache::InvalidateBlocksWithPageIndex.
// Bypassing this (e.g. writing to g_unprotected_ram directly) would
// leave stale JIT-compiled code executing after RSIL patches RAM.

#pragma once

#include "rsil/Config.h"
#include "rsil/Types.h"
#include "rsil/ScenePatchLayer.h"

#include <mutex>
#include <unordered_map>

namespace rsil {

// DuckStationRamAccess: implements RSIL's RamAccess interface using
// DuckStation's CPU::SafeWriteMemoryWord / CPU::SafeReadMemoryBytes.
// This ensures JIT cache invalidation is triggered when RSIL patches
// code pages.
class DuckStationRamAccess final : public RamAccess {
public:
    bool read(uint32_t address, uint8_t* dest, size_t size) override;
    bool write(uint32_t address, const uint8_t* src, size_t size) override;
    size_t ram_size() override;
};

// DuckStationHostAdapter: bridges RSIL -> DuckStation renderer.
class DuckStationHostAdapter final : public HostAdapter {
public:
    DuckStationHostAdapter();
    ~DuckStationHostAdapter() override;

    // -------- HostAdapter interface --------

    HostPreRegToken preregister_descriptor(TexpageId texpage,
                                           ClutId clut,
                                           CellId hint_cell) override;
    void preregister_shader(const PrimitiveAttributes& attrs) override;
    void preregister_pipeline(ClusterSignatureId sig) override;
    void release_preregistration(HostPreRegToken token) override;
    void elevate_priority(uint32_t microseconds) override;
    void feed_culler(CellId cell, const std::vector<CellId>& neighbors) override;
    void draw_overlay() override;

    struct Stats {
        uint32_t active_hints = 0;
        uint64_t total_hints_issued = 0;
        uint64_t priority_elevations = 0;
    };
    const Stats& stats() const { return stats_; }

private:
    std::mutex mu_;
    HostPreRegToken next_token_ = 1;
    Stats stats_;
};

}  // namespace rsil

