#!/usr/bin/env python3
"""
Wipeout 2097 — Comprehensive MIPS Culling Scanner

Scans a PS1 disc image's executable for ALL possible culling patterns
based on the PS1 SDK rendering pipeline:

  CPU → GTE (RTPS/RTPT) → SZ/OTZ depth output → culling decision → DMA to GPU

The culling decision is a MIPS comparison + conditional branch. This scanner
finds every possible comparison pattern that could implement it.

Patterns scanned:
  1. slti/sltiu + branch        (integer compare)
  2. subu/sub + bltz/bgez       (subtraction compare)
  3. addiu + bltz/bgez          (add-negative compare)
  4. c.le.s/c.lt.s + bc1t/bc1f (float compare)
  5. cfc2 + andi + bne/beq      (GTE flag check)
  6. sltu + branch              (unsigned range check, sector-based)

Usage:
  python3 wipeout-scanner.py "Wipeout XL.bin"
  python3 wipeout-scanner.py "Wipeout XL.bin" --range 100 500
  python3 wipeout-scanner.py "Wipeout XL.bin" --float

Output:
  - Console: ranked list of candidates with full MIPS context
  - File: wipeout-draw-distance.cht (DuckStation cheat file)
"""

import struct
import sys
import os
import argparse

# ============================================================================
#  MIPS instruction encoding (from MIPS R3000A reference)
# ============================================================================

def get_bits(word, hi, lo):
    return (word >> lo) & ((1 << (hi - lo + 1)) - 1)

def sign_extend_16(val):
    if val & 0x8000:
        return val - 0x10000
    return val

# Opcodes (bits 31-26)
OP_SPECIAL = 0x00  # R-type
OP_REGIMM  = 0x01  # BLTZ, BGEZ
OP_J       = 0x02
OP_JAL     = 0x03
OP_BEQ     = 0x04
OP_BNE     = 0x05
OP_BLEZ    = 0x06
OP_BGTZ    = 0x07
OP_ADDI    = 0x08
OP_ADDIU   = 0x09
OP_SLTI    = 0x0A
OP_SLTIU   = 0x0B
OP_ANDI    = 0x0C
OP_ORI     = 0x0D
OP_LUI     = 0x0F
OP_COP1    = 0x11  # Float operations
OP_COP2    = 0x12  # GTE operations
OP_LW      = 0x23
OP_LWC2    = 0x32  # Load word from GTE
OP_SW      = 0x2B

# SPECIAL funct codes (bits 5-0)
F_SUB   = 0x22
F_SUBU  = 0x23
F_SLT   = 0x2A
F_SLTU  = 0x2B
F_JR    = 0x08

# REGIMM rt codes (bits 20-16)
RT_BLTZ  = 0x00
RT_BGEZ  = 0x01

# COP1 (float) — bc1t/bc1f are COP1 BC instructions
# Format: 010001 01000 offset16  (bc1t)
#          bc1t: op=0x11, rs=0x08
#          bc1f: op=0x11, rs=0x00
# Actually: COP1 BC format is (0x11 << 26) | (0x01 << 21) | (tf << 16) | offset
# tf=1 for bc1t, tf=0 for bc1f

# COP2 (GTE) — cfc2 is (0x12 << 26) | (0x00 << 21) | (rt << 16) | (rd << 11) | (0 << 6) | 0x00
# Actually cfc2 format: op=COP2(0x12), rs=0 (mfc2=0, cfc2=2)
# cfc2: 010010 00010 rt rd 00000 000000

REG_NAMES = [
    "$zero", "$at", "$v0", "$v1", "$a0", "$a1", "$a2", "$a3",
    "$t0", "$t1", "$t2", "$t3", "$t4", "$t5", "$t6", "$t7",
    "$s0", "$s1", "$s2", "$s3", "$s4", "$s5", "$s6", "$s7",
    "$t8", "$t9", "$k0", "$k1", "$gp", "$sp", "$fp", "$ra"
]

# ============================================================================
#  Pattern detection
# ============================================================================

def is_conditional_branch(word):
    """Returns (is_branch, branch_type, target_offset) or (False, None, None)."""
    op = get_bits(word, 31, 26)
    rt = get_bits(word, 20, 16)
    imm = sign_extend_16(get_bits(word, 15, 0))

    if op == OP_BEQ:
        return True, "beq", imm
    if op == OP_BNE:
        return True, "bne", imm
    if op == OP_BLEZ:
        return True, "blez", imm
    if op == OP_BGTZ:
        return True, "bgtz", imm
    if op == OP_REGIMM:
        if rt == RT_BLTZ:
            return True, "bltz", imm
        if rt == RT_BGEZ:
            return True, "bgez", imm
    # bc1t/bc1f: COP1 with BC sub-op
    if op == OP_COP1:
        rs = get_bits(word, 25, 21)
        if rs == 0x08:  # BC format
            tf = get_bits(word, 16, 16)
            return True, "bc1t" if tf else "bc1f", imm
    return False, None, None

def check_branch_within(code, offset, max_dist=4):
    """Check if there's a conditional branch within max_dist instructions."""
    for j in range(1, min(max_dist + 1, (len(code) - offset) // 4)):
        next_word = struct.unpack_from('<I', code, offset + j * 4)[0]
        is_br, br_type, _ = is_conditional_branch(next_word)
        if is_br:
            return True, br_type, j
    return False, None, None

def scan_pattern_1_slti(code, text_addr, min_val, max_val):
    """Pattern 1: slti/sltiu $rt, $rs, IMM + branch"""
    results = []
    for i in range(0, len(code) - 8, 4):
        word = struct.unpack_from('<I', code, i)[0]
        op = get_bits(word, 31, 26)
        if op not in (OP_SLTI, OP_SLTIU):
            continue
        imm = sign_extend_16(get_bits(word, 15, 0))
        if imm < min_val or imm > max_val:
            continue
        has_branch, br_type, br_dist = check_branch_within(code, i, 4)
        if not has_branch:
            continue
        addr = text_addr + i
        name = "sltiu" if op == OP_SLTIU else "slti"
        rs = get_bits(word, 25, 21)
        rt = get_bits(word, 20, 16)
        results.append({
            'pattern': f'P1-{name}',
            'addr': addr,
            'value': imm,
            'disasm': f'{name} {REG_NAMES[rt]}, {REG_NAMES[rs]}, {imm}',
            'branch_type': br_type,
            'branch_dist': br_dist,
            'word_offset': i,
            'patch_word': (op << 26) | (rs << 21) | (rt << 16) | (32767 & 0xFFFF),
        })
    return results

def scan_pattern_2_subu_bltz(code, text_addr, min_val, max_val):
    """Pattern 2: subu $rd, $rs, $rt → bltz/bgez $rd"""
    results = []
    for i in range(0, len(code) - 8, 4):
        word = struct.unpack_from('<I', code, i)[0]
        op = get_bits(word, 31, 26)
        funct = get_bits(word, 5, 0)
        if op != OP_SPECIAL or funct not in (F_SUB, F_SUBU):
            continue
        rd = get_bits(word, 15, 11)
        rs = get_bits(word, 25, 21)
        rt = get_bits(word, 20, 16)
        # Check next instruction for bltz/bgez on rd
        if i + 4 < len(code):
            next_word = struct.unpack_from('<I', code, i + 4)[0]
            next_op = get_bits(next_word, 31, 26)
            next_rt = get_bits(next_word, 20, 16)
            next_rs = get_bits(next_word, 25, 21)
            if next_op == OP_REGIMM and next_rt in (RT_BLTZ, RT_BGEZ):
                # Check if there's an addiu loading a constant before the sub
                if i >= 4:
                    prev_word = struct.unpack_from('<I', code, i - 4)[0]
                    prev_op = get_bits(prev_word, 31, 26)
                    if prev_op == OP_ADDIU:
                        prev_imm = sign_extend_16(get_bits(prev_word, 15, 0))
                        prev_rt_reg = get_bits(prev_word, 20, 16)
                        if abs(prev_imm) >= min_val and abs(prev_imm) <= max_val:
                            addr = text_addr + i - 4
                            val = abs(prev_imm)
                            name = "subu" if funct == F_SUBU else "sub"
                            br_name = "bltz" if next_rt == RT_BLTZ else "bgez"
                            results.append({
                                'pattern': f'P2-{name}+{br_name}',
                                'addr': addr,
                                'value': val,
                                'disasm': f'addiu {REG_NAMES[prev_rt_reg]}, $zero, {prev_imm}; {name} {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}; {br_name} {REG_NAMES[next_rs]}',
                                'branch_type': br_name,
                                'branch_dist': 2,
                                'word_offset': i - 4,
                                'patch_word': (OP_ADDIU << 26) | (0 << 21) | (prev_rt_reg << 16) | (32767 & 0xFFFF),
                            })
    return results

def scan_pattern_3_addiu_bltz(code, text_addr, min_val, max_val):
    """Pattern 3: addiu $rt, $rs, -IMM → bltz/bgez $rt"""
    results = []
    for i in range(0, len(code) - 8, 4):
        word = struct.unpack_from('<I', code, i)[0]
        op = get_bits(word, 31, 26)
        if op != OP_ADDIU:
            continue
        imm = sign_extend_16(get_bits(word, 15, 0))
        rt = get_bits(word, 20, 16)
        rs = get_bits(word, 25, 21)
        # Looking for addiu with negative immediate (subtraction)
        if imm >= 0 or abs(imm) < min_val or abs(imm) > max_val:
            continue
        # Check next instruction for bltz/bgez on rt
        if i + 4 < len(code):
            next_word = struct.unpack_from('<I', code, i + 4)[0]
            next_op = get_bits(next_word, 31, 26)
            next_rt = get_bits(next_word, 20, 16)
            if next_op == OP_REGIMM and next_rt in (RT_BLTZ, RT_BGEZ):
                next_rs = get_bits(next_word, 25, 21)
                if next_rs == rt:
                    addr = text_addr + i
                    val = abs(imm)
                    br_name = "bltz" if next_rt == RT_BLTZ else "bgez"
                    results.append({
                        'pattern': f'P3-addiu+{br_name}',
                        'addr': addr,
                        'value': val,
                        'disasm': f'addiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {imm}; {br_name} {REG_NAMES[rt]}',
                        'branch_type': br_name,
                        'branch_dist': 1,
                        'word_offset': i,
                        # Patch: change immediate to -32767 (very large subtraction)
                        'patch_word': (OP_ADDIU << 26) | (rs << 21) | (rt << 16) | ((-32767) & 0xFFFF),
                    })
    return results

def scan_pattern_4_float_compare(code, text_addr):
    """Pattern 4: c.le.s/c.lt.s + bc1t/bc1f"""
    results = []
    for i in range(0, len(code) - 8, 4):
        word = struct.unpack_from('<I', code, i)[0]
        op = get_bits(word, 31, 26)
        if op != OP_COP1:
            continue
        fmt = get_bits(word, 25, 21)
        ft = get_bits(word, 20, 16)
        fs = get_bits(word, 15, 11)
        fd = get_bits(word, 10, 6)
        funct = get_bits(word, 5, 0)
        # C cond.fmt: fmt=16 (single), funct=0x3E (c.le.s) or 0x3C (c.lt.s)
        if fmt != 0x10:
            continue
        if funct not in (0x3C, 0x3E, 0x3D, 0x3F):
            continue
        # Check next instruction for bc1t/bc1f
        has_branch, br_type, br_dist = check_branch_within(code, i, 3)
        if not has_branch:
            continue
        addr = text_addr + i
        cond_names = {0x3C: "c.lt.s", 0x3D: "c.lt.s", 0x3E: "c.le.s", 0x3F: "c.le.s"}
        cond_name = cond_names.get(funct, f"c.?.s({funct:#x})")
        results.append({
            'pattern': f'P4-float',
            'addr': addr,
            'value': -1,  # Float threshold unknown from code alone
            'disasm': f'{cond_name} $f{fd}, $f{fs}, $f{ft}; {br_type}',
            'branch_type': br_type,
            'branch_dist': br_dist,
            'word_offset': i,
            'patch_word': None,  # Float patches need different approach
        })
    return results

def scan_pattern_5_gte_flag(code, text_addr):
    """Pattern 5: cfc2 $rt, $flag → andi → bne/beq"""
    results = []
    for i in range(0, len(code) - 12, 4):
        word = struct.unpack_from('<I', code, i)[0]
        op = get_bits(word, 31, 26)
        if op != OP_COP2:
            continue
        rs = get_bits(word, 25, 21)
        if rs != 0x02:  # cfc2 sub-op
            continue
        rt = get_bits(word, 20, 16)
        rd = get_bits(word, 15, 11)  # GTE register number
        # Check for andi within 3 instructions
        for j in range(1, min(4, (len(code) - i) // 4)):
            check_word = struct.unpack_from('<I', code, i + j * 4)[0]
            check_op = get_bits(check_word, 31, 26)
            if check_op == OP_ANDI:
                andi_imm = get_bits(check_word, 15, 0)
                # Check for branch after andi
                has_branch, br_type, _ = check_branch_within(code, i + j * 4, 2)
                if has_branch and andi_imm != 0:
                    addr = text_addr + i
                    results.append({
                        'pattern': 'P5-GTE-flag',
                        'addr': addr,
                        'value': andi_imm,
                        'disasm': f'cfc2 {REG_NAMES[rt]}, $gtereg{rd}; andi {REG_NAMES[rt]}, 0x{andi_imm:04X}; {br_type}',
                        'branch_type': br_type,
                        'branch_dist': j + 1,
                        'word_offset': i,
                        'patch_word': None,  # GTE flag patches need different approach
                    })
                    break
    return results

def scan_pattern_6_sltu_range(code, text_addr, min_val, max_val):
    """Pattern 6: sltu $rt, $rs, $rd + branch (unsigned range check, sector-based)"""
    results = []
    for i in range(0, len(code) - 8, 4):
        word = struct.unpack_from('<I', code, i)[0]
        op = get_bits(word, 31, 26)
        funct = get_bits(word, 5, 0)
        if op != OP_SPECIAL or funct != F_SLTU:
            continue
        rd = get_bits(word, 15, 11)
        rs = get_bits(word, 25, 21)
        rt = get_bits(word, 20, 16)
        # Check for addiu loading a constant before (the range)
        if i >= 4:
            prev_word = struct.unpack_from('<I', code, i - 4)[0]
            prev_op = get_bits(prev_word, 31, 26)
            if prev_op == OP_ADDIU:
                prev_imm = sign_extend_16(get_bits(prev_word, 15, 0))
                if prev_imm >= min_val and prev_imm <= max_val:
                    has_branch, br_type, br_dist = check_branch_within(code, i, 2)
                    if has_branch:
                        addr = text_addr + i - 4
                        results.append({
                            'pattern': 'P6-sltu-range',
                            'addr': addr,
                            'value': prev_imm,
                            'disasm': f'addiu {REG_NAMES[get_bits(prev_word, 20, 16)]}, $zero, {prev_imm}; sltu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}; {br_type}',
                            'branch_type': br_type,
                            'branch_dist': br_dist,
                            'word_offset': i - 4,
                            'patch_word': (OP_ADDIU << 26) | (0 << 21) | (get_bits(prev_word, 20, 16) << 16) | (32767 & 0xFFFF),
                        })
    return results

# ============================================================================
#  PS-X EXE parser
# ============================================================================

PSX_EXE_MAGIC = b"PS-X EXE"

def find_and_parse_exe(data):
    """Find and parse PS-X EXE header."""
    offset = data.find(PSX_EXE_MAGIC)
    if offset == -1:
        return None
    header = data[offset:offset + 0x800]
    if len(header) < 0x30:
        return None
    initial_pc = struct.unpack_from('<I', header, 0x10)[0]
    text_addr = struct.unpack_from('<I', header, 0x18)[0]
    text_size = struct.unpack_from('<I', header, 0x1C)[0]
    code_offset = offset + 0x800
    if text_size == 0 or text_size > 0x800000:
        text_size = min(len(data) - code_offset, 0x200000)
    code = data[code_offset:code_offset + text_size]
    return {
        'text_addr': text_addr,
        'text_size': text_size,
        'initial_pc': initial_pc,
        'code': code,
        'code_offset': code_offset,
    }

# ============================================================================
#  Disassembly context
# ============================================================================

def disasm_context(code, offset, text_addr, num_before=3, num_after=4):
    """Get disassembly context around an offset."""
    lines = []
    start = max(0, offset - num_before * 4)
    end = min(len(code), offset + (num_after + 1) * 4)
    for j in range(start, end, 4):
        if j + 4 > len(code):
            break
        word = struct.unpack_from('<I', code, j)[0]
        addr = text_addr + j
        op = get_bits(word, 31, 26)
        marker = " <<< CULLING" if j == offset else ""
        # Simple disasm
        if op == OP_SLTI or op == OP_SLTIU:
            imm = sign_extend_16(get_bits(word, 15, 0))
            name = "sltiu" if op == OP_SLTIU else "slti"
            d = f"{name} {REG_NAMES[get_bits(word,20,16)]}, {REG_NAMES[get_bits(word,25,21)]}, {imm}"
        elif op == OP_ADDIU:
            imm = sign_extend_16(get_bits(word, 15, 0))
            d = f"addiu {REG_NAMES[get_bits(word,20,16)]}, {REG_NAMES[get_bits(word,25,21)]}, {imm}"
        elif op == OP_BEQ:
            imm = sign_extend_16(get_bits(word, 15, 0))
            d = f"beq {REG_NAMES[get_bits(word,25,21)]}, {REG_NAMES[get_bits(word,20,16)]}, 0x{addr+4+imm*2:08X}"
        elif op == OP_BNE:
            imm = sign_extend_16(get_bits(word, 15, 0))
            d = f"bne {REG_NAMES[get_bits(word,25,21)]}, {REG_NAMES[get_bits(word,20,16)]}, 0x{addr+4+imm*2:08X}"
        elif op == OP_REGIMM:
            rt = get_bits(word, 20, 16)
            imm = sign_extend_16(get_bits(word, 15, 0))
            name = "bltz" if rt == RT_BLTZ else "bgez"
            d = f"{name} {REG_NAMES[get_bits(word,25,21)]}, 0x{addr+4+imm*2:08X}"
        elif op == OP_COP1:
            rs = get_bits(word, 25, 21)
            if rs == 0x08:
                tf = get_bits(word, 16, 16)
                imm = sign_extend_16(get_bits(word, 15, 0))
                d = f"{'bc1t' if tf else 'bc1f'} 0x{addr+4+imm*2:08X}"
            else:
                fmt = get_bits(word, 25, 21)
                funct = get_bits(word, 5, 0)
                cond = {0x3C: "c.lt.s", 0x3E: "c.le.s"}.get(funct, f"c.?.s({funct:#x})")
                d = f"{cond} $f{get_bits(word,15,11)}, $f{get_bits(word,10,6)}, $f{get_bits(word,20,16)}"
        elif op == OP_COP2:
            rs = get_bits(word, 25, 21)
            if rs == 0x02:
                d = f"cfc2 {REG_NAMES[get_bits(word,20,16)]}, $gtereg{get_bits(word,15,11)}"
            else:
                d = f"cop2 0x{word:08X}"
        elif op == OP_SPECIAL:
            funct = get_bits(word, 5, 0)
            if funct == F_SUBU:
                d = f"subu {REG_NAMES[get_bits(word,15,11)]}, {REG_NAMES[get_bits(word,25,21)]}, {REG_NAMES[get_bits(word,20,16)]}"
            elif funct == F_SUB:
                d = f"sub {REG_NAMES[get_bits(word,15,11)]}, {REG_NAMES[get_bits(word,25,21)]}, {REG_NAMES[get_bits(word,20,16)]}"
            elif funct == F_SLTU:
                d = f"sltu {REG_NAMES[get_bits(word,15,11)]}, {REG_NAMES[get_bits(word,25,21)]}, {REG_NAMES[get_bits(word,20,16)]}"
            elif funct == F_JR:
                d = f"jr {REG_NAMES[get_bits(word,25,21)]}"
            else:
                d = f"special funct={funct:#x}"
        elif op == OP_LUI:
            d = f"lui {REG_NAMES[get_bits(word,20,16)]}, 0x{get_bits(word,15,0):04X}"
        elif op == OP_ORI:
            d = f"ori {REG_NAMES[get_bits(word,20,16)]}, {REG_NAMES[get_bits(word,25,21)]}, 0x{get_bits(word,15,0):04X}"
        elif op == OP_LW:
            imm = sign_extend_16(get_bits(word, 15, 0))
            d = f"lw {REG_NAMES[get_bits(word,20,16)]}, {imm}({REG_NAMES[get_bits(word,25,21)]})"
        elif op == OP_SW:
            imm = sign_extend_16(get_bits(word, 15, 0))
            d = f"sw {REG_NAMES[get_bits(word,20,16)]}, {imm}({REG_NAMES[get_bits(word,25,21)]})"
        else:
            d = f".word 0x{word:08X}"
        lines.append(f"  0x{addr:08X}: {word:08X}  {d}{marker}")
    return lines

# ============================================================================
#  Cheat file generator
# ============================================================================

def generate_cht(candidates, game_name="Wipeout 2097"):
    lines = []
    lines.append(f"; {game_name} — Draw Distance Candidates")
    lines.append(f"; Generated by wipeout-scanner.py (comprehensive)")
    lines.append(f"; Enable ONE at a time. If pop-in changes, that's the culling instruction.")
    lines.append("")

    idx = 0
    for c in candidates:
        if c.get('patch_word') is None:
            continue  # Skip float/GTE candidates (need different patch approach)
        idx += 1
        if idx > 30:
            break
        addr = c['addr'] & 0x1FFFFFFF
        lines.append(f"[Candidate {idx}: {c['pattern']} addr=0x{c['addr']:08X} val={c['value']}]")
        lines.append("Type = Gameshark")
        lines.append("Activation = EndFrame")
        lines.append(f"A0{addr:07X} {c['patch_word']:08X}")
        lines.append("")

    # Also add float candidates as comments (need manual investigation)
    float_count = sum(1 for c in candidates if c.get('patch_word') is None)
    if float_count > 0:
        lines.append(f"; {float_count} float/GTE candidates found but need manual investigation")
        lines.append("; These use float compare or GTE flag — can't auto-patch")

    return '\n'.join(lines), idx


def generate_rsil_manifest(candidates, exe, game_name="Wipeout 2097",
                           game_md5="00000000000000000000000000000000"):
    """Generate an RSIL ScenePatchLayer manifest JSON from scan candidates.

    Unlike the .cht file (which patches specific addresses), the RSIL
    manifest uses signature-anchored AOB patterns derived from the
    original instruction bytes. This makes patches portable across
    regional variants and revisions.
    """
    import json

    code = exe['code']
    patches = []
    idx = 0
    for c in candidates:
        if c.get('patch_word') is None:
            continue  # Skip float/GTE (can't auto-patch)
        idx += 1
        if idx > 30:
            break

        # Build an AOB pattern from the original instruction word.
        # We use the full 4 bytes of the instruction as the pattern,
        # with no wildcards. The replacement is the patched word.
        offset = c['word_offset']
        orig_bytes = code[offset:offset + 4]
        patch_bytes = struct.pack('<I', c['patch_word'])

        pattern_hex = ' '.join(f'{b:02X}' for b in orig_bytes)
        replacement_hex = ' '.join(f'{b:02X}' for b in patch_bytes)

        # For slti/sltiu patterns, we also add a multiplier variant
        # (2x the original value) as an alternative to max-out.
        multipliers = []
        if c['value'] > 0:
            for mult in [2, 3, 4]:
                new_val = min(c['value'] * mult, 32767)
                if c['pattern'].startswith('P1'):
                    op = 0x0B if 'sltiu' in c['pattern'] else 0x0A
                    # Can't easily reconstruct without rs/rt — skip multi for now
                    pass
                multipliers.append(new_val)

        patches.append({
            'name': f'candidate_{idx}_{c["pattern"]}_addr_{c["addr"]:08X}',
            'description': f'{c["disasm"][:80]} | original_value={c["value"]} | maxed_to=32767',
            'pattern': pattern_hex,
            'replacement': replacement_hex,
            'category': 'streaming_budget' if c['value'] < 500 else 'lod_distance',
            'requires_8mb': c['value'] > 200,  # Larger thresholds need more RAM
        })

    manifest = {
        'display_name': f'{game_name} (auto-discovered)',
        'exe_md5': game_md5,
        'exe_crc32': 0,
        'exe_name': 'AUTO-DISCOVERED',
        'recommend_8mb_ram': any(p['requires_8mb'] for p in patches),
        'recommend_fastboot': False,
        'patches': patches,
    }
    return json.dumps(manifest, indent=2), len(patches)

# ============================================================================
#  Main
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description='Scan PS1 disc for culling patterns')
    parser.add_argument('iso', help='PS1 disc image (.bin)')
    parser.add_argument('--range', nargs=2, type=int, default=[50, 1000],
                        metavar=('MIN', 'MAX'), help='Value range to search (default: 50 1000)')
    parser.add_argument('--float', action='store_true', help='Also scan for float comparisons')
    parser.add_argument('--out', default='wipeout-draw-distance.cht', help='Output .cht file')
    parser.add_argument('--rsil-manifest', default=None,
                        help='Also output an RSIL ScenePatchLayer manifest JSON to this path')
    parser.add_argument('--md5', default='00000000000000000000000000000000',
                        help='Game executable MD5 for the RSIL manifest (32 hex chars)')
    args = parser.parse_args()

    if not os.path.exists(args.iso):
        print(f"ERROR: {args.iso} not found")
        sys.exit(1)

    print(f"Loading: {args.iso} ({os.path.getsize(args.iso)/1024/1024:.1f} MB)")
    with open(args.iso, 'rb') as f:
        data = f.read()

    print("Searching for PS-X EXE...")
    exe = find_and_parse_exe(data)
    if not exe:
        print("ERROR: No PS-X EXE found")
        sys.exit(1)

    print(f"  Text: 0x{exe['text_addr']:08X}, {exe['text_size']:,} bytes ({exe['text_size']//1024} KB)")
    print(f"  PC:   0x{exe['initial_pc']:08X}")

    min_val, max_val = args.range
    all_candidates = []

    print(f"\nScanning for culling patterns (range {min_val}-{max_val})...")

    # Pattern 1: slti/sltiu + branch
    p1 = scan_pattern_1_slti(exe['code'], exe['text_addr'], min_val, max_val)
    print(f"  P1 (slti/sltiu + branch):     {len(p1)} candidates")
    all_candidates.extend(p1)

    # Pattern 2: subu + bltz
    p2 = scan_pattern_2_subu_bltz(exe['code'], exe['text_addr'], min_val, max_val)
    print(f"  P2 (subu + bltz/bgez):        {len(p2)} candidates")
    all_candidates.extend(p2)

    # Pattern 3: addiu + bltz
    p3 = scan_pattern_3_addiu_bltz(exe['code'], exe['text_addr'], min_val, max_val)
    print(f"  P3 (addiu + bltz/bgez):       {len(p3)} candidates")
    all_candidates.extend(p3)

    # Pattern 6: sltu range
    p6 = scan_pattern_6_sltu_range(exe['code'], exe['text_addr'], min_val, max_val)
    print(f"  P6 (sltu range + branch):     {len(p6)} candidates")
    all_candidates.extend(p6)

    # Pattern 4: float compare (optional)
    if args.float:
        p4 = scan_pattern_4_float_compare(exe['code'], exe['text_addr'])
        print(f"  P4 (float c.le.s/c.lt.s):     {len(p4)} candidates")
        all_candidates.extend(p4)

    # Pattern 5: GTE flag
    p5 = scan_pattern_5_gte_flag(exe['code'], exe['text_addr'])
    print(f"  P5 (cfc2 GTE flag):           {len(p5)} candidates")
    all_candidates.extend(p5)

    if not all_candidates:
        print("\nNo candidates found. Try a wider range.")
        sys.exit(1)

    # Sort: integer patterns first (auto-patchable), then by closeness to 200
    all_candidates.sort(key=lambda c: (
        0 if c.get('patch_word') is not None else 1,
        abs(c['value'] - 200) if c['value'] > 0 else 9999
    ))

    # Print results
    print(f"\n{'='*80}")
    print(f"TOTAL: {len(all_candidates)} candidates")
    print(f"{'='*80}")
    print(f"\n{'#':<4} {'Pattern':<18} {'Address':<12} {'Value':<8} {'Branch':<8} Instruction")
    print("-" * 80)

    for i, c in enumerate(all_candidates[:40]):
        patchable = "✓" if c.get('patch_word') is not None else "✗"
        print(f"{i+1:<4} {c['pattern']:<18} 0x{c['addr']:08X}  {c['value']:<8} {c['branch_type']:<8} {c['disasm'][:50]}")

    # Print context for top 15
    print(f"\n{'='*80}")
    print("TOP 15 CANDIDATES WITH CONTEXT:")
    print(f"{'='*80}")
    for i, c in enumerate(all_candidates[:15]):
        print(f"\n--- #{i+1}: {c['pattern']} at 0x{c['addr']:08X} (value={c['value']}) ---")
        ctx = disasm_context(exe['code'], c['word_offset'], exe['text_addr'])
        for line in ctx:
            print(line)

    # Generate .cht file
    cht_content, patchable_count = generate_cht(all_candidates)
    with open(args.out, 'w') as f:
        f.write(cht_content)

    print(f"\n{'='*80}")
    print(f"Cheat file: {args.out} ({patchable_count} auto-patchable candidates)")
    print(f"{'='*80}")

    # Generate RSIL manifest if requested
    if args.rsil_manifest:
        manifest_json, manifest_count = generate_rsil_manifest(
            all_candidates, exe, game_name="Wipeout 2097", game_md5=args.md5)
        with open(args.rsil_manifest, 'w') as f:
            f.write(manifest_json)
        print(f"RSIL manifest: {args.rsil_manifest} ({manifest_count} patches)")
        print(f"  Copy to: dep/rsil/patches/ for RSIL Enhanced Mode")

    print(f"{'='*80}")
    print(f"""
To test in DuckStation:

1. Copy {args.out} to: %APPDATA%\\DuckStation\\cheats\\SCUS-94351.cht
   (or your portable mode cheats folder)

2. Load Wipeout 2097 in DuckStation

3. Right-click game → Cheats → enable ONE candidate at a time

4. Start a race. If pop-in changes, that's the culling instruction.

5. Candidates marked ✓ are auto-patchable. Candidates marked ✗ (float/GTE)
   need manual investigation — their context is printed above.
""")

if __name__ == "__main__":
    main()
