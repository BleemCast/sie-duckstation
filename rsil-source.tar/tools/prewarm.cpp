// SPDX-License-Identifier: BSD-3-Clause
// RSIL — `prewarm` CLI tool.
//
// Drives a headless DuckStation pre-pass to build the RSIL scheduling
// cache for a game. The resulting cache is loaded on subsequent normal
// launches, eliminating first-play host-side pop-in.
//
// Usage:
//   prewarm --exe <path-to-game-exe> [--save-state <path>]
//           [--input-replay <path>] [--frames <N>]
//           [--db <path>] [--force]
//
// This tool is the Cemu-shader-cache equivalent for RSIL scheduling.
// The first run takes ~10 minutes (configurable); subsequent launches
// of the same game load the cache in milliseconds.
//
// Integration note: when built inside DuckStation, this tool links
// against DuckStation's core library and uses its headless mode to
// drive the emulator. When built standalone (for testing), it simulates
// frames with a no-op advance callback.

#include "rsil/RSILSubsystem.h"
#include "rsil/Config.h"
#include "rsil/HeadlessPrePass.h"
#include "rsil/Persistence.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <iostream>
#include <string>

#ifdef RSIL_DUCKSTATION_INTEGRATED
// When integrated into DuckStation, use the real headless system.
#include "core/system.h"
#include "core/host_interface.h"
int run_with_duckstation(int argc, char** argv);
#else
// Standalone mode: simulate frames (for testing the pre-pass logic
// without a full DuckStation build).
int run_standalone(int argc, char** argv);
#endif

static void print_usage() {
    std::fprintf(stderr,
        "RSIL prewarm — headless pre-pass cache builder\n"
        "\n"
        "Usage:\n"
        "  prewarm --exe <path> [options]\n"
        "\n"
        "Options:\n"
        "  --exe <path>          Game executable (PS-EXE or disc image)\n"
        "  --save-state <path>   Save state to load (skips boot/menu)\n"
        "  --input-replay <path> Input replay file (for directed exploration)\n"
        "  --frames <N>          Number of frames to run (default: 36000 = 10min)\n"
        "  --db <path>           Cache database path (default: rsil_cache.sqlite)\n"
        "  --force               Rebuild even if cache exists\n"
        "  --no-checkpoint       Disable periodic checkpoints\n"
        "  --quiet               Suppress progress output\n"
        "\n"
        "The cache is keyed by the executable's MD5/CRC32. Subsequent\n"
        "launches of the same game (via duckstation-qt) will load this\n"
        "cache automatically and have host-side pop-in pre-warmed.\n");
}

int main(int argc, char** argv) {
    if (argc < 2) {
        print_usage();
        return 1;
    }

    // Quick scan for --help / -h.
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--help") == 0 ||
            std::strcmp(argv[i], "-h") == 0) {
            print_usage();
            return 0;
        }
    }

#ifdef RSIL_DUCKSTATION_INTEGRATED
    return run_with_duckstation(argc, argv);
#else
    return run_standalone(argc, argv);
#endif
}

// ---------------------------------------------------------------------------
// Standalone mode (no DuckStation dependency)
// ---------------------------------------------------------------------------

#ifndef RSIL_DUCKSTATION_INTEGRATED

struct Args {
    std::filesystem::path exe;
    std::filesystem::path save_state;
    std::filesystem::path input_replay;
    std::filesystem::path db = "rsil_cache.sqlite";
    uint32_t frames = 36000;
    bool force = false;
    bool checkpoint = true;
    bool quiet = false;
};

static bool parse_args(int argc, char** argv, Args& a) {
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        auto next = [&](int& j) -> std::string {
            if (j + 1 >= argc) return "";
            return argv[++j];
        };
        if      (arg == "--exe")          a.exe = next(i);
        else if (arg == "--save-state")   a.save_state = next(i);
        else if (arg == "--input-replay") a.input_replay = next(i);
        else if (arg == "--db")           a.db = next(i);
        else if (arg == "--frames")       a.frames = std::stoul(next(i));
        else if (arg == "--force")        a.force = true;
        else if (arg == "--no-checkpoint") a.checkpoint = false;
        else if (arg == "--quiet")        a.quiet = true;
        else {
            std::fprintf(stderr, "Unknown argument: %s\n", arg.c_str());
            return false;
        }
    }
    if (a.exe.empty()) {
        std::fprintf(stderr, "Error: --exe is required\n");
        return false;
    }
    return true;
}

int run_standalone(int argc, char** argv) {
    Args a;
    if (!parse_args(argc, argv, a)) {
        print_usage();
        return 1;
    }

    if (!a.quiet) {
        std::printf("RSIL prewarm (standalone test mode)\n");
        std::printf("  exe:           %s\n", a.exe.string().c_str());
        std::printf("  frames:        %u\n", a.frames);
        std::printf("  db:            %s\n", a.db.string().c_str());
        std::printf("  checkpoint:    %s\n", a.checkpoint ? "yes" : "no");
        std::printf("\n");
    }

    // In standalone mode we don't have a real executable to hash, so we
    // synthesize a signature from the filename. In integrated mode this
    // is computed from the actual loaded PS-EXE bytes.
    rsil::ExecutableSignature sig;
    sig.crc32 = 0xDEADBEEFu;
    sig.display_name = a.exe.filename().string();

    rsil::RSILConfig cfg = rsil::RSILConfig::defaults();
    cfg.db_path = a.db;
    cfg.flags.telemetry   = true;
    cfg.flags.graph       = true;
    cfg.flags.persistence = true;
    cfg.flags.predictor   = false;  // pre-pass mode
    cfg.flags.preregister = false;
    cfg.flags.overlay     = false;
    cfg.flags.validator   = false;

    rsil::NullHostAdapter null_host;
    auto subsystem = rsil::RSILSubsystem::create(
        cfg, null_host, nullptr, rsil::make_sqlite_backend());
    subsystem->on_executable_loaded(sig);

    rsil::PrePassConfig pcfg;
    pcfg.target_frames = a.frames;
    pcfg.save_state_path = a.save_state;
    pcfg.input_replay_path = a.input_replay;
    pcfg.force = a.force;
    pcfg.checkpoint = a.checkpoint;

    // Simulate frame advancement. In standalone mode there's no real
    // emulator, so we just tick the frame counter. This exercises the
    // pre-pass loop logic and produces a (mostly empty) cache file.
    uint32_t frame_counter = 0;
    auto advance = [&frame_counter](uint32_t) -> bool {
        frame_counter++;
        return true;
    };

    if (!a.quiet) {
        std::printf("Running pre-pass...\n");
    }

    bool ok = subsystem->run_pre_pass(pcfg, advance);

    auto prog = subsystem->pre_pass_progress();
    if (!a.quiet) {
        std::printf("\n");
        std::printf("Pre-pass %s\n", ok ? "completed" : "failed");
        std::printf("  frames elapsed:       %u\n", prog.frames_elapsed);
        std::printf("  signatures observed: %u\n", prog.signatures_observed);
        std::printf("  transitions observed:%u\n", prog.transitions_observed);
        std::printf("  cells assigned:      %u\n", prog.cells_assigned);
        if (!prog.error_message.empty()) {
            std::printf("  error: %s\n", prog.error_message.c_str());
        }
        std::printf("\n");
        std::printf("Cache saved to: %s\n", a.db.string().c_str());
        std::printf("Subsequent launches of this game will load the cache\n");
        std::printf("and have host-side pop-in pre-warmed.\n");
    }

    return ok ? 0 : 1;
}

#endif  // RSIL_DUCKSTATION_INTEGRATED
